﻿namespace ToolsForOffice.DailyTasks.Classes
{
    public static class Utils
    {
        public static string[] GetCustomValueNames()
        {
            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string valuesFilePath = Path.Combine(desktopPath, "DailyTasks", "DailyTasks-Values.bin");

            return File.ReadAllLines(valuesFilePath);
        }
    }

}