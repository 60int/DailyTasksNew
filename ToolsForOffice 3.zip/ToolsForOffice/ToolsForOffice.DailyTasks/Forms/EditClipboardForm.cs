﻿using Sunny.UI;
using System.Text;
using ToolsForOffice.Shared;

namespace ToolsForOffice.DailyTasks.Forms
{
    public partial class EditClipboardForm : UIForm
    {
        static readonly List<TextCell> textCells = new();

        private SelectedTheme? _cachedSelectedTheme;
        private void LoadTheme()
        {
            if (_cachedSelectedTheme == null)
            {
                string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
                string filePath = Path.Combine(desktopPath, "DailyTasks", "DailyTasks-SelectedTheme.bin");
                _cachedSelectedTheme = SelectedTheme.Load(filePath);
            }

            switch (_cachedSelectedTheme.CurrentTheme)
            {
                case Theme.Cloud:
                    UIStyles.InitColorful(Color.SkyBlue, Color.White);
                    break;
                case Theme.Summer:
                    UIStyles.InitColorful(Color.Green, Color.White);
                    break;
                case Theme.Spring:
                    UIStyles.InitColorful(Color.LightPink, Color.Black);
                    break;
                case Theme.Fall:
                    UIStyles.InitColorful(Color.Orange, Color.Black);
                    break;
                case Theme.Snow:
                    UIStyles.InitColorful(Color.LightBlue, Color.White);
                    break;
                case Theme.Default:
                    break;
            }
        }

        public EditClipboardForm()
        {
            InitializeComponent();

            //Check if file is empty
            long fileLen = new FileInfo("Daily Tasks/Settings/CopyClipboard.txt").Length;
            if (fileLen == 0 || (fileLen == 3 && File.ReadAllBytes("file").SequenceEqual(new byte[] { 239, 187, 191 })))
            {
                MessageBox.Show("A text fájl jelenleg nem szerkeszthető", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (textCells.Count == 0)
                {
                    using StreamReader reader = new("Daily Tasks/Settings/CopyClipboard.txt", Encoding.UTF8);
                    while (!reader.EndOfStream)
                    {
                        textCells.Add(new TextCell(reader.ReadLine()));
                    }
                    reader.Close();
                }
            }
            MainDataGridView.DataSource = null;
            MainDataGridView.Rows.Clear();
            MainDataGridView.Columns.Clear();
            MainDataGridView.DataSource = textCells;
            MainDataGridView.Columns[1].HeaderText = MainDataGridView.Rows[0].DataBoundItem.ToString();
            MainDataGridView.Columns[2].HeaderText = MainDataGridView.Rows[1].DataBoundItem.ToString();
            MainDataGridView.Columns[3].HeaderText = MainDataGridView.Rows[2].DataBoundItem.ToString();
            MainDataGridView.Columns[4].HeaderText = MainDataGridView.Rows[3].DataBoundItem.ToString();
            MainDataGridView.Columns[5].HeaderText = MainDataGridView.Rows[4].DataBoundItem.ToString();
            MainDataGridView.Columns[6].HeaderText = MainDataGridView.Rows[5].DataBoundItem.ToString();
            MainDataGridView.Columns[7].HeaderText = MainDataGridView.Rows[6].DataBoundItem.ToString();
            MainDataGridView.Columns[8].HeaderText = MainDataGridView.Rows[7].DataBoundItem.ToString();

            MainDataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            int rowHeight = (MainDataGridView.Height - MainDataGridView.ColumnHeadersHeight) / MainDataGridView.Rows.Count - 2;
            MainDataGridView.RowTemplate.Height = rowHeight;
            MainDataGridView.ColumnHeadersHeight = rowHeight;
            MainDataGridView.DefaultCellStyle.WrapMode = DataGridViewTriState.True;

            LoadTheme();
        }

        private void OKButton_Click(object sender, EventArgs e)
        {
            try
            {
                var confirmResult = MessageBox.Show("Do you want to change this value?", "Value change", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (confirmResult == DialogResult.Yes)
                {
                    using TextWriter tw = new StreamWriter("Daily Tasks/Settings/CopyClipboard.txt", false);
                    for (int i = 0; i < MainDataGridView.Rows.Count; i++)
                    {
                        for (int j = 0; j < MainDataGridView.Columns.Count; j++)
                        {
                            tw.Write($"{MainDataGridView.Rows[i].Cells[j].Value}");
                            if (j != MainDataGridView.Columns.Count - 1)
                            {
                                tw.Write(",");
                            }
                        }
                        tw.WriteLine();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                DialogResult = DialogResult.None;
            }
        }

        private void CancelButton_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
