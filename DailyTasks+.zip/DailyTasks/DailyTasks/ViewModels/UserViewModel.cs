﻿using System;
using System.IO;
using System.Linq;
using System.Windows;
using DailyTasks.Views;
using DailyTasks.Models;
using System.Windows.Input;
using DailyTasks.DataAccess;
using System.Threading.Tasks;
using System.Collections.ObjectModel;

namespace DailyTasks.ViewModels
{
    public class UserViewModel : ViewModelBase
    {
        private ICommand? _saveCommand;
        private ICommand? _resetCommand;
        private ICommand? _editCommand;
        private ICommand? _deleteCommand;
        private ICommand? _selectCommand;
        private UsersRepository _userRepository;
        public User UserRecord { get; set; }
        private User _currentUser;

        public UserViewModel()
        {
            UserRecord = new User();
            _currentUser = new User();
            LoadAllUsersAsync();
        }
        public ICommand? SaveCommand
        {
            get
            {
                _saveCommand ??= new AsyncRelayCommand(param => SaveUserAsync(), null!);

                return _saveCommand;
            }
        }
        public ICommand ResetCommand
        {
            get
            {
                _resetCommand ??= new AsyncRelayCommand(param => ResetDataAsync(), null!);

                return _resetCommand;
            }
        }
        public ICommand EditCommand
        {
            get
            {
                _editCommand ??= new AsyncRelayCommand(param => EditUserAsync((int)param), null!);

                return _editCommand;
            }
        }
        public ICommand DeleteCommand
        {
            get
            {
                _deleteCommand ??= new AsyncRelayCommand(param => DeleteUserAsync((int)param), null!);

                return _deleteCommand;
            }
        }
        public ICommand SelectCommand
        {
            get
            {
                _selectCommand ??= new AsyncRelayCommand(param => SelectUserAsync(), null!);

                return _selectCommand;
            }
        }
        public User CurrentUser
        {
            get => _currentUser;
            set
            {
                _currentUser = value;
                OnPropertyChanged(nameof(CurrentUser));
            }
        }
        public async Task SelectUserAsync()
        {
            if (CurrentUser != null)
            {
                string currentUser = CurrentUser.UserName;
                string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
                string filePath = Path.Combine(desktopPath, "DailyTasks", "DailyTasks-MyUser.txt");
                await File.WriteAllTextAsync(filePath, currentUser);

                if (Application.Current.Windows.OfType<UsersWindow>().FirstOrDefault() is UsersWindow usersPage)
                {
                    usersPage.Close();
                }
            }
        }

        public async Task ResetDataAsync()
        {
            UserRecord.UserName = string.Empty;
            UserRecord.Id = 0;
        }
        public async Task SaveUserAsync()
        {
            _userRepository = new UsersRepository();
            if (UserRecord != null && !string.IsNullOrEmpty(UserRecord.UserName))
            {
                User userEntity = new User { UserName = UserRecord.UserName };
                try
                {
                    if (UserRecord.Id <= 0)
                    {
                        await _userRepository.AddUser(userEntity);
                        MessageBox.Show("New user successfully saved.");
                    }
                    else
                    {
                        userEntity.Id = UserRecord.Id;
                        await _userRepository.UpdateUser(userEntity);
                        MessageBox.Show("User successfully updated.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occured while saving. " + ex.InnerException);
                }
            }
            if (Application.Current.Windows.OfType<UsersWindow>().FirstOrDefault() is UsersWindow usersPage)
            {
                usersPage.Close();
            }
        }

        public async Task DeleteUserAsync(int id)
        {
            if (MessageBox.Show("Confirm delete of this user?", "User", MessageBoxButton.YesNo)
                == MessageBoxResult.Yes)
            {
                try
                {
                    await _userRepository!.RemoveUser(id);
                    MessageBox.Show("User successfully deleted.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occured while saving. " + ex.InnerException);
                }
                finally
                {
                    await LoadAllUsersAsync();
                }
            }
        }

        public async Task EditUserAsync(int id)
        {
            var model = await _userRepository!.Get(id);
            UserRecord.Id = model.Id;
            UserRecord.UserName = model.UserName;
        }

        public async Task LoadAllUsersAsync()
        {
            _userRepository = new UsersRepository();
            UserRecord.Users = new ObservableCollection<User>(await _userRepository.GetAll());
        }
    }
}
