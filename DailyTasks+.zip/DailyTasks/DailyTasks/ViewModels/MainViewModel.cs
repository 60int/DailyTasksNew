﻿using System;
using System.IO;
using System.Linq;
using System.Windows;
using DailyTasks.Views;
using DailyTasks.Models;
using System.Windows.Input;
using DailyTasks.DataAccess;
using System.Threading.Tasks;
using System.Collections.ObjectModel;

namespace DailyTasks.ViewModels
{
    public class MainViewModel : ViewModelBase
    {
        #region Fields and Properties

        private ICommand? _openUsersWindowCommand;

        private readonly TasksRepository _tasksRepository;

        private readonly UsersRepository _usersRepository;

        public User? UserRecord { get; set; }

        public DailyTask? DailyTaskRecord { get; set; }

        public TasksViewModel Tasks { get; set; }

        private string? _currentUserName;

        public string? CurrentUserName
        {
            get => _currentUserName;
            set
            {
                _currentUserName = value;
                OnPropertyChanged(nameof(CurrentUserName));
            }
        }

        #endregion

        public MainViewModel()
        {
            DailyTaskRecord = new DailyTask();
            _usersRepository = new UsersRepository();
            _tasksRepository = new TasksRepository();
            Tasks = new TasksViewModel();
            CurrentUserName = GetUsernameFromFile();

            InitializeAsync();
        }

        private async Task InitializeAsync()
        {
            try
            {
                await Tasks.GetAll();
                await LoadCurrentUserTasks();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.InnerException.ToString(), ex.Message);
            }
        }

        public ICommand? OpenUsersWindowCommand
        {
            get
            {
                _openUsersWindowCommand ??= new AsyncRelayCommand(param => OpenUsersWindow(), null!);

                return _openUsersWindowCommand;
            }
        }

        private static string GetUsernameFromFile()
        {
            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string filePath = Path.Combine(desktopPath, "DailyTasks", "DailyTasks-MyUser.txt");
            string username = File.ReadAllText(filePath).Trim();
            return username;
        }

        public async Task OpenUsersWindow()
        {
            await Application.Current.Dispatcher.InvokeAsync(() =>
            {
                var userWindow = new UsersWindow
                {
                    DataContext = new UserViewModel()
                };
                userWindow.ShowDialog();
            });
            LoadCurrentUserTasks();
        }

        private async Task LoadCurrentUserTasks()
        {
            string currentUserName = GetUsernameFromFile();

            User currentUser = (await _usersRepository.GetAll()).FirstOrDefault(user => user.UserName == currentUserName)!;

            if (currentUser != null)
            {
                DailyTaskRecord!.DailyTasks = new ObservableCollection<DailyTask>((await _tasksRepository.GetAll()).Where(task => task.User != null && task.User.Id == currentUser.Id));
                CurrentUserName = currentUser.UserName!;
            }
            else
            {
                DailyTaskRecord!.DailyTasks!.Clear();
            }
        }
    }
}