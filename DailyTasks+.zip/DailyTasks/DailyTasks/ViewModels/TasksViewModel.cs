﻿using System;
using System.Windows;
using DailyTasks.Views;
using DailyTasks.Models;
using System.Windows.Input;
using DailyTasks.DataAccess;
using System.Threading.Tasks;
using System.Collections.ObjectModel;

namespace DailyTasks.ViewModels
{
    public class TasksViewModel
    {
        private ICommand? _editCommand;
        private ICommand? _deleteCommand;
        private ICommand? _openAddTaskWindowCommand;
        private readonly TasksRepository? _tasksRepository;
        public ObservableCollection<DailyTask> DailyTasks { get; set; }
        public TasksViewModel()
        {
            DailyTasks = new ObservableCollection<DailyTask>();
            _tasksRepository = new TasksRepository();
            GetAll();
        }
        public ICommand EditCommand
        {
            get
            {
                _editCommand ??= new AsyncRelayCommand(async param => await EditTask((int)param), null!);

                return _editCommand;
            }
        }

        public ICommand DeleteCommand
        {
            get
            {
                _deleteCommand ??= new AsyncRelayCommand(async param => await DeleteTask((int)param), null!);

                return _deleteCommand;
            }
        }

        public ICommand OpenAddTaskWindowCommand
        {
            get
            {
                _openAddTaskWindowCommand ??= new AsyncRelayCommand(async param => await OpenAddTaskWindow(), null!);

                return _openAddTaskWindowCommand;
            }
        }

        public async Task GetAll()
        {
            DailyTasks.Clear();
            var tasks = await _tasksRepository!.GetAll();
            foreach (var data in tasks)
            {
                DailyTasks.Add(new DailyTask()
                {
                    Id = data.Id,
                    User = data.User,
                    TotalAmount = data.TotalAmount,
                    CustomValue1 = data.CustomValue1,
                    CustomValue2 = data.CustomValue2,
                    CustomValue3 = data.CustomValue3,
                    CustomValue4 = data.CustomValue4,
                    StartTime = (DateTime)data.StartTime!,
                    EndTime = (DateTime)data.EndTime!,
                    Completed = data.Completed,
                    Priority = data.Priority,
                    TaskType = data.TaskType
                });
            }
        }

        public async Task OpenAddTaskWindow()
        {
            var taskWindow = new AddTaskWindow
            {
                DataContext = new AddTaskViewModel()
            };
            taskWindow.ShowDialog();
            await GetAll();
        }
        public async Task DeleteTask(int id)
        {
            if (MessageBox.Show("Confirm delete of this record?", "Task", MessageBoxButton.YesNo)
                == MessageBoxResult.Yes)
            {
                try
                {
                    await _tasksRepository!.RemoveDailyTask(id);
                    MessageBox.Show("Record successfully deleted.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occured while saving. " + ex.InnerException);
                }
                finally
                {
                    await GetAll();
                }
            }
        }
        public async Task EditTask(int id)
        {
            var model = await _tasksRepository!.Get(id);
            var addTaskWindow = new AddTaskWindow();
            var addTaskViewModel = new AddTaskViewModel
            {
                DailyTaskRecord = model,
            };
            addTaskWindow.DataContext = addTaskViewModel;
            addTaskWindow.ShowDialog();
            await GetAll();
        }
    }

}