﻿using System;
using System.IO;
using System.Linq;
using System.Windows;
using DailyTasks.Views;
using DailyTasks.Models;
using System.Windows.Input;
using DailyTasks.DataAccess;
using System.Threading.Tasks;

namespace DailyTasks.ViewModels
{
    public class AddTaskViewModel
    {
        private ICommand? _saveCommand;
        private TasksRepository? _repository;
        private readonly DailyTask? _dailyTaskEntity = null!;
        public DailyTask DailyTaskRecord { get; set; }
        public static Array TaskPriorities
        {
            get { return Enum.GetValues(typeof(TaskPriority)); }
        }
        public ICommand? SaveCommand
        {
            get
            {
                _saveCommand ??= new AsyncRelayCommand(async param => await SaveData(), null!);

                return _saveCommand;
            }
        }
        public AddTaskViewModel()
        {
            DailyTaskRecord = new DailyTask();
            _dailyTaskEntity = new DailyTask();
            LoadCurrentUser();
        }
        public async Task LoadCurrentUser()
        {
            UsersRepository usersRepository = new();
            string currentUserName = GetUsernameFromFile()!;
            User currentUser =(await usersRepository.GetAll()).FirstOrDefault(u => u.UserName == currentUserName)!;
            if (currentUser != null)
            {
                DailyTaskRecord.User = currentUser;
            }
        }
        private static string? GetUsernameFromFile()
        {
            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string filePath = Path.Combine(desktopPath, "DailyTasks", "DailyTasks-MyUser.txt");
            string username = File.ReadAllText(filePath).Trim();
            return username;
        }
        public async Task SaveData()
        {
            _repository = new TasksRepository();
            UsersRepository usersRepository = new();

            if (DailyTaskRecord != null)
            {
                User user =(await usersRepository.GetAll()).FirstOrDefault(u => u.UserName == DailyTaskRecord.User.UserName)!;
                if (user == null)
                {
                    MessageBox.Show("The user does not exist.");
                    return;
                }
                _repository.DbContext.Users.Attach(user);
                _dailyTaskEntity!.UserId = user.Id;
                _dailyTaskEntity!.User = user!;
                _dailyTaskEntity!.User.UserName = user!.UserName;
                _dailyTaskEntity.TotalAmount = DailyTaskRecord.TotalAmount;
                _dailyTaskEntity.CustomValue1 = DailyTaskRecord.CustomValue1;
                _dailyTaskEntity.CustomValue2 = DailyTaskRecord.CustomValue2;
                _dailyTaskEntity.CustomValue3 = DailyTaskRecord.CustomValue3;
                _dailyTaskEntity.CustomValue4 = DailyTaskRecord.CustomValue4;
                _dailyTaskEntity.StartTime = DailyTaskRecord.StartTime!;
                _dailyTaskEntity.EndTime = DailyTaskRecord.EndTime!;
                _dailyTaskEntity.Completed = DailyTaskRecord.Completed;
                _dailyTaskEntity.Priority = DailyTaskRecord.Priority;
                _dailyTaskEntity.TaskType = DailyTaskRecord.TaskType;
                try
                {
                    if (DailyTaskRecord.Id <= 0)
                    {
                        await _repository!.AddDailyTask(_dailyTaskEntity);
                        MessageBox.Show("New task successfully saved.");
                    }
                    else
                    {
                        _dailyTaskEntity.Id = DailyTaskRecord.Id;
                        await _repository!.UpdateDailyTask(_dailyTaskEntity);
                        MessageBox.Show("Task successfully updated.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occured while saving. " + ex.InnerException);
                }
            }
            if (Application.Current.Windows.OfType<AddTaskWindow>().FirstOrDefault() is AddTaskWindow tasksPage)
            {
                tasksPage.Close();
            }
        }
    }
}