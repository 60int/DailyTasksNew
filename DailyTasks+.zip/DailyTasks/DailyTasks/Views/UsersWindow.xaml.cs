﻿using Wpf.Ui.Controls;

namespace DailyTasks.Views
{
    /// <summary>
    /// Interaction logic for UsersWindow.xaml
    /// </summary>
    public partial class UsersWindow : UiWindow
    {
        public UsersWindow()
        {
            InitializeComponent();
        }
    }
}
