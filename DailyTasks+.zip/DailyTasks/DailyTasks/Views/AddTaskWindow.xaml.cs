﻿using Wpf.Ui.Controls;

namespace DailyTasks.Views
{
    public partial class AddTaskWindow : UiWindow
    {
        public AddTaskWindow()
        {
            InitializeComponent();
        }
    }
}
