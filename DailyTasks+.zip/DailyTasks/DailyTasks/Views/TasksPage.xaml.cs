﻿using Wpf.Ui.Controls;
using DailyTasks.ViewModels;

namespace DailyTasks.Views
{
    public partial class TasksPage : UiPage
    {
        public TasksPage()
        {
            InitializeComponent();
            DataContext = new TasksViewModel();
        }
    }
}