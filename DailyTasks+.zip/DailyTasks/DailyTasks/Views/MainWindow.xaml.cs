﻿using Wpf.Ui.Controls;
using DailyTasks.ViewModels;
using Wpf.Ui.Appearance;

namespace DailyTasks.Views
{
    public partial class MainWindow : UiWindow
    {
        public MainWindow()
        {
            InitializeComponent();
            DataContext = new MainViewModel();
            //Wpf.Ui.Appearance.Background.Apply(this, BackgroundType.Acrylic);
            //Wpf.Ui.Animations.Transitions.ApplyTransition(UserButton, Wpf.Ui.Animations.TransitionType.FadeIn, 15);
        }
    }
}
