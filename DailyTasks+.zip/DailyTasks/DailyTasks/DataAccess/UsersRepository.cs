﻿using DailyTasks.Models;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace DailyTasks.DataAccess
{
    public class UsersRepository
    {
        private readonly DailyTasksDbContext _dbContext = null!;

        public UsersRepository()
        {
            _dbContext = new DailyTasksDbContext();
        }
        public async Task<User> Get(int id)
        {
            return await _dbContext.Users.FindAsync(id);
        }
        public async Task<IEnumerable<User>> GetAll()
        {
            return await _dbContext!.Users.ToListAsync();
        }
        public async Task AddUser(User user)
        {
            if (user != null)
            {
                await _dbContext!.Users.AddAsync(user);
                await _dbContext.SaveChangesAsync();
            }
        }
        public async Task UpdateUser(User user)
        {
            var userToUpdate = await Get(user.Id);
            if (userToUpdate != null)
            {
                userToUpdate.UserName = user.UserName;
                await _dbContext!.SaveChangesAsync();
            }
        }
        public async Task RemoveUser(int id)
        {
            var user = await _dbContext!.Users.FindAsync(id);
            if (user != null)
            {
                _dbContext.Users.Remove(user);
                await _dbContext.SaveChangesAsync();
            }
        }
    }
}
