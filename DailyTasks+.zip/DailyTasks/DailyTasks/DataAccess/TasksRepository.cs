﻿using DailyTasks.Models;
using System.Threading.Tasks;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace DailyTasks.DataAccess
{
    public class TasksRepository
    {
        private readonly DailyTasksDbContext? _dbContext = null;
        public DailyTasksDbContext DbContext => _dbContext;
        public TasksRepository()
        {
            _dbContext = new DailyTasksDbContext();
        }
        public async Task<DailyTask> Get(int id)
        {
            return await _dbContext!.DailyTasks.Include(t => t.User).FirstOrDefaultAsync(t => t.Id == id);
        }
        public async Task<IEnumerable<DailyTask>> GetAll()
        {
            return await _dbContext!.DailyTasks.Include(t => t.User).ToListAsync();
        }
        public async Task AddDailyTask(DailyTask dailyTask)
        {
            if (dailyTask != null)
            {
                await _dbContext!.DailyTasks.AddAsync(dailyTask);
                await _dbContext.SaveChangesAsync();
            }
        }
        public async Task UpdateDailyTask(DailyTask dailyTask)
        {
            var taskToUpdate = await Get(dailyTask.Id);
            if (taskToUpdate != null)
            {
                taskToUpdate.User = dailyTask.User;
                taskToUpdate.TotalAmount = dailyTask.TotalAmount;
                taskToUpdate.CustomValue1 = dailyTask.CustomValue1 ?? 0;
                taskToUpdate.CustomValue2 = dailyTask.CustomValue2 ?? 0;
                taskToUpdate.CustomValue3 = dailyTask.CustomValue3 ?? 0;
                taskToUpdate.CustomValue4 = dailyTask.CustomValue4 ?? 0;
                taskToUpdate.StartTime = dailyTask.StartTime!;
                taskToUpdate.EndTime = dailyTask.EndTime!;
                taskToUpdate.Completed = dailyTask.Completed;
                taskToUpdate.Priority = dailyTask.Priority;
                taskToUpdate.TaskType = dailyTask.TaskType;

                await _dbContext!.SaveChangesAsync();
            }
        }
        public async Task RemoveDailyTask(int id)
        {
            var dailyTask = await _dbContext!.DailyTasks.FindAsync(id);
            if (dailyTask != null)
            {
                _dbContext.DailyTasks.Remove(dailyTask);
                await _dbContext.SaveChangesAsync();
            }
        }
    }
}
