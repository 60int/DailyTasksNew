﻿using Sunny.UI;

namespace ToolsForOffice.DailyTasks.Forms
{
    public partial class DataSettingsForm : UIForm
    {
        public DataSettingsForm()
        {
            InitializeComponent();
        }
    }
}
