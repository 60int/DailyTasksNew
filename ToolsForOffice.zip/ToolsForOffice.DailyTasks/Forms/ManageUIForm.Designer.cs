﻿namespace ToolsForOffice.DailyTasks.Forms
{
    partial class ManageUIForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ManageUIForm));
            uiLabel10 = new Sunny.UI.UILabel();
            uiButton5 = new Sunny.UI.UIButton();
            uiImageButton11 = new Sunny.UI.UIImageButton();
            uiImageButton12 = new Sunny.UI.UIImageButton();
            uiImageButton13 = new Sunny.UI.UIImageButton();
            uiImageButton14 = new Sunny.UI.UIImageButton();
            uiImageButton15 = new Sunny.UI.UIImageButton();
            uiLabel9 = new Sunny.UI.UILabel();
            uiButton4 = new Sunny.UI.UIButton();
            uiImageButton6 = new Sunny.UI.UIImageButton();
            uiImageButton7 = new Sunny.UI.UIImageButton();
            uiImageButton8 = new Sunny.UI.UIImageButton();
            uiImageButton9 = new Sunny.UI.UIImageButton();
            uiImageButton10 = new Sunny.UI.UIImageButton();
            uiLabel8 = new Sunny.UI.UILabel();
            DefaultMenuButton = new Sunny.UI.UIButton();
            SnowMenuButton = new Sunny.UI.UIImageButton();
            FallMenuButton = new Sunny.UI.UIImageButton();
            SpringMenuButton = new Sunny.UI.UIImageButton();
            SummerMenuButton = new Sunny.UI.UIImageButton();
            CLoudMenuButton = new Sunny.UI.UIImageButton();
            pictureBox1 = new PictureBox();
            ManageDataButton = new Sunny.UI.UIImageButton();
            ((System.ComponentModel.ISupportInitialize)uiImageButton11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)uiImageButton12).BeginInit();
            ((System.ComponentModel.ISupportInitialize)uiImageButton13).BeginInit();
            ((System.ComponentModel.ISupportInitialize)uiImageButton14).BeginInit();
            ((System.ComponentModel.ISupportInitialize)uiImageButton15).BeginInit();
            ((System.ComponentModel.ISupportInitialize)uiImageButton6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)uiImageButton7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)uiImageButton8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)uiImageButton9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)uiImageButton10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)SnowMenuButton).BeginInit();
            ((System.ComponentModel.ISupportInitialize)FallMenuButton).BeginInit();
            ((System.ComponentModel.ISupportInitialize)SpringMenuButton).BeginInit();
            ((System.ComponentModel.ISupportInitialize)SummerMenuButton).BeginInit();
            ((System.ComponentModel.ISupportInitialize)CLoudMenuButton).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)ManageDataButton).BeginInit();
            SuspendLayout();
            // 
            // uiLabel10
            // 
            uiLabel10.BackColor = Color.White;
            uiLabel10.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            uiLabel10.Location = new Point(302, 312);
            uiLabel10.Name = "uiLabel10";
            uiLabel10.Size = new Size(178, 23);
            uiLabel10.Style = Sunny.UI.UIStyle.Custom;
            uiLabel10.TabIndex = 62;
            uiLabel10.Text = "Clipboard Animation";
            uiLabel10.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // uiButton5
            // 
            uiButton5.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            uiButton5.Location = new Point(382, 370);
            uiButton5.MinimumSize = new Size(1, 1);
            uiButton5.Name = "uiButton5";
            uiButton5.Size = new Size(84, 25);
            uiButton5.Style = Sunny.UI.UIStyle.Custom;
            uiButton5.TabIndex = 61;
            uiButton5.Text = "Turn Off";
            // 
            // uiImageButton11
            // 
            uiImageButton11.BackColor = Color.White;
            uiImageButton11.BorderStyle = BorderStyle.FixedSingle;
            uiImageButton11.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            uiImageButton11.Location = new Point(366, 370);
            uiImageButton11.Name = "uiImageButton11";
            uiImageButton11.Size = new Size(10, 25);
            uiImageButton11.Style = Sunny.UI.UIStyle.Custom;
            uiImageButton11.TabIndex = 60;
            uiImageButton11.TabStop = false;
            uiImageButton11.Text = null;
            // 
            // uiImageButton12
            // 
            uiImageButton12.BackColor = Color.FromArgb(255, 128, 0);
            uiImageButton12.BorderStyle = BorderStyle.FixedSingle;
            uiImageButton12.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            uiImageButton12.Location = new Point(350, 370);
            uiImageButton12.Name = "uiImageButton12";
            uiImageButton12.Size = new Size(10, 25);
            uiImageButton12.Style = Sunny.UI.UIStyle.Custom;
            uiImageButton12.TabIndex = 59;
            uiImageButton12.TabStop = false;
            uiImageButton12.Text = null;
            // 
            // uiImageButton13
            // 
            uiImageButton13.BackColor = Color.FromArgb(255, 128, 255);
            uiImageButton13.BorderStyle = BorderStyle.FixedSingle;
            uiImageButton13.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            uiImageButton13.Location = new Point(334, 370);
            uiImageButton13.Name = "uiImageButton13";
            uiImageButton13.Size = new Size(10, 25);
            uiImageButton13.Style = Sunny.UI.UIStyle.Custom;
            uiImageButton13.TabIndex = 58;
            uiImageButton13.TabStop = false;
            uiImageButton13.Text = null;
            // 
            // uiImageButton14
            // 
            uiImageButton14.BackColor = Color.FromArgb(0, 192, 0);
            uiImageButton14.BorderStyle = BorderStyle.FixedSingle;
            uiImageButton14.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            uiImageButton14.Location = new Point(318, 370);
            uiImageButton14.Name = "uiImageButton14";
            uiImageButton14.Size = new Size(10, 25);
            uiImageButton14.Style = Sunny.UI.UIStyle.Custom;
            uiImageButton14.TabIndex = 57;
            uiImageButton14.TabStop = false;
            uiImageButton14.Text = null;
            // 
            // uiImageButton15
            // 
            uiImageButton15.BackColor = Color.SteelBlue;
            uiImageButton15.BorderStyle = BorderStyle.FixedSingle;
            uiImageButton15.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            uiImageButton15.Location = new Point(302, 370);
            uiImageButton15.Name = "uiImageButton15";
            uiImageButton15.Size = new Size(10, 25);
            uiImageButton15.Style = Sunny.UI.UIStyle.Custom;
            uiImageButton15.TabIndex = 56;
            uiImageButton15.TabStop = false;
            uiImageButton15.Text = null;
            // 
            // uiLabel9
            // 
            uiLabel9.BackColor = Color.White;
            uiLabel9.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            uiLabel9.Location = new Point(302, 195);
            uiLabel9.Name = "uiLabel9";
            uiLabel9.Size = new Size(145, 23);
            uiLabel9.Style = Sunny.UI.UIStyle.Custom;
            uiLabel9.TabIndex = 55;
            uiLabel9.Text = "Clipboard color";
            uiLabel9.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // uiButton4
            // 
            uiButton4.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            uiButton4.Location = new Point(382, 250);
            uiButton4.MinimumSize = new Size(1, 1);
            uiButton4.Name = "uiButton4";
            uiButton4.Size = new Size(84, 25);
            uiButton4.Style = Sunny.UI.UIStyle.Custom;
            uiButton4.TabIndex = 54;
            uiButton4.Text = "Default";
            // 
            // uiImageButton6
            // 
            uiImageButton6.BackColor = Color.White;
            uiImageButton6.BorderStyle = BorderStyle.FixedSingle;
            uiImageButton6.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            uiImageButton6.Location = new Point(366, 250);
            uiImageButton6.Name = "uiImageButton6";
            uiImageButton6.Size = new Size(10, 25);
            uiImageButton6.Style = Sunny.UI.UIStyle.Custom;
            uiImageButton6.TabIndex = 53;
            uiImageButton6.TabStop = false;
            uiImageButton6.Text = null;
            // 
            // uiImageButton7
            // 
            uiImageButton7.BackColor = Color.FromArgb(255, 128, 0);
            uiImageButton7.BorderStyle = BorderStyle.FixedSingle;
            uiImageButton7.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            uiImageButton7.Location = new Point(350, 250);
            uiImageButton7.Name = "uiImageButton7";
            uiImageButton7.Size = new Size(10, 25);
            uiImageButton7.Style = Sunny.UI.UIStyle.Custom;
            uiImageButton7.TabIndex = 52;
            uiImageButton7.TabStop = false;
            uiImageButton7.Text = null;
            // 
            // uiImageButton8
            // 
            uiImageButton8.BackColor = Color.FromArgb(255, 128, 255);
            uiImageButton8.BorderStyle = BorderStyle.FixedSingle;
            uiImageButton8.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            uiImageButton8.Location = new Point(334, 250);
            uiImageButton8.Name = "uiImageButton8";
            uiImageButton8.Size = new Size(10, 25);
            uiImageButton8.Style = Sunny.UI.UIStyle.Custom;
            uiImageButton8.TabIndex = 51;
            uiImageButton8.TabStop = false;
            uiImageButton8.Text = null;
            // 
            // uiImageButton9
            // 
            uiImageButton9.BackColor = Color.FromArgb(0, 192, 0);
            uiImageButton9.BorderStyle = BorderStyle.FixedSingle;
            uiImageButton9.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            uiImageButton9.Location = new Point(318, 250);
            uiImageButton9.Name = "uiImageButton9";
            uiImageButton9.Size = new Size(10, 25);
            uiImageButton9.Style = Sunny.UI.UIStyle.Custom;
            uiImageButton9.TabIndex = 50;
            uiImageButton9.TabStop = false;
            uiImageButton9.Text = null;
            // 
            // uiImageButton10
            // 
            uiImageButton10.BackColor = Color.SteelBlue;
            uiImageButton10.BorderStyle = BorderStyle.FixedSingle;
            uiImageButton10.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            uiImageButton10.Location = new Point(302, 250);
            uiImageButton10.Name = "uiImageButton10";
            uiImageButton10.Size = new Size(10, 25);
            uiImageButton10.Style = Sunny.UI.UIStyle.Custom;
            uiImageButton10.TabIndex = 49;
            uiImageButton10.TabStop = false;
            uiImageButton10.Text = null;
            // 
            // uiLabel8
            // 
            uiLabel8.BackColor = Color.White;
            uiLabel8.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            uiLabel8.Location = new Point(302, 89);
            uiLabel8.Name = "uiLabel8";
            uiLabel8.Size = new Size(145, 23);
            uiLabel8.Style = Sunny.UI.UIStyle.Custom;
            uiLabel8.TabIndex = 48;
            uiLabel8.Text = "Menu color";
            uiLabel8.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // DefaultMenuButton
            // 
            DefaultMenuButton.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            DefaultMenuButton.Location = new Point(384, 139);
            DefaultMenuButton.MinimumSize = new Size(1, 1);
            DefaultMenuButton.Name = "DefaultMenuButton";
            DefaultMenuButton.Size = new Size(82, 25);
            DefaultMenuButton.Style = Sunny.UI.UIStyle.Custom;
            DefaultMenuButton.TabIndex = 47;
            DefaultMenuButton.Text = "Default";
            DefaultMenuButton.Click += DefaultMenuButton_Click;
            // 
            // SnowMenuButton
            // 
            SnowMenuButton.BackColor = Color.White;
            SnowMenuButton.BorderStyle = BorderStyle.FixedSingle;
            SnowMenuButton.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            SnowMenuButton.Location = new Point(368, 139);
            SnowMenuButton.Name = "SnowMenuButton";
            SnowMenuButton.Size = new Size(10, 25);
            SnowMenuButton.Style = Sunny.UI.UIStyle.Custom;
            SnowMenuButton.TabIndex = 46;
            SnowMenuButton.TabStop = false;
            SnowMenuButton.Text = null;
            SnowMenuButton.Click += SnowMenuButton_Click;
            // 
            // FallMenuButton
            // 
            FallMenuButton.BackColor = Color.FromArgb(255, 128, 0);
            FallMenuButton.BorderStyle = BorderStyle.FixedSingle;
            FallMenuButton.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            FallMenuButton.Location = new Point(352, 139);
            FallMenuButton.Name = "FallMenuButton";
            FallMenuButton.Size = new Size(10, 25);
            FallMenuButton.Style = Sunny.UI.UIStyle.Custom;
            FallMenuButton.TabIndex = 45;
            FallMenuButton.TabStop = false;
            FallMenuButton.Text = null;
            FallMenuButton.Click += FallMenuButton_Click;
            // 
            // SpringMenuButton
            // 
            SpringMenuButton.BackColor = Color.FromArgb(255, 128, 255);
            SpringMenuButton.BorderStyle = BorderStyle.FixedSingle;
            SpringMenuButton.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            SpringMenuButton.Location = new Point(336, 139);
            SpringMenuButton.Name = "SpringMenuButton";
            SpringMenuButton.Size = new Size(10, 25);
            SpringMenuButton.Style = Sunny.UI.UIStyle.Custom;
            SpringMenuButton.TabIndex = 44;
            SpringMenuButton.TabStop = false;
            SpringMenuButton.Text = null;
            SpringMenuButton.Click += SpringMenuButton_Click;
            // 
            // SummerMenuButton
            // 
            SummerMenuButton.BackColor = Color.FromArgb(0, 192, 0);
            SummerMenuButton.BorderStyle = BorderStyle.FixedSingle;
            SummerMenuButton.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            SummerMenuButton.Location = new Point(320, 139);
            SummerMenuButton.Name = "SummerMenuButton";
            SummerMenuButton.Size = new Size(10, 25);
            SummerMenuButton.Style = Sunny.UI.UIStyle.Custom;
            SummerMenuButton.TabIndex = 43;
            SummerMenuButton.TabStop = false;
            SummerMenuButton.Text = null;
            SummerMenuButton.Click += SummerMenuButton_Click;
            // 
            // CLoudMenuButton
            // 
            CLoudMenuButton.BackColor = Color.SteelBlue;
            CLoudMenuButton.BorderStyle = BorderStyle.FixedSingle;
            CLoudMenuButton.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            CLoudMenuButton.Location = new Point(304, 139);
            CLoudMenuButton.Name = "CLoudMenuButton";
            CLoudMenuButton.Size = new Size(10, 25);
            CLoudMenuButton.Style = Sunny.UI.UIStyle.Custom;
            CLoudMenuButton.TabIndex = 42;
            CLoudMenuButton.TabStop = false;
            CLoudMenuButton.Text = null;
            CLoudMenuButton.Click += CLoudMenuButton_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.White;
            pictureBox1.Dock = DockStyle.Fill;
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(800, 450);
            pictureBox1.TabIndex = 41;
            pictureBox1.TabStop = false;
            // 
            // ManageDataButton
            // 
            ManageDataButton.BackColor = Color.White;
            ManageDataButton.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            ManageDataButton.Image = (Image)resources.GetObject("ManageDataButton.Image");
            ManageDataButton.ImageOffset = new Point(1, -1);
            ManageDataButton.Location = new Point(12, 12);
            ManageDataButton.Name = "ManageDataButton";
            ManageDataButton.Size = new Size(36, 36);
            ManageDataButton.SizeMode = PictureBoxSizeMode.StretchImage;
            ManageDataButton.Style = Sunny.UI.UIStyle.Custom;
            ManageDataButton.TabIndex = 63;
            ManageDataButton.TabStop = false;
            ManageDataButton.Text = null;
            ManageDataButton.Click += ManageDataButton_Click;
            // 
            // ManageUIForm
            // 
            AllowShowTitle = false;
            AutoScaleMode = AutoScaleMode.None;
            BackColor = Color.White;
            ClientSize = new Size(800, 450);
            Controls.Add(ManageDataButton);
            Controls.Add(uiLabel10);
            Controls.Add(uiButton5);
            Controls.Add(uiImageButton11);
            Controls.Add(uiImageButton12);
            Controls.Add(uiImageButton13);
            Controls.Add(uiImageButton14);
            Controls.Add(uiImageButton15);
            Controls.Add(uiLabel9);
            Controls.Add(uiButton4);
            Controls.Add(uiImageButton6);
            Controls.Add(uiImageButton7);
            Controls.Add(uiImageButton8);
            Controls.Add(uiImageButton9);
            Controls.Add(uiImageButton10);
            Controls.Add(uiLabel8);
            Controls.Add(DefaultMenuButton);
            Controls.Add(SnowMenuButton);
            Controls.Add(FallMenuButton);
            Controls.Add(SpringMenuButton);
            Controls.Add(SummerMenuButton);
            Controls.Add(CLoudMenuButton);
            Controls.Add(pictureBox1);
            Name = "ManageUIForm";
            Padding = new Padding(0);
            RectColor = Color.White;
            ShowTitle = false;
            Style = Sunny.UI.UIStyle.Custom;
            Text = "ManageUIForm";
            TitleColor = Color.White;
            ZoomScaleRect = new Rectangle(15, 15, 800, 450);
            ((System.ComponentModel.ISupportInitialize)uiImageButton11).EndInit();
            ((System.ComponentModel.ISupportInitialize)uiImageButton12).EndInit();
            ((System.ComponentModel.ISupportInitialize)uiImageButton13).EndInit();
            ((System.ComponentModel.ISupportInitialize)uiImageButton14).EndInit();
            ((System.ComponentModel.ISupportInitialize)uiImageButton15).EndInit();
            ((System.ComponentModel.ISupportInitialize)uiImageButton6).EndInit();
            ((System.ComponentModel.ISupportInitialize)uiImageButton7).EndInit();
            ((System.ComponentModel.ISupportInitialize)uiImageButton8).EndInit();
            ((System.ComponentModel.ISupportInitialize)uiImageButton9).EndInit();
            ((System.ComponentModel.ISupportInitialize)uiImageButton10).EndInit();
            ((System.ComponentModel.ISupportInitialize)SnowMenuButton).EndInit();
            ((System.ComponentModel.ISupportInitialize)FallMenuButton).EndInit();
            ((System.ComponentModel.ISupportInitialize)SpringMenuButton).EndInit();
            ((System.ComponentModel.ISupportInitialize)SummerMenuButton).EndInit();
            ((System.ComponentModel.ISupportInitialize)CLoudMenuButton).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)ManageDataButton).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Sunny.UI.UILabel uiLabel10;
        private Sunny.UI.UIButton uiButton5;
        private Sunny.UI.UIImageButton uiImageButton11;
        private Sunny.UI.UIImageButton uiImageButton12;
        private Sunny.UI.UIImageButton uiImageButton13;
        private Sunny.UI.UIImageButton uiImageButton14;
        private Sunny.UI.UIImageButton uiImageButton15;
        private Sunny.UI.UILabel uiLabel9;
        private Sunny.UI.UIButton uiButton4;
        private Sunny.UI.UIImageButton uiImageButton6;
        private Sunny.UI.UIImageButton uiImageButton7;
        private Sunny.UI.UIImageButton uiImageButton8;
        private Sunny.UI.UIImageButton uiImageButton9;
        private Sunny.UI.UIImageButton uiImageButton10;
        private Sunny.UI.UILabel uiLabel8;
        private Sunny.UI.UIButton DefaultMenuButton;
        private Sunny.UI.UIImageButton SnowMenuButton;
        private Sunny.UI.UIImageButton FallMenuButton;
        private Sunny.UI.UIImageButton SpringMenuButton;
        private Sunny.UI.UIImageButton SummerMenuButton;
        private Sunny.UI.UIImageButton CLoudMenuButton;
        private PictureBox pictureBox1;
        private Sunny.UI.UIImageButton ManageDataButton;
    }
}