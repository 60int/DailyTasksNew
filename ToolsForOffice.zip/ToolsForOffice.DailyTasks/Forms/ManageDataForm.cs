﻿using Sunny.UI;

namespace ToolsForOffice.DailyTasks.Forms
{
    public partial class ManageDataForm : UIForm
    {
        public ManageDataForm()
        {
            InitializeComponent();
            pictureBox1.BackColor = Color.White;
            uiLabel1.BackColor = Color.White;
            uiLabel2.BackColor = Color.White;
            uiLabel3.BackColor = Color.White;
            uiLabel4.BackColor = Color.White;
            FolderLabel.BackColor = Color.White;
            FolderNameLabel.BackColor = Color.White;
        }

        private void ManageDataButton_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
