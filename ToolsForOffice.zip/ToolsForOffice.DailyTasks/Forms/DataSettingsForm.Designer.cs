﻿namespace ToolsForOffice.DailyTasks.Forms
{
    partial class DataSettingsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            SuspendLayout();
            // 
            // DataSettingsForm
            // 
            AllowShowTitle = false;
            AutoScaleMode = AutoScaleMode.None;
            BackColor = Color.White;
            ClientSize = new Size(800, 450);
            ControlBoxFillHoverColor = Color.FromArgb(109, 109, 103);
            Name = "DataSettingsForm";
            Padding = new Padding(0);
            RectColor = Color.FromArgb(48, 48, 48);
            ShowTitle = false;
            Style = Sunny.UI.UIStyle.Custom;
            Text = "DataSettingsForm";
            TitleColor = Color.FromArgb(48, 48, 48);
            ZoomScaleRect = new Rectangle(15, 15, 800, 450);
            ResumeLayout(false);
        }

        #endregion
    }
}