﻿using Sunny.UI;

namespace ToolsForOffice.DailyTasks.Forms
{
    public partial class EdiUserForm : UIForm
    {
        public EdiUserForm()
        {
            InitializeComponent();
        }
    }
}
