using Sunny.UI;
using System.Text;
using System.Text.Json;
using ToolsForOffice.Shared;
using DailyTasks.Forms.Classes;
using ToolsForOffice.CopyClipboard;
using ToolsForOffice.ScreenshotShare;
using ToolsForOffice.DailyTasks.Forms;

namespace ToolsForOffice.DailyTasks
{
    public partial class MainForm : UIForm
    {
        #region Fields and Properties

        FileSystemWatcher watcher = new();

        private Form activeForm = null!;

        private readonly CancellationTokenSource cts = new();

        readonly string MainFolder = $"Daily Tasks/";
        readonly string SettingsFolder = $"Daily Tasks/Settings/";
        readonly string ImageFolder = $"Daily Tasks/Images/";
        readonly string ClipboardFile = "Daily Tasks/Settings/CopyClipboard.txt";
        readonly string UsersFile = $"Daily Tasks/Settings/Users.txt";

        private static readonly HttpClient client = new();

        private SelectedTheme? _cachedSelectedTheme;

        #endregion

        public MainForm()
        {
            InitializeComponent();
            InitializeDataGridView();
            ThemeChangedEventManager.ThemeChanged += OnThemeChanged!;
        }

        #region Load Data

        private void MainForm_Load(object sender, EventArgs e)
        {

            try
            {
                CreateDirectories();
                string username = GetUser();
                CurrentUser.Text = username;
                CurrentUserHome.Text = username;
                FadeInLabel(CurrentUserHome, CurrentUserHome.BackColor, Color.Black, 2000);
                FadeInLabel(CurrentUserLabelHome, CurrentUserLabelHome.BackColor, Color.Black, 2000);
                CreateClipboardFile();
                CreateFileSystemWatcher();
                RefreshListBoxAndDataGrid();
                LoadUsers();
                LoadWeatherData();
                LoadTheme();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Application couldn't start" + ex, "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private static string GetUsernameFromFile()
        {
            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string filePath = Path.Combine(desktopPath, "DailyTasks", "DailyTasks-MyUser.txt");
            string username = File.ReadAllText(filePath);
            return username;
        }

        private static string GetUser()
        {
            string username = GetUsernameFromFile();
            return username;
        }

        private static string GetMainFile()
        {
            string username = GetUsernameFromFile();
            return $"Daily Tasks/Daily Tasks - {username}.csv";
        }

        private static string GetFolder()
        {
            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string filePath = Path.Combine(desktopPath, "DailyTasks", "DailyTasks-MyFolder.bin");
            string folderPath;
            using (var binaryReader = new BinaryReader(File.Open(filePath, FileMode.Open)))
            {
                folderPath = binaryReader.ReadString();
            }
            return folderPath + "/";
        }

        private void LoadUsers()
        {
            UsersToolStripMenuItem.DropDownItems.Clear();
            if (File.Exists(UsersFile))
            {
                foreach (User userItem in User.Deserialize(UsersFile))
                {
                    ToolStripItem item = UsersToolStripMenuItem.DropDownItems.Add(userItem.UserName);
                    item.Click += UserItem_Click;
                    if (_cachedSelectedTheme == null)
                    {
                        string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
                        string filePath = Path.Combine(desktopPath, "DailyTasks", "DailyTasks-MenuTheme.bin");
                        _cachedSelectedTheme = SelectedTheme.Load(filePath);
                    }
                    switch (_cachedSelectedTheme.CurrentTheme)
                    {
                        case Theme.Default:
                            item.BackColor = Color.FromArgb(48, 48, 48);
                            item.ForeColor = Color.White;
                            break;
                        case Theme.Cloud:
                            item.BackColor = Color.SteelBlue;
                            item.ForeColor = Color.White;
                            break;
                        case Theme.Summer:
                            item.BackColor = Color.Green;
                            item.ForeColor = Color.White;
                            break;
                        case Theme.Spring:
                            item.BackColor = Color.Pink;
                            item.ForeColor = Color.White;
                            break;
                        case Theme.Fall:
                            item.BackColor = Color.Orange;
                            item.ForeColor = Color.White;
                            break;
                        case Theme.Snow:
                            item.BackColor = Color.LightSteelBlue;
                            item.ForeColor = Color.White;
                            break;
                        default:
                            break;
                    }
                }
            }
            else
            {
                switch (MessageBox.Show("Users file is corrupted or doesn't exist! Do you want to create a new one?", "Error", MessageBoxButtons.YesNo, MessageBoxIcon.Information))
                {
                    case DialogResult.Yes:
                        using (FileStream fs = File.Create(UsersFile))
                        {
                            char[] value = "Default\n".ToCharArray();
                            fs.Write(Encoding.UTF8.GetBytes(value), 0, value.Length);
                        }
                        MessageBox.Show("File created!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        break;
                    case DialogResult.Cancel:
                        Environment.Exit(0);
                        break;
                    case DialogResult.No:
                        Environment.Exit(0);
                        break;
                }
            }
        }

        List<DailyTask> LoadDataFromCsvFiles()
        {
            List<DailyTask> allTasks = new();

            if (CurrentUser.Text == "Default")
            {
                string[] filePaths = Directory.GetFiles(MainFolder, "*.csv");

                foreach (string filePath in filePaths)
                {
                    allTasks.AddRange(DailyTask.Deserialize(filePath));
                }
            }
            else
            {
                string mainFile = GetMainFile();
                if (!File.Exists(mainFile))
                {
                    using FileStream fs = File.Create(mainFile);
                }

                allTasks.AddRange(DailyTask.Deserialize(mainFile));
            }

            return allTasks;
        }

        private void LoadWeatherData()
        {
            string apiKey = "21d566ff98366dd488938f59cf6d1376";
            string city = "Budapest";
            string url = $"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={apiKey}&units=metric";

            try
            {
                HttpResponseMessage response = client.GetAsync(url).Result;
                response.EnsureSuccessStatusCode();
                string json = response.Content.ReadAsStringAsync().Result;

                using JsonDocument doc = JsonDocument.Parse(json);
                JsonElement root = doc.RootElement;
                double temperature = root.GetProperty("main").GetProperty("temp").GetDouble();
                string conditions = root.GetProperty("weather")[0].GetProperty("main").GetString()!;
                LocationLabel.Text = city;
                ConditionsLabel.Text = conditions;
                CelsiusLabel.Text = $"{temperature}��C";
                FadeInLabel(LocationLabel, LocationLabel.BackColor, Color.Black, 2000);
                FadeInLabel(ConditionsLabel, ConditionsLabel.BackColor, Color.Black, 2000);
                FadeInLabel(CelsiusLabel, CelsiusLabel.BackColor, Color.Black, 2000);
            }
            catch (HttpRequestException)
            {
                ConditionsLabel.Text = "Weather data is not available";
                CelsiusLabel.Text = "";
            }
            catch (JsonException)
            {
                ConditionsLabel.Text = "Weather data is not available";
                CelsiusLabel.Text = "";
            }
        }

        #endregion

        #region Display Data

        void InitializeDataGridView()
        {
            string[] customValueNames = Classes.Utils.GetCustomValueNames();

            MainDataGridView.AutoGenerateColumns = false;
            MainDataGridView.Columns.Add("Day of the Week", "Day Of Week");
            MainDataGridView.Columns.Add("Title", "User");
            MainDataGridView.Columns.Add("TotalSum", "Total Sum");
            MainDataGridView.Columns.Add(customValueNames[2], customValueNames[2]);
            MainDataGridView.Columns.Add("TotalOK", "Total OK");
            MainDataGridView.Columns.Add("TotalNG", "Total NG");
            MainDataGridView.Columns.Add("Task Type", "TaskType");
        }

        private void CreateFileSystemWatcher()
        {
            watcher = new FileSystemWatcher
            {
                Path = GetFolder(),
                NotifyFilter = NotifyFilters.FileName | NotifyFilters.Size,
                Filter = "*.jpg"
            };
            watcher.Created += new FileSystemEventHandler(OnImageCreated);
            watcher.EnableRaisingEvents = true;
        }

        private void CreateDirectories()
        {
            try
            {
                string[] directories = { MainFolder, ImageFolder, SettingsFolder };
                foreach (string directory in directories)
                {
                    if (!Directory.Exists(directory))
                    {
                        Directory.CreateDirectory(directory);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while creating directories: " + ex.Message);
            }
        }

        private void CreateClipboardFile()
        {
            if (!File.Exists(ClipboardFile))
            {
                StringBuilder sb = new();
                for (int i = 1; i <= 8; i++)
                {
                    sb.Append($"Drop Down item {i}");
                    for (int j = 1; j <= 8; j++)
                    {
                        sb.Append($",New Item (column {j}/{i})");
                    }
                    sb.AppendLine();
                }

                using StreamWriter writer = new(ClipboardFile, false, Encoding.UTF8);
                writer.Write(sb.ToString());
            }
        }

        #endregion

        void RefreshListBoxAndDataGrid(bool showCurrentWeekOnly = true)
        {
            string[] customValueNames = Classes.Utils.GetCustomValueNames();

            MainListBox.Items.Clear();
            MainDataGridView.Rows.Clear();

            List<DailyTask> allTasks = LoadDataFromCsvFiles();

            // Calculate total sum, not finished, total OK and total NG by title
            var totalSumByTitle = DailyTask.TotalSumByTitle(allTasks.ToArray());
            var notFinishedByTitle = DailyTask.NotFinishedByTitle(allTasks.ToArray());
            var totalOKByTitle = DailyTask.TotalOKByTitle(allTasks.ToArray());
            var totalNGByTitle = DailyTask.TotalNGByTitle(allTasks.ToArray());

            // Group tasks by date and title
            var tasksGroupedByDateAndTitle = allTasks.GroupBy(t => new { t.StartTime!.Value.Date, t.Title });

            // Calculate start and end dates of current week
            DateTime startOfWeek = DateTime.Today.AddDays(-(int)DateTime.Today.DayOfWeek);
            DateTime endOfWeek = startOfWeek.AddDays(7);

            // Add a row for each group
            foreach (var group in tasksGroupedByDateAndTitle.OrderBy(g => g.Key.Date))
            {
                // Check if StartTime is within current week
                if (!showCurrentWeekOnly || (group.Key.Date >= startOfWeek && group.Key.Date < endOfWeek))
                {
                    string date = group.Key.Date.ToString("d");
                    string title = group.Key.Title!;
                    int totalSum = group.Sum(t => t.TotalAmount) ?? 0;
                    int notFinished = group.Sum(t => t.CustomValue3) ?? 0;
                    int totalOK = group.Sum(t => t.TotalAmount - (t.CustomValue1 + t.CustomValue2)) ?? 0;
                    int totalNG = group.Sum(t => t.CustomValue1 + t.CustomValue2) ?? 0;
                    string taskType = group.First().TaskType!.ToString(); // Change TaskType.ToString() to TaskType

                    MainDataGridView.Rows.Add(date, title, totalSum, notFinished, totalOK, totalNG, taskType);
                }
            }
            foreach (DailyTask item in allTasks.OrderByDescending(task => task.StartTime))
            {
                MainListBox.Items.Add(item);
            }
        }

        void SaveChanges()
        {
            DailyTask[] tasks = new DailyTask[MainListBox.Items.Count];
            int i = 0;
            foreach (DailyTask item in MainListBox.Items)
            {
                tasks[i] = item;
                i++;
            }
            string mainFile = GetMainFile();
            if (!File.Exists(mainFile))
            {
                using FileStream fs = File.Create(mainFile);
            }
            DailyTask.Serialize(mainFile, tasks);
        }

        #region Custom Events

        private void NewUserToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddUserForm form = new();
            if (form.ShowDialog() == DialogResult.OK)
            {
                ToolStripItem newUserItem = new ToolStripMenuItem(form.User!.UserName);

                newUserItem.Click += UserItem_Click;

                UsersToolStripMenuItem.DropDownItems.Add(newUserItem);

                newUserItem.BackColor = Color.FromArgb(48, 48, 48);

                newUserItem.ForeColor = Color.White;

                using StreamWriter writer = new(UsersFile, true, Encoding.UTF8);

                writer.WriteLine(form.User.CSVFormat());

                MessageBox.Show("New User added!", "Success");
            }
        }

        private void UserItem_Click(object? sender, EventArgs e)
        {
            CurrentUser.Text = (sender! as ToolStripItem)!.Text;
            CurrentUserHome.Text = (sender! as ToolStripItem)!.Text;

            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string filePath = Path.Combine(desktopPath, "DailyTasks", "DailyTasks-MyUser.txt");
            File.WriteAllText(filePath, CurrentUser.Text);
            RefreshListBoxAndDataGrid();
        }

        private void MainDateTimePicker_ValueChanged(object sender, EventArgs e)
        {
            // Get custom value names
            string[] customValueNames = Classes.Utils.GetCustomValueNames();

            // Get the selected date
            DateTime selectedDate = MainDateTimePicker.Value;

            MainListBox.Items.Clear();
            MainDataGridView.Rows.Clear();

            // Load data from CSV files
            List<DailyTask> allTasks = LoadDataFromCsvFiles();

            var totalSumByTitle = DailyTask.TotalSumByTitle(allTasks.ToArray());
            var notFinishedByTitle = DailyTask.NotFinishedByTitle(allTasks.ToArray());
            var totalOKByTitle = DailyTask.TotalOKByTitle(allTasks.ToArray());
            var totalNGByTitle = DailyTask.TotalNGByTitle(allTasks.ToArray());

            // Filter tasks by selected date
            var tasksBySelectedDate = allTasks.Where(t => t.StartTime.HasValue && t.StartTime.Value.Date == selectedDate.Date);

            // Group tasks by date and title
            var tasksGroupedByDateAndTitle = tasksBySelectedDate.GroupBy(t => new { t.StartTime!.Value.Date, t.Title });

            // Add a row for each group
            foreach (var group in tasksGroupedByDateAndTitle)
            {
                string date = group.Key.Date.ToString("d");
                string title = group.Key.Title!;
                int totalSum = group.Sum(t => t.TotalAmount) ?? 0;
                int notFinished = group.Sum(t => t.CustomValue3) ?? 0;
                int totalOK = group.Sum(t => t.TotalAmount - (t.CustomValue1 + t.CustomValue2)) ?? 0;
                int totalNG = group.Sum(t => t.CustomValue1 + t.CustomValue2) ?? 0;
                string taskType = group.First().TaskType!;

                MainDataGridView.Rows.Add(date, title, totalSum, notFinished, totalOK, totalNG, taskType);
            }

            foreach (DailyTask item in allTasks)
            {
                MainListBox.Items.Add(item);
            }
        }

        #endregion

        #region Main Buttons

        private void ShowAllButton_Click(object sender, EventArgs e)
        {
            RefreshListBoxAndDataGrid(showCurrentWeekOnly: false);
        }

        private void CurrentWeekButton_Click(object sender, EventArgs e)
        {
            RefreshListBoxAndDataGrid(showCurrentWeekOnly: true);
        }

        private void AddTaskButton_Click(object sender, EventArgs e)
        {
            AddTaskForm form = new(ClipboardFile);
            MainDataGridView.BackgroundColor = Color.White;
            if (form.ShowDialog() == DialogResult.OK)
            {
                MainListBox.Items.Add(form.Task!);
                SaveChanges();
                RefreshListBoxAndDataGrid();
            }
            LoadTheme();
        }

        private void UpdateTaskButton_Click(object sender, EventArgs e)
        {
            if (MainListBox.SelectedItem != null)
            {
                AddTaskForm form = new(ClipboardFile)
                {
                    Task = (DailyTask)MainListBox.SelectedItem
                };
                MainDataGridView.BackgroundColor = Color.White;
                if (form.ShowDialog() == DialogResult.OK)
                {
                    MainListBox.Items[MainListBox.SelectedIndex] = MainListBox.SelectedItem!;
                    SaveChanges();
                    RefreshListBoxAndDataGrid();
                }
            }
            LoadTheme();
        }

        private void RemoveTaskButton_Click(object sender, EventArgs e)
        {
            if (MainListBox.SelectedIndex != -1 && MessageBox.Show("Do you want to delete this item?", "Delete item?", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                MainListBox.Items.RemoveAt(MainListBox.SelectedIndex);
                SaveChanges();
                RefreshListBoxAndDataGrid();
            }
            LoadTheme();
        }

        private void MainListBox_DoubleClick(object sender, EventArgs e)
        {
            if (MainListBox.SelectedItem != null)
            {
                AddTaskForm form = new(ClipboardFile)
                {
                    Task = (DailyTask)MainListBox.SelectedItem
                };
                MainDataGridView.BackgroundColor = Color.White;
                if (form.ShowDialog() == DialogResult.OK)
                {
                    MainListBox.Items[MainListBox.SelectedIndex] = MainListBox.SelectedItem!;
                    SaveChanges();
                    RefreshListBoxAndDataGrid();
                }
            }
            LoadTheme();
        }

        private void ClipboardButton_Click(object sender, EventArgs e)
        {
            watcher.EnableRaisingEvents = false;
            CopyClipboardForm Form = new();
            WindowState = FormWindowState.Minimized;
            Form.Owner = this;
            Form.FormClosed += (s, args) =>
            {
                watcher.EnableRaisingEvents = true;
                WindowState = FormWindowState.Normal;
                LoadUsers();
                LoadTheme();
            };
            Form.Show();
        }

        private void ScreenshotShareButton_Click(object sender, EventArgs e)
        {
            watcher.EnableRaisingEvents = false;
            ScreenshotShareForm Form = new();
            WindowState = FormWindowState.Minimized;
            Form.Owner = this;
            Form.FormClosed += (s, args) =>
            {
                watcher.EnableRaisingEvents = true;
                WindowState = FormWindowState.Normal;
                LoadTheme();
            };
            Form.Show();
        }

        private void EditClipboardButton_Click(object sender, EventArgs e)
        {
            OpenChildForm(new EditClipboardForm());
            LoadTheme();
        }

        private void ShareImageTimer_Tick(object sender, EventArgs e)
        {
            ShareImageTimer.Stop();
            ShareImageLabel.Visible = false;
        }

        private void ToolStripMenuItem_DropDownOpened(object sender, EventArgs e)
        {
            ToolStripMenuItem? menuItem = sender as ToolStripMenuItem;
            menuItem!.ForeColor = Color.Black;
        }

        private void ToolStripMenuItem_DropDownClosed(object sender, EventArgs e)
        {
            ToolStripMenuItem? menuItem = sender as ToolStripMenuItem;
            menuItem!.ForeColor = Color.White;
        }

        private void EditValueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            EditValueForm editValueForm = new();
            editValueForm.ShowDialog();
        }

        private void EditTypeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            EditTypeForm editTypeForm = new();
            editTypeForm.ShowDialog();
        }

        private void ManageDataButton_Click(object sender, EventArgs e)
        {
            OpenChildSettingsForm(new ManageDataForm());
            LoadTheme();
        }

        private void CustomUIButton_Click(object sender, EventArgs e)
        {
            OpenChildSettingsForm(new ManageUIForm());
            LoadTheme();
        }

        #endregion

        #region Visuals / Animations

        private void OpenChildForm(Form childForm)
        {
            activeForm?.Close();
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            ToolsPage.Controls.Add(childForm);
            childForm.BringToFront();
            childForm.Show();
        }

        private void OpenChildSettingsForm(Form childForm)
        {
            activeForm?.Close();
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            SettingsPage.Controls.Add(childForm);
            childForm.BringToFront();
            childForm.Show();
        }

        private void OnThemeChanged(object sender, ThemeChangedEventArgs e)
        {
            _cachedSelectedTheme = null;
        }

        private void LoadTheme()
        {
            if (_cachedSelectedTheme == null)
            {
                string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
                string filePath = Path.Combine(desktopPath, "DailyTasks", "DailyTasks-MenuTheme.bin");
                _cachedSelectedTheme = SelectedTheme.Load(filePath);
            }

            switch (_cachedSelectedTheme.CurrentTheme)
            {
                case Theme.Cloud:
                    UIStyles.InitColorful(Color.SteelBlue, Color.White);
                    MainTabControl.TabBackColor = Color.SteelBlue;
                    MainTabControl.TabSelectedColor = Color.SteelBlue;
                    MainTabControl.TabSelectedForeColor = Color.White;
                    MainTabControl.TabSelectedHighColor = Color.White;
                    MainTabControl.TabUnSelectedForeColor = Color.White;
                    MainMenuStrip!.BackColor = Color.SteelBlue;
                    HomeMenuStrip.BackColor = Color.SteelBlue;
                    ToolsMenuStrip.BackColor = Color.SteelBlue;
                    TasksMenuStrip.BackColor = Color.SteelBlue;
                    SettingsMenuStrip.BackColor = Color.SteelBlue;
                    NewUserToolStripMenuItem.BackColor = Color.SteelBlue;
                    UsersToolStripMenuItem.BackColor = Color.SteelBlue;
                    ExitToolStripMenuItem.BackColor = Color.SteelBlue;
                    EditValueToolStripMenuItem.BackColor = Color.SteelBlue;
                    EditTypeToolStripMenuItem.BackColor = Color.SteelBlue;
                    break;
                case Theme.Summer:
                    UIStyles.InitColorful(Color.Green, Color.White);
                    MainTabControl.TabBackColor = Color.Green;
                    MainTabControl.TabSelectedColor = Color.Green;
                    MainTabControl.TabSelectedForeColor = Color.White;
                    MainTabControl.TabSelectedHighColor = Color.White;
                    MainTabControl.TabUnSelectedForeColor = Color.White;
                    MainMenuStrip!.BackColor = Color.Green;
                    HomeMenuStrip.BackColor = Color.Green;
                    ToolsMenuStrip.BackColor = Color.Green;
                    TasksMenuStrip.BackColor = Color.Green;
                    SettingsMenuStrip.BackColor = Color.Green;
                    NewUserToolStripMenuItem.BackColor = Color.Green;
                    UsersToolStripMenuItem.BackColor = Color.Green;
                    ExitToolStripMenuItem.BackColor = Color.Green;
                    EditValueToolStripMenuItem.BackColor = Color.Green;
                    EditTypeToolStripMenuItem.BackColor = Color.Green;
                    break;
                case Theme.Spring:
                    UIStyles.InitColorful(Color.LightPink, Color.Black);
                    MainTabControl.TabBackColor = Color.LightPink;
                    MainTabControl.TabSelectedColor = Color.LightPink;
                    MainTabControl.TabSelectedForeColor = Color.Black;
                    MainTabControl.TabSelectedHighColor = Color.Black;
                    MainTabControl.TabUnSelectedForeColor = Color.Black;
                    MainMenuStrip!.BackColor = Color.LightPink;
                    HomeMenuStrip.BackColor = Color.LightPink;
                    ToolsMenuStrip.BackColor = Color.LightPink;
                    TasksMenuStrip.BackColor = Color.Pink;
                    SettingsMenuStrip.BackColor = Color.Pink;
                    NewUserToolStripMenuItem.BackColor = Color.Pink;
                    UsersToolStripMenuItem.BackColor = Color.Pink;
                    ExitToolStripMenuItem.BackColor = Color.Pink;
                    EditValueToolStripMenuItem.BackColor = Color.Pink;
                    EditTypeToolStripMenuItem.BackColor = Color.Pink;
                    break;
                case Theme.Fall:
                    UIStyles.InitColorful(Color.Orange, Color.Black);
                    MainTabControl.TabBackColor = Color.Orange;
                    MainTabControl.TabSelectedColor = Color.Orange;
                    MainTabControl.TabSelectedForeColor = Color.Black;
                    MainTabControl.TabSelectedHighColor = Color.Black;
                    MainTabControl.TabUnSelectedForeColor = Color.Black;
                    MainMenuStrip!.BackColor = Color.Orange;
                    HomeMenuStrip.BackColor = Color.Orange;
                    ToolsMenuStrip.BackColor = Color.Orange;
                    TasksMenuStrip.BackColor = Color.Orange;
                    SettingsMenuStrip.BackColor = Color.Orange;
                    NewUserToolStripMenuItem.BackColor = Color.Orange;
                    UsersToolStripMenuItem.BackColor = Color.Orange;
                    ExitToolStripMenuItem.BackColor = Color.Orange;
                    EditValueToolStripMenuItem.BackColor = Color.Orange;
                    EditTypeToolStripMenuItem.BackColor = Color.Orange;
                    break;
                case Theme.Snow:
                    UIStyles.InitColorful(Color.LightSteelBlue, Color.White);
                    MainTabControl.TabBackColor = Color.LightSteelBlue;
                    MainTabControl.TabSelectedColor = Color.LightSteelBlue;
                    MainTabControl.TabSelectedForeColor = Color.White;
                    MainTabControl.TabSelectedHighColor = Color.White;
                    MainTabControl.TabUnSelectedForeColor = Color.White;
                    MainMenuStrip!.BackColor = Color.LightSteelBlue;
                    HomeMenuStrip.BackColor = Color.LightSteelBlue;
                    ToolsMenuStrip.BackColor = Color.LightSteelBlue;
                    TasksMenuStrip.BackColor = Color.LightSteelBlue;
                    SettingsMenuStrip.BackColor = Color.LightSteelBlue;
                    NewUserToolStripMenuItem.BackColor = Color.LightSteelBlue;
                    UsersToolStripMenuItem.BackColor = Color.LightSteelBlue;
                    ExitToolStripMenuItem.BackColor = Color.LightSteelBlue;
                    EditValueToolStripMenuItem.BackColor = Color.LightSteelBlue;
                    EditTypeToolStripMenuItem.BackColor = Color.LightSteelBlue;
                    break;
                case Theme.Default:
                    UIStyles.InitColorful(Color.FromArgb(48,48,48), Color.White);
                    MainTabControl.TabBackColor = Color.FromArgb(48, 48, 48);
                    MainTabControl.TabSelectedColor = Color.FromArgb(48, 48, 48);
                    MainTabControl.TabSelectedForeColor = Color.White;
                    MainTabControl.TabSelectedHighColor = Color.White;
                    MainTabControl.TabUnSelectedForeColor = Color.White;
                    MainMenuStrip!.BackColor = Color.FromArgb(48, 48, 48);
                    HomeMenuStrip.BackColor = Color.FromArgb(48, 48, 48);
                    ToolsMenuStrip.BackColor = Color.FromArgb(48, 48, 48);
                    TasksMenuStrip.BackColor = Color.FromArgb(48, 48, 48);
                    SettingsMenuStrip.BackColor = Color.FromArgb(48, 48, 48);
                    break;
            }
        }

        private static void FadeInLabel(Label label, Color startColor, Color endColor, int duration)
        {
            var timer = new System.Windows.Forms.Timer();
            int elapsed = 0;
            timer.Interval = 10;
            timer.Tick += (s, e) =>
            {
                elapsed += timer.Interval;
                float progress = (float)elapsed / duration;
                if (progress >= 1)
                {
                    progress = 1;
                    timer.Stop();
                }
                int r = (int)(startColor.R + (endColor.R - startColor.R) * progress);
                int g = (int)(startColor.G + (endColor.G - startColor.G) * progress);
                int b = (int)(startColor.B + (endColor.B - startColor.B) * progress);
                label.ForeColor = Color.FromArgb(r, g, b);
            };
            timer.Start();
        }

        #endregion

        #region Share Image Function

        private delegate void UpdateImageDelegate(string notification);

        private void ImageAlert(string notification)
        {
            if (InvokeRequired)
            {
                BeginInvoke(new UpdateImageDelegate(ImageAlert), new object[] { notification });
                return;
            }
            Notification.Classes.Notification.ShowInformation(notification, 5000);
        }

        private async void OnImageCreated(object sender, FileSystemEventArgs e)
        {
            try
            {
                watcher.EnableRaisingEvents = false;
                await ProcessAsync(cts.Token);
            }
            finally
            {
                watcher.EnableRaisingEvents = true;
            }
        }

        public static FileInfo GetNewestFile(DirectoryInfo directory)
        {
            return directory.GetFiles()
                .OrderByDescending(f => f.LastWriteTime)
                .FirstOrDefault()!;
        }

        private async Task ProcessAsync(CancellationToken cancellationToken)
        {
            FileInfo newestFile = GetNewestFile(new DirectoryInfo(GetFolder()));
            if (!File.Exists(newestFile.FullName))
            {
                return;
            }
            string alert = $"{newestFile.Name.Split(" - ").FirstOrDefault()!} sent an image";
            await Task.Run(() => ImageAlert(alert), cancellationToken);
        }

        private void ShareScreenshotButton_Click(object sender, EventArgs e)
        {
            if (Clipboard.GetDataObject() is IDataObject data && data.GetDataPresent(DataFormats.Bitmap))
            {
                if (data.GetData(DataFormats.Bitmap, true) is Image image)
                {
                    using Bitmap bm = new(image);
                    StringBuilder fileNameBuilder = new();
                    fileNameBuilder.Append(GetFolder());
                    fileNameBuilder.Append(CurrentUser.Text);
                    fileNameBuilder.Append(" - ");
                    fileNameBuilder.Append(DateTime.Now.ToString("MMdd-HH-mm-ss"));
                    fileNameBuilder.Append(".jpg");

                    using var fileStream = new FileStream(fileNameBuilder.ToString(), FileMode.Create);
                    using var bufferedStream = new BufferedStream(fileStream);
                    bm.Save(bufferedStream, System.Drawing.Imaging.ImageFormat.Jpeg);

                    ShareImageTimer.Start();
                    ShareImageLabel.Text = "Image saved!";
                    ShareImageLabel.Visible = true;
                    ShowInfoTip("Image captured and saved!");
                }
            }
            else
            {
                ShareImageTimer.Start();
                ShareImageLabel.Text = "Error";
                ShareImageLabel.Visible = true;
                ShowErrorTip("The Data In Clipboard is not in image format!");
            }
        }

        #endregion

    }
}