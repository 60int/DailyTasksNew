﻿namespace ToolsForOffice.CopyClipboard
{
    partial class CopyClipboardForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CopyClipboardForm));
            MainPictureBox = new PictureBox();
            MainComboBox = new ComboBox();
            SkinsButton = new Button();
            MainListBox = new ListBox();
            CloudButton = new Button();
            SummerButton = new Button();
            SpringButton = new Button();
            FallButton = new Button();
            SnowButton = new Button();
            CancelButton = new Button();
            MainLabel = new Label();
            CopyLabel = new Label();
            CopyTimer = new System.Windows.Forms.Timer(components);
            TimerUpdate = new System.Windows.Forms.Timer(components);
            CameraButton = new Button();
            ShareImageLabel = new Label();
            ((System.ComponentModel.ISupportInitialize)MainPictureBox).BeginInit();
            SuspendLayout();
            // 
            // MainPictureBox
            // 
            MainPictureBox.Dock = DockStyle.Fill;
            MainPictureBox.Location = new Point(0, 0);
            MainPictureBox.Margin = new Padding(0);
            MainPictureBox.Name = "MainPictureBox";
            MainPictureBox.Size = new Size(195, 200);
            MainPictureBox.TabIndex = 0;
            MainPictureBox.TabStop = false;
            MainPictureBox.Paint += MainPictureBox_Paint;
            // 
            // MainComboBox
            // 
            MainComboBox.FormattingEnabled = true;
            MainComboBox.Location = new Point(12, 12);
            MainComboBox.Name = "MainComboBox";
            MainComboBox.Size = new Size(155, 23);
            MainComboBox.TabIndex = 1;
            MainComboBox.SelectedIndexChanged += MainComboBox_SelectedIndexChanged;
            // 
            // SkinsButton
            // 
            SkinsButton.Cursor = Cursors.Hand;
            SkinsButton.FlatStyle = FlatStyle.Flat;
            SkinsButton.Location = new Point(173, 12);
            SkinsButton.Name = "SkinsButton";
            SkinsButton.Size = new Size(10, 23);
            SkinsButton.TabIndex = 2;
            SkinsButton.UseVisualStyleBackColor = true;
            SkinsButton.Click += SkinsButton_Click;
            // 
            // MainListBox
            // 
            MainListBox.FormattingEnabled = true;
            MainListBox.ItemHeight = 15;
            MainListBox.Location = new Point(12, 41);
            MainListBox.Name = "MainListBox";
            MainListBox.Size = new Size(171, 124);
            MainListBox.TabIndex = 3;
            MainListBox.Click += MainListBox_Click;
            MainListBox.SelectedIndexChanged += MainListBox_SelectedIndexChanged;
            // 
            // CloudButton
            // 
            CloudButton.BackColor = Color.SkyBlue;
            CloudButton.Cursor = Cursors.Hand;
            CloudButton.FlatStyle = FlatStyle.Flat;
            CloudButton.Location = new Point(12, 171);
            CloudButton.Name = "CloudButton";
            CloudButton.Size = new Size(10, 23);
            CloudButton.TabIndex = 4;
            CloudButton.UseVisualStyleBackColor = false;
            CloudButton.Click += CloudButton_Click;
            // 
            // SummerButton
            // 
            SummerButton.BackColor = Color.Green;
            SummerButton.Cursor = Cursors.Hand;
            SummerButton.FlatStyle = FlatStyle.Flat;
            SummerButton.Location = new Point(28, 171);
            SummerButton.Name = "SummerButton";
            SummerButton.Size = new Size(10, 23);
            SummerButton.TabIndex = 5;
            SummerButton.UseVisualStyleBackColor = false;
            SummerButton.Click += SummerButton_Click;
            // 
            // SpringButton
            // 
            SpringButton.BackColor = Color.Pink;
            SpringButton.Cursor = Cursors.Hand;
            SpringButton.FlatStyle = FlatStyle.Flat;
            SpringButton.Location = new Point(44, 171);
            SpringButton.Name = "SpringButton";
            SpringButton.Size = new Size(10, 23);
            SpringButton.TabIndex = 6;
            SpringButton.UseVisualStyleBackColor = false;
            SpringButton.Click += SpringButton_Click;
            // 
            // FallButton
            // 
            FallButton.BackColor = Color.Orange;
            FallButton.Cursor = Cursors.Hand;
            FallButton.FlatStyle = FlatStyle.Flat;
            FallButton.Location = new Point(60, 171);
            FallButton.Name = "FallButton";
            FallButton.Size = new Size(10, 23);
            FallButton.TabIndex = 7;
            FallButton.UseVisualStyleBackColor = false;
            FallButton.Click += FallButton_Click;
            // 
            // SnowButton
            // 
            SnowButton.Cursor = Cursors.Hand;
            SnowButton.FlatStyle = FlatStyle.Flat;
            SnowButton.Location = new Point(76, 171);
            SnowButton.Name = "SnowButton";
            SnowButton.Size = new Size(10, 23);
            SnowButton.TabIndex = 8;
            SnowButton.UseVisualStyleBackColor = true;
            SnowButton.Click += SnowButton_Click;
            // 
            // CancelButton
            // 
            CancelButton.Cursor = Cursors.Hand;
            CancelButton.FlatStyle = FlatStyle.Flat;
            CancelButton.Location = new Point(108, 171);
            CancelButton.Name = "CancelButton";
            CancelButton.Size = new Size(75, 23);
            CancelButton.TabIndex = 9;
            CancelButton.Text = "Cancel";
            CancelButton.UseVisualStyleBackColor = true;
            CancelButton.Click += CancelButton_Click;
            // 
            // MainLabel
            // 
            MainLabel.BackColor = Color.White;
            MainLabel.Location = new Point(12, 165);
            MainLabel.Name = "MainLabel";
            MainLabel.Size = new Size(171, 18);
            MainLabel.TabIndex = 10;
            MainLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // CopyLabel
            // 
            CopyLabel.AutoSize = true;
            CopyLabel.Location = new Point(76, 183);
            CopyLabel.Name = "CopyLabel";
            CopyLabel.Size = new Size(46, 15);
            CopyLabel.TabIndex = 11;
            CopyLabel.Text = "copied!";
            // 
            // CopyTimer
            // 
            CopyTimer.Tick += CopyTimer_Tick;
            // 
            // TimerUpdate
            // 
            TimerUpdate.Enabled = true;
            TimerUpdate.Interval = 30;
            TimerUpdate.Tick += TimerUpdate_Tick;
            // 
            // CameraButton
            // 
            CameraButton.BackColor = Color.Transparent;
            CameraButton.BackgroundImage = Properties.Resources.Camera_Icon;
            CameraButton.BackgroundImageLayout = ImageLayout.Center;
            CameraButton.Cursor = Cursors.Hand;
            CameraButton.FlatStyle = FlatStyle.Flat;
            CameraButton.ForeColor = SystemColors.ButtonHighlight;
            CameraButton.Location = new Point(161, 144);
            CameraButton.Name = "CameraButton";
            CameraButton.Size = new Size(20, 20);
            CameraButton.TabIndex = 12;
            CameraButton.UseVisualStyleBackColor = false;
            CameraButton.Click += CameraButton_Click;
            // 
            // ShareImageLabel
            // 
            ShareImageLabel.AutoSize = true;
            ShareImageLabel.Location = new Point(76, 183);
            ShareImageLabel.Name = "ShareImageLabel";
            ShareImageLabel.Size = new Size(0, 15);
            ShareImageLabel.TabIndex = 13;
            // 
            // CopyClipboardForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(195, 200);
            Controls.Add(ShareImageLabel);
            Controls.Add(CameraButton);
            Controls.Add(CopyLabel);
            Controls.Add(MainLabel);
            Controls.Add(CancelButton);
            Controls.Add(SnowButton);
            Controls.Add(FallButton);
            Controls.Add(SpringButton);
            Controls.Add(SummerButton);
            Controls.Add(CloudButton);
            Controls.Add(MainListBox);
            Controls.Add(SkinsButton);
            Controls.Add(MainComboBox);
            Controls.Add(MainPictureBox);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            Name = "CopyClipboardForm";
            StartPosition = FormStartPosition.CenterScreen;
            ((System.ComponentModel.ISupportInitialize)MainPictureBox).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox MainPictureBox;
        private ComboBox MainComboBox;
        private Button SkinsButton;
        private ListBox MainListBox;
        private Button CloudButton;
        private Button SummerButton;
        private Button SpringButton;
        private Button FallButton;
        private Button SnowButton;
        private Button CancelButton;
        private Label MainLabel;
        private Label CopyLabel;
        private System.Windows.Forms.Timer CopyTimer;
        private System.Windows.Forms.Timer TimerUpdate;
        private Button CameraButton;
        private Label ShareImageLabel;
    }
}