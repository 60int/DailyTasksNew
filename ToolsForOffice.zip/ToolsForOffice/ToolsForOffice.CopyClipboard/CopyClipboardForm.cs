namespace ToolsForOffice.CopyClipboard
{
    public partial class CopyClipboardForm : Form
    {
        public CopyClipboardForm()
        {
            InitializeComponent();
        }
    }
}