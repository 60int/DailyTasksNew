namespace ToolsForOffice.ShareScreenshot
{
    public partial class ShareScreenshotForm : Form
    {
        public ShareScreenshotForm()
        {
            InitializeComponent();
        }
    }
}