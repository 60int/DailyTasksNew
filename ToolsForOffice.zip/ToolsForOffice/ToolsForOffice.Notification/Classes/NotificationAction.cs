﻿namespace ToolsForOffice.Notification.Classes
{
    public enum NotificationAction
    {
        Start,
        Wait,
        Close
    }
}
