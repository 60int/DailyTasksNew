﻿namespace ToolsForOffice.Notification.Classes
{
    public enum NotificationType
    {
        Success,
        Information
    }
}
