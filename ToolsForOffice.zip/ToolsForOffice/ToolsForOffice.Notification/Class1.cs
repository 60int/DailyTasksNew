﻿namespace ToolsForOffice.Notification
{
    public class Class1
    {

    }
}