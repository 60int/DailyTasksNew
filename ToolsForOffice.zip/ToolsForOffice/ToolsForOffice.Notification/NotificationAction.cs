﻿namespace ToolsForOffice.Notification
{
    public enum NotificationAction
    {
        Start,
        Wait,
        Close
    }
}
