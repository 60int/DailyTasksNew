﻿using Sunny.UI;

namespace ToolsForOffice.DailyTasks.Forms
{
    public partial class EditValueForm : UIForm
    {
        public EditValueForm()
        {
            InitializeComponent();
        }
    }
}
