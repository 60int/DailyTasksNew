﻿namespace ToolsForOffice.DailyTasks.Forms
{
    partial class EditValueForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            CancelButton = new Sunny.UI.UIButton();
            AddButton = new Sunny.UI.UIButton();
            ValueTextBox1 = new Sunny.UI.UITextBox();
            ValueTextBox2 = new Sunny.UI.UITextBox();
            ValueTextBox3 = new Sunny.UI.UITextBox();
            ValueTextBox4 = new Sunny.UI.UITextBox();
            SuspendLayout();
            // 
            // CancelButton
            // 
            CancelButton.FillColor = Color.FromArgb(62, 81, 181);
            CancelButton.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            CancelButton.Location = new Point(123, 223);
            CancelButton.MinimumSize = new Size(1, 1);
            CancelButton.Name = "CancelButton";
            CancelButton.Size = new Size(100, 35);
            CancelButton.Style = Sunny.UI.UIStyle.Custom;
            CancelButton.TabIndex = 7;
            CancelButton.Text = "Cancel";
            // 
            // AddButton
            // 
            AddButton.FillColor = Color.FromArgb(62, 81, 181);
            AddButton.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            AddButton.Location = new Point(17, 223);
            AddButton.MinimumSize = new Size(1, 1);
            AddButton.Name = "AddButton";
            AddButton.Size = new Size(100, 35);
            AddButton.Style = Sunny.UI.UIStyle.Custom;
            AddButton.TabIndex = 6;
            AddButton.Text = "OK";
            // 
            // ValueTextBox1
            // 
            ValueTextBox1.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            ValueTextBox1.Location = new Point(17, 52);
            ValueTextBox1.Margin = new Padding(4, 5, 4, 5);
            ValueTextBox1.MinimumSize = new Size(1, 16);
            ValueTextBox1.Name = "ValueTextBox1";
            ValueTextBox1.Padding = new Padding(5);
            ValueTextBox1.RectColor = Color.FromArgb(62, 81, 181);
            ValueTextBox1.ShowText = false;
            ValueTextBox1.Size = new Size(206, 29);
            ValueTextBox1.Style = Sunny.UI.UIStyle.Custom;
            ValueTextBox1.TabIndex = 5;
            ValueTextBox1.Text = "Value 1";
            ValueTextBox1.TextAlignment = ContentAlignment.MiddleLeft;
            ValueTextBox1.Watermark = "";
            // 
            // ValueTextBox2
            // 
            ValueTextBox2.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            ValueTextBox2.Location = new Point(17, 91);
            ValueTextBox2.Margin = new Padding(4, 5, 4, 5);
            ValueTextBox2.MinimumSize = new Size(1, 16);
            ValueTextBox2.Name = "ValueTextBox2";
            ValueTextBox2.Padding = new Padding(5);
            ValueTextBox2.RectColor = Color.FromArgb(62, 81, 181);
            ValueTextBox2.ShowText = false;
            ValueTextBox2.Size = new Size(206, 29);
            ValueTextBox2.Style = Sunny.UI.UIStyle.Custom;
            ValueTextBox2.TabIndex = 8;
            ValueTextBox2.Text = "Value 2";
            ValueTextBox2.TextAlignment = ContentAlignment.MiddleLeft;
            ValueTextBox2.Watermark = "";
            // 
            // ValueTextBox3
            // 
            ValueTextBox3.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            ValueTextBox3.Location = new Point(17, 130);
            ValueTextBox3.Margin = new Padding(4, 5, 4, 5);
            ValueTextBox3.MinimumSize = new Size(1, 16);
            ValueTextBox3.Name = "ValueTextBox3";
            ValueTextBox3.Padding = new Padding(5);
            ValueTextBox3.RectColor = Color.FromArgb(62, 81, 181);
            ValueTextBox3.ShowText = false;
            ValueTextBox3.Size = new Size(206, 29);
            ValueTextBox3.Style = Sunny.UI.UIStyle.Custom;
            ValueTextBox3.TabIndex = 9;
            ValueTextBox3.Text = "Value 3";
            ValueTextBox3.TextAlignment = ContentAlignment.MiddleLeft;
            ValueTextBox3.Watermark = "";
            // 
            // ValueTextBox4
            // 
            ValueTextBox4.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            ValueTextBox4.Location = new Point(17, 169);
            ValueTextBox4.Margin = new Padding(4, 5, 4, 5);
            ValueTextBox4.MinimumSize = new Size(1, 16);
            ValueTextBox4.Name = "ValueTextBox4";
            ValueTextBox4.Padding = new Padding(5);
            ValueTextBox4.RectColor = Color.FromArgb(62, 81, 181);
            ValueTextBox4.ShowText = false;
            ValueTextBox4.Size = new Size(206, 29);
            ValueTextBox4.Style = Sunny.UI.UIStyle.Custom;
            ValueTextBox4.TabIndex = 10;
            ValueTextBox4.Text = "Value 4";
            ValueTextBox4.TextAlignment = ContentAlignment.MiddleLeft;
            ValueTextBox4.Watermark = "";
            // 
            // EditValueForm
            // 
            AutoScaleMode = AutoScaleMode.None;
            BackColor = Color.White;
            ClientSize = new Size(241, 273);
            Controls.Add(ValueTextBox4);
            Controls.Add(ValueTextBox3);
            Controls.Add(ValueTextBox2);
            Controls.Add(CancelButton);
            Controls.Add(AddButton);
            Controls.Add(ValueTextBox1);
            Name = "EditValueForm";
            RectColor = Color.FromArgb(62, 81, 181);
            Style = Sunny.UI.UIStyle.Custom;
            Text = "Edit";
            TitleColor = Color.FromArgb(62, 81, 181);
            ZoomScaleRect = new Rectangle(15, 15, 800, 450);
            ResumeLayout(false);
        }

        #endregion

        private Sunny.UI.UIButton CancelButton;
        private Sunny.UI.UIButton AddButton;
        private Sunny.UI.UITextBox ValueTextBox1;
        private Sunny.UI.UITextBox ValueTextBox2;
        private Sunny.UI.UITextBox ValueTextBox3;
        private Sunny.UI.UITextBox ValueTextBox4;
    }
}