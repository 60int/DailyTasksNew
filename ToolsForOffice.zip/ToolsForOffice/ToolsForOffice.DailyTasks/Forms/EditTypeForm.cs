﻿using Sunny.UI;

namespace ToolsForOffice.DailyTasks.Forms
{
    public partial class EditTypeForm : UIForm
    {
        public EditTypeForm()
        {
            InitializeComponent();
        }
    }
}
