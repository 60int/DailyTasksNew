﻿using System.Text.Json;
using MaterialSkin.Controls;

namespace ToolsForOffice.DailyTasks.Forms
{
    public partial class HomePageForm : MaterialForm
    {
        private static readonly HttpClient client = new();
        private static string GetUser()
        {
            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string filePath = Path.Combine(desktopPath, "DailyTasks-MyUser.txt");
            string username = File.ReadAllText(filePath);
            return username;
        }
        public HomePageForm()
        {
            InitializeComponent();
            CurrentUserLabel.Text = GetUser();

            string apiKey = "21d566ff98366dd488938f59cf6d1376";
            string city = "Budapest";
            string url = $"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={apiKey}&units=metric";

            try
            {
                HttpResponseMessage response = client.GetAsync(url).Result;
                response.EnsureSuccessStatusCode();
                string json = response.Content.ReadAsStringAsync().Result;

                using JsonDocument doc = JsonDocument.Parse(json);
                JsonElement root = doc.RootElement;
                double temperature = root.GetProperty("main").GetProperty("temp").GetDouble();
                string conditions = root.GetProperty("weather")[0].GetProperty("main").GetString()!;
                LocationLabel.Text = city;
                ConditionsLabel.Text = conditions;
                CelsiusLabel.Text = $"{temperature}°C";
            }
            catch (HttpRequestException)
            {
                ConditionsLabel.Text = "Weather data is not available";
                CelsiusLabel.Text = "";
            }
            catch (JsonException)
            {
                ConditionsLabel.Text = "Weather data is not available";
                CelsiusLabel.Text = "";
            }
        }

        private void WeatherPictureBox_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
