﻿using DailyTasks.Forms.Classes;
using MaterialSkin.Controls;

namespace ToolsForOffice.DailyTasks.Forms
{
    public partial class AddTaskForm : MaterialForm
    {
        DailyTask? task;
        internal DailyTask? Task
        {
            get => task;
            set
            {
                task = value;
                UserTextBox.Text = task!.Title;
                TotalNumericUpDown.Value = (int)task.TotalAmount!;
                ScrapNGNumericUpDown.Value = (int)task.ScrapNG!;
                OtherNGNumericUpDown.Value = (int)task.OtherNG!;
                AmountLeftNumericUpDown.Value = (int)task.AmountLeft!;
                NGOKNumericUpDown.Value = (int)task.NgOK!;
                CompletedCheckBox.Checked = task.Completed;
                MainDateTimePicker.Value = (DateTime)task.StartTime!;
                TypeComboBox.SelectedItem = task.TaskType;
                PriorityComboBox.SelectedIndex = (int)task.Priority;
            }
        }

        private static string GetUser()
        {
            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string filePath = Path.Combine(desktopPath, "DailyTasks-MyUser.txt");
            string username = File.ReadAllText(filePath);
            return username;
        }

        public AddTaskForm(string cellTypeFilename)
        {
            InitializeComponent();
            string[] lines = File.ReadAllLines(cellTypeFilename);
            foreach (string line in lines)
            {
                string cellType = line.Split(',')[0];
                TypeComboBox.Items.Add(cellType);
            }
            // Select the first item in the TypeComboBox
            TypeComboBox.SelectedIndex = 0;
            PriorityComboBox.DataSource = Enum.GetValues(typeof(TaskPriority));
            MaximizeBox = false;
            UserTextBox.Text = GetUser();
            AcceptButton = OKButton;
        }


        private void OKButton_Click(object sender, EventArgs e)
        {
            if (task == null)
            {
                if (UserTextBox.Text.Length >= 3)
                {
                    task = new DailyTask(UserTextBox.Text, (int)TotalNumericUpDown.Value, (int)ScrapNGNumericUpDown.Value, (int)OtherNGNumericUpDown.Value, (int)AmountLeftNumericUpDown.Value, (int)NGOKNumericUpDown.Value, CompletedCheckBox.Checked, MainDateTimePicker.Value, TypeComboBox.SelectedItem.ToString(), (TaskPriority)PriorityComboBox.SelectedIndex);
                }
                else
                {
                    MessageBox.Show("The title must be 3 or less characters long!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    UserTextBox.Focus();
                    DialogResult = DialogResult.None;
                }
            }
            else
            {
                task.Title = UserTextBox.Text;
                task.TotalAmount = (int)TotalNumericUpDown.Value;
                task.ScrapNG = (int)ScrapNGNumericUpDown.Value;
                task.OtherNG = (int)OtherNGNumericUpDown.Value;
                task.AmountLeft = (int)AmountLeftNumericUpDown.Value;
                task.NgOK = (int)NGOKNumericUpDown.Value;
                task.Completed = CompletedCheckBox.Checked;
                task.StartTime = MainDateTimePicker.Value;
                task.TaskType = TypeComboBox.SelectedItem.ToString();
                task.Priority = (TaskPriority)PriorityComboBox.SelectedIndex;
            }
        }

        //Keep window on top always
        protected override CreateParams CreateParams
        {
            get
            {
                var cp = base.CreateParams;
                cp.ExStyle |= 8;  // Turn on WS_EX_TOPMOST
                return cp;
            }
        }

    }
}
