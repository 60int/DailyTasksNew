﻿using Sunny.UI;

namespace ToolsForOffice.DailyTasks.Forms
{
    public partial class EditClipboardForm : UIForm
    {
        public EditClipboardForm()
        {
            InitializeComponent();
        }
    }
}
