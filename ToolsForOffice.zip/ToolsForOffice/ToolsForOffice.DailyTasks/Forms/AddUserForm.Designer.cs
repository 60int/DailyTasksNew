﻿namespace ToolsForOffice.DailyTasks.Forms
{
    partial class AddUserForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            UserNameTextBox = new Sunny.UI.UITextBox();
            AddButton = new Sunny.UI.UIButton();
            CancelButton = new Sunny.UI.UIButton();
            SuspendLayout();
            // 
            // UserNameTextBox
            // 
            UserNameTextBox.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            UserNameTextBox.Location = new Point(16, 49);
            UserNameTextBox.Margin = new Padding(4, 5, 4, 5);
            UserNameTextBox.MinimumSize = new Size(1, 16);
            UserNameTextBox.Name = "UserNameTextBox";
            UserNameTextBox.Padding = new Padding(5);
            UserNameTextBox.RectColor = Color.FromArgb(62, 81, 181);
            UserNameTextBox.ShowText = false;
            UserNameTextBox.Size = new Size(206, 29);
            UserNameTextBox.Style = Sunny.UI.UIStyle.Custom;
            UserNameTextBox.TabIndex = 0;
            UserNameTextBox.Text = "Username";
            UserNameTextBox.TextAlignment = ContentAlignment.MiddleLeft;
            UserNameTextBox.Watermark = "";
            // 
            // AddButton
            // 
            AddButton.FillColor = Color.FromArgb(62, 81, 181);
            AddButton.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            AddButton.Location = new Point(16, 95);
            AddButton.MinimumSize = new Size(1, 1);
            AddButton.Name = "AddButton";
            AddButton.Size = new Size(100, 35);
            AddButton.Style = Sunny.UI.UIStyle.Custom;
            AddButton.TabIndex = 3;
            AddButton.Text = "OK";
            AddButton.Click += AddButton_Click;
            // 
            // CancelButton
            // 
            CancelButton.FillColor = Color.FromArgb(62, 81, 181);
            CancelButton.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            CancelButton.Location = new Point(122, 95);
            CancelButton.MinimumSize = new Size(1, 1);
            CancelButton.Name = "CancelButton";
            CancelButton.Size = new Size(100, 35);
            CancelButton.Style = Sunny.UI.UIStyle.Custom;
            CancelButton.TabIndex = 4;
            CancelButton.Text = "Cancel";
            // 
            // AddUserForm
            // 
            AutoScaleMode = AutoScaleMode.None;
            BackColor = Color.White;
            ClientSize = new Size(242, 142);
            Controls.Add(CancelButton);
            Controls.Add(AddButton);
            Controls.Add(UserNameTextBox);
            Name = "AddUserForm";
            RectColor = Color.FromArgb(62, 81, 181);
            Style = Sunny.UI.UIStyle.Custom;
            Text = "Add User";
            TitleColor = Color.FromArgb(62, 81, 181);
            TopMost = true;
            ZoomScaleRect = new Rectangle(15, 15, 214, 195);
            ResumeLayout(false);
        }

        #endregion

        private Sunny.UI.UITextBox UserNameTextBox;
        private Sunny.UI.UIButton AddButton;
        private Sunny.UI.UIButton CancelButton;
    }
}