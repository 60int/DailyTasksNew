﻿namespace ToolsForOffice.DailyTasks.Forms
{
    partial class HomePageForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            SunPanel = new Panel();
            WeatherPictureBox = new PictureBox();
            ConditionsLabel = new MaterialSkin.Controls.MaterialLabel();
            CelsiusLabel = new MaterialSkin.Controls.MaterialLabel();
            LocationLabel = new MaterialSkin.Controls.MaterialLabel();
            CurrentUserLabel = new MaterialSkin.Controls.MaterialLabel();
            CurrentUser = new MaterialSkin.Controls.MaterialLabel();
            ((System.ComponentModel.ISupportInitialize)WeatherPictureBox).BeginInit();
            SuspendLayout();
            // 
            // SunPanel
            // 
            SunPanel.BackColor = Color.Transparent;
            SunPanel.BackgroundImage = Properties.Resources.DailyTask_MainIcon;
            SunPanel.BackgroundImageLayout = ImageLayout.Stretch;
            SunPanel.Location = new Point(389, 121);
            SunPanel.Name = "SunPanel";
            SunPanel.Size = new Size(122, 127);
            SunPanel.TabIndex = 9;
            // 
            // WeatherPictureBox
            // 
            WeatherPictureBox.Location = new Point(343, 92);
            WeatherPictureBox.Name = "WeatherPictureBox";
            WeatherPictureBox.Size = new Size(216, 198);
            WeatherPictureBox.TabIndex = 8;
            WeatherPictureBox.TabStop = false;
            WeatherPictureBox.Paint += WeatherPictureBox_Paint;
            // 
            // ConditionsLabel
            // 
            ConditionsLabel.Depth = 0;
            ConditionsLabel.Font = new Font("Roboto", 14F, FontStyle.Regular, GraphicsUnit.Pixel);
            ConditionsLabel.Location = new Point(389, 353);
            ConditionsLabel.MouseState = MaterialSkin.MouseState.HOVER;
            ConditionsLabel.Name = "ConditionsLabel";
            ConditionsLabel.Size = new Size(122, 30);
            ConditionsLabel.TabIndex = 7;
            ConditionsLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // CelsiusLabel
            // 
            CelsiusLabel.Depth = 0;
            CelsiusLabel.Font = new Font("Roboto", 14F, FontStyle.Regular, GraphicsUnit.Pixel);
            CelsiusLabel.Location = new Point(389, 323);
            CelsiusLabel.MouseState = MaterialSkin.MouseState.HOVER;
            CelsiusLabel.Name = "CelsiusLabel";
            CelsiusLabel.Size = new Size(122, 30);
            CelsiusLabel.TabIndex = 6;
            CelsiusLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // LocationLabel
            // 
            LocationLabel.Depth = 0;
            LocationLabel.Font = new Font("Roboto", 14F, FontStyle.Regular, GraphicsUnit.Pixel);
            LocationLabel.Location = new Point(389, 293);
            LocationLabel.MouseState = MaterialSkin.MouseState.HOVER;
            LocationLabel.Name = "LocationLabel";
            LocationLabel.Size = new Size(122, 30);
            LocationLabel.TabIndex = 5;
            LocationLabel.Text = "Budapest";
            LocationLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // CurrentUserLabel
            // 
            CurrentUserLabel.BackColor = Color.FromArgb(30, 0, 0, 0);
            CurrentUserLabel.Depth = 0;
            CurrentUserLabel.Font = new Font("Roboto", 14F, FontStyle.Regular, GraphicsUnit.Pixel);
            CurrentUserLabel.Location = new Point(835, 13);
            CurrentUserLabel.MouseState = MaterialSkin.MouseState.HOVER;
            CurrentUserLabel.Name = "CurrentUserLabel";
            CurrentUserLabel.Size = new Size(71, 23);
            CurrentUserLabel.TabIndex = 24;
            CurrentUserLabel.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // CurrentUser
            // 
            CurrentUser.AutoSize = true;
            CurrentUser.BackColor = Color.FromArgb(30, 0, 0, 0);
            CurrentUser.Depth = 0;
            CurrentUser.Font = new Font("Roboto", 14F, FontStyle.Regular, GraphicsUnit.Pixel);
            CurrentUser.Location = new Point(739, 15);
            CurrentUser.MouseState = MaterialSkin.MouseState.HOVER;
            CurrentUser.Name = "CurrentUser";
            CurrentUser.Size = new Size(91, 19);
            CurrentUser.TabIndex = 23;
            CurrentUser.Text = "Current User:";
            // 
            // HomePageForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(914, 485);
            Controls.Add(CurrentUserLabel);
            Controls.Add(CurrentUser);
            Controls.Add(SunPanel);
            Controls.Add(WeatherPictureBox);
            Controls.Add(ConditionsLabel);
            Controls.Add(CelsiusLabel);
            Controls.Add(LocationLabel);
            FormStyle = FormStyles.StatusAndActionBar_None;
            Name = "HomePageForm";
            Padding = new Padding(3, 0, 3, 3);
            Text = "HomePageForm";
            ((System.ComponentModel.ISupportInitialize)WeatherPictureBox).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel SunPanel;
        private PictureBox WeatherPictureBox;
        private MaterialSkin.Controls.MaterialLabel ConditionsLabel;
        private MaterialSkin.Controls.MaterialLabel CelsiusLabel;
        private MaterialSkin.Controls.MaterialLabel LocationLabel;
        private MaterialSkin.Controls.MaterialLabel CurrentUserLabel;
        private MaterialSkin.Controls.MaterialLabel CurrentUser;
    }
}