﻿namespace ToolsForOffice.DailyTasks.Forms
{
    partial class AddTaskForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            UserTaskLabel = new Sunny.UI.UILabel();
            UserTextBox = new Sunny.UI.UITextBox();
            TotalLabel = new Sunny.UI.UILabel();
            CustomValueLabel1 = new Sunny.UI.UILabel();
            CustomValueLabel2 = new Sunny.UI.UILabel();
            CustomValueLabel3 = new Sunny.UI.UILabel();
            CustomValueLabel4 = new Sunny.UI.UILabel();
            MainDateTimePicker = new Sunny.UI.UIDatePicker();
            TypeComboBox = new Sunny.UI.UIComboBox();
            PriorityComboBox = new Sunny.UI.UIComboBox();
            OKButton = new Sunny.UI.UIButton();
            CancelButton = new Sunny.UI.UIButton();
            TotalNumericUpDown = new Sunny.UI.UIIntegerUpDown();
            CustomUpDown1 = new Sunny.UI.UIIntegerUpDown();
            CustomUpDown2 = new Sunny.UI.UIIntegerUpDown();
            CustomUpDown3 = new Sunny.UI.UIIntegerUpDown();
            CustomUpDown4 = new Sunny.UI.UIIntegerUpDown();
            CompletedSwitch = new Sunny.UI.UISwitch();
            CompletedLabel = new Sunny.UI.UILabel();
            SuspendLayout();
            // 
            // UserTaskLabel
            // 
            UserTaskLabel.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            UserTaskLabel.Location = new Point(13, 50);
            UserTaskLabel.Name = "UserTaskLabel";
            UserTaskLabel.Size = new Size(129, 29);
            UserTaskLabel.Style = Sunny.UI.UIStyle.Custom;
            UserTaskLabel.TabIndex = 0;
            UserTaskLabel.Text = "User";
            UserTaskLabel.TextAlign = ContentAlignment.MiddleRight;
            // 
            // UserTextBox
            // 
            UserTextBox.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            UserTextBox.Location = new Point(149, 49);
            UserTextBox.Margin = new Padding(4, 5, 4, 5);
            UserTextBox.MinimumSize = new Size(1, 16);
            UserTextBox.Name = "UserTextBox";
            UserTextBox.Padding = new Padding(5);
            UserTextBox.RectColor = Color.FromArgb(62, 81, 181);
            UserTextBox.ShowText = false;
            UserTextBox.Size = new Size(150, 29);
            UserTextBox.Style = Sunny.UI.UIStyle.Custom;
            UserTextBox.TabIndex = 12;
            UserTextBox.TextAlignment = ContentAlignment.MiddleLeft;
            UserTextBox.Watermark = "";
            // 
            // TotalLabel
            // 
            TotalLabel.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            TotalLabel.Location = new Point(13, 89);
            TotalLabel.Name = "TotalLabel";
            TotalLabel.Size = new Size(129, 29);
            TotalLabel.Style = Sunny.UI.UIStyle.Custom;
            TotalLabel.TabIndex = 2;
            TotalLabel.Text = "Total";
            TotalLabel.TextAlign = ContentAlignment.MiddleRight;
            // 
            // CustomValueLabel1
            // 
            CustomValueLabel1.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            CustomValueLabel1.Location = new Point(13, 128);
            CustomValueLabel1.Name = "CustomValueLabel1";
            CustomValueLabel1.Size = new Size(129, 29);
            CustomValueLabel1.Style = Sunny.UI.UIStyle.Custom;
            CustomValueLabel1.TabIndex = 3;
            CustomValueLabel1.Text = "Custom Value";
            CustomValueLabel1.TextAlign = ContentAlignment.MiddleRight;
            // 
            // CustomValueLabel2
            // 
            CustomValueLabel2.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            CustomValueLabel2.Location = new Point(13, 166);
            CustomValueLabel2.Name = "CustomValueLabel2";
            CustomValueLabel2.Size = new Size(129, 29);
            CustomValueLabel2.Style = Sunny.UI.UIStyle.Custom;
            CustomValueLabel2.TabIndex = 4;
            CustomValueLabel2.Text = "Custom Value";
            CustomValueLabel2.TextAlign = ContentAlignment.MiddleRight;
            // 
            // CustomValueLabel3
            // 
            CustomValueLabel3.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            CustomValueLabel3.Location = new Point(13, 205);
            CustomValueLabel3.Name = "CustomValueLabel3";
            CustomValueLabel3.Size = new Size(129, 29);
            CustomValueLabel3.Style = Sunny.UI.UIStyle.Custom;
            CustomValueLabel3.TabIndex = 5;
            CustomValueLabel3.Text = "Custom Value";
            CustomValueLabel3.TextAlign = ContentAlignment.MiddleRight;
            // 
            // CustomValueLabel4
            // 
            CustomValueLabel4.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            CustomValueLabel4.Location = new Point(13, 244);
            CustomValueLabel4.Name = "CustomValueLabel4";
            CustomValueLabel4.Size = new Size(129, 29);
            CustomValueLabel4.Style = Sunny.UI.UIStyle.Custom;
            CustomValueLabel4.TabIndex = 6;
            CustomValueLabel4.Text = "Custom Value";
            CustomValueLabel4.TextAlign = ContentAlignment.MiddleRight;
            // 
            // MainDateTimePicker
            // 
            MainDateTimePicker.FillColor = Color.White;
            MainDateTimePicker.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            MainDateTimePicker.Location = new Point(13, 317);
            MainDateTimePicker.Margin = new Padding(4, 5, 4, 5);
            MainDateTimePicker.MaxLength = 10;
            MainDateTimePicker.MinimumSize = new Size(63, 0);
            MainDateTimePicker.Name = "MainDateTimePicker";
            MainDateTimePicker.Padding = new Padding(0, 0, 30, 2);
            MainDateTimePicker.RectColor = Color.FromArgb(62, 81, 181);
            MainDateTimePicker.Size = new Size(286, 29);
            MainDateTimePicker.Style = Sunny.UI.UIStyle.Custom;
            MainDateTimePicker.SymbolDropDown = 61555;
            MainDateTimePicker.SymbolNormal = 61555;
            MainDateTimePicker.TabIndex = 7;
            MainDateTimePicker.Text = "2023-06-30";
            MainDateTimePicker.TextAlignment = ContentAlignment.MiddleLeft;
            MainDateTimePicker.Value = new DateTime(2023, 6, 30, 0, 0, 0, 0);
            MainDateTimePicker.Watermark = "";
            // 
            // TypeComboBox
            // 
            TypeComboBox.DataSource = null;
            TypeComboBox.FillColor = Color.White;
            TypeComboBox.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            TypeComboBox.Location = new Point(13, 356);
            TypeComboBox.Margin = new Padding(4, 5, 4, 5);
            TypeComboBox.MinimumSize = new Size(63, 0);
            TypeComboBox.Name = "TypeComboBox";
            TypeComboBox.Padding = new Padding(0, 0, 30, 2);
            TypeComboBox.RectColor = Color.FromArgb(62, 81, 181);
            TypeComboBox.Size = new Size(286, 29);
            TypeComboBox.Style = Sunny.UI.UIStyle.Custom;
            TypeComboBox.TabIndex = 8;
            TypeComboBox.Text = "Type";
            TypeComboBox.TextAlignment = ContentAlignment.MiddleLeft;
            TypeComboBox.Watermark = "";
            // 
            // PriorityComboBox
            // 
            PriorityComboBox.DataSource = null;
            PriorityComboBox.FillColor = Color.White;
            PriorityComboBox.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            PriorityComboBox.Location = new Point(13, 395);
            PriorityComboBox.Margin = new Padding(4, 5, 4, 5);
            PriorityComboBox.MinimumSize = new Size(63, 0);
            PriorityComboBox.Name = "PriorityComboBox";
            PriorityComboBox.Padding = new Padding(0, 0, 30, 2);
            PriorityComboBox.RectColor = Color.FromArgb(62, 81, 181);
            PriorityComboBox.Size = new Size(286, 29);
            PriorityComboBox.Style = Sunny.UI.UIStyle.Custom;
            PriorityComboBox.TabIndex = 9;
            PriorityComboBox.Text = "Priority";
            PriorityComboBox.TextAlignment = ContentAlignment.MiddleLeft;
            PriorityComboBox.Watermark = "";
            // 
            // OKButton
            // 
            OKButton.DialogResult = DialogResult.OK;
            OKButton.FillColor = Color.FromArgb(62, 81, 181);
            OKButton.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            OKButton.Location = new Point(93, 432);
            OKButton.MinimumSize = new Size(1, 1);
            OKButton.Name = "OKButton";
            OKButton.Size = new Size(100, 35);
            OKButton.Style = Sunny.UI.UIStyle.Custom;
            OKButton.TabIndex = 10;
            OKButton.Text = "OK";
            OKButton.Click += OKButton_Click;
            // 
            // CancelButton
            // 
            CancelButton.DialogResult = DialogResult.Cancel;
            CancelButton.FillColor = Color.FromArgb(62, 81, 181);
            CancelButton.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            CancelButton.Location = new Point(199, 432);
            CancelButton.MinimumSize = new Size(1, 1);
            CancelButton.Name = "CancelButton";
            CancelButton.Size = new Size(100, 35);
            CancelButton.Style = Sunny.UI.UIStyle.Custom;
            CancelButton.TabIndex = 11;
            CancelButton.Text = "Cancel";
            // 
            // TotalNumericUpDown
            // 
            TotalNumericUpDown.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            TotalNumericUpDown.Location = new Point(149, 88);
            TotalNumericUpDown.Margin = new Padding(4, 5, 4, 5);
            TotalNumericUpDown.Minimum = 0;
            TotalNumericUpDown.MinimumSize = new Size(100, 0);
            TotalNumericUpDown.Name = "TotalNumericUpDown";
            TotalNumericUpDown.RectColor = Color.FromArgb(62, 81, 181);
            TotalNumericUpDown.ShowText = false;
            TotalNumericUpDown.Size = new Size(150, 29);
            TotalNumericUpDown.Style = Sunny.UI.UIStyle.Custom;
            TotalNumericUpDown.TabIndex = 1;
            TotalNumericUpDown.Text = "uiIntegerUpDown1";
            TotalNumericUpDown.TextAlignment = ContentAlignment.MiddleCenter;
            // 
            // CustomUpDown1
            // 
            CustomUpDown1.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            CustomUpDown1.Location = new Point(149, 127);
            CustomUpDown1.Margin = new Padding(4, 5, 4, 5);
            CustomUpDown1.Minimum = 0;
            CustomUpDown1.MinimumSize = new Size(100, 0);
            CustomUpDown1.Name = "CustomUpDown1";
            CustomUpDown1.RectColor = Color.FromArgb(62, 81, 181);
            CustomUpDown1.ShowText = false;
            CustomUpDown1.Size = new Size(150, 29);
            CustomUpDown1.Style = Sunny.UI.UIStyle.Custom;
            CustomUpDown1.TabIndex = 2;
            CustomUpDown1.Text = "uiIntegerUpDown1";
            CustomUpDown1.TextAlignment = ContentAlignment.MiddleCenter;
            // 
            // CustomUpDown2
            // 
            CustomUpDown2.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            CustomUpDown2.Location = new Point(149, 166);
            CustomUpDown2.Margin = new Padding(4, 5, 4, 5);
            CustomUpDown2.Minimum = 0;
            CustomUpDown2.MinimumSize = new Size(100, 0);
            CustomUpDown2.Name = "CustomUpDown2";
            CustomUpDown2.RectColor = Color.FromArgb(62, 81, 181);
            CustomUpDown2.ShowText = false;
            CustomUpDown2.Size = new Size(150, 29);
            CustomUpDown2.Style = Sunny.UI.UIStyle.Custom;
            CustomUpDown2.TabIndex = 3;
            CustomUpDown2.Text = "uiIntegerUpDown1";
            CustomUpDown2.TextAlignment = ContentAlignment.MiddleCenter;
            // 
            // CustomUpDown3
            // 
            CustomUpDown3.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            CustomUpDown3.Location = new Point(149, 205);
            CustomUpDown3.Margin = new Padding(4, 5, 4, 5);
            CustomUpDown3.Minimum = 0;
            CustomUpDown3.MinimumSize = new Size(100, 0);
            CustomUpDown3.Name = "CustomUpDown3";
            CustomUpDown3.RectColor = Color.FromArgb(62, 81, 181);
            CustomUpDown3.ShowText = false;
            CustomUpDown3.Size = new Size(150, 29);
            CustomUpDown3.Style = Sunny.UI.UIStyle.Custom;
            CustomUpDown3.TabIndex = 4;
            CustomUpDown3.Text = "uiIntegerUpDown1";
            CustomUpDown3.TextAlignment = ContentAlignment.MiddleCenter;
            // 
            // CustomUpDown4
            // 
            CustomUpDown4.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            CustomUpDown4.Location = new Point(149, 243);
            CustomUpDown4.Margin = new Padding(4, 5, 4, 5);
            CustomUpDown4.Minimum = 0;
            CustomUpDown4.MinimumSize = new Size(100, 0);
            CustomUpDown4.Name = "CustomUpDown4";
            CustomUpDown4.RectColor = Color.FromArgb(62, 81, 181);
            CustomUpDown4.ShowText = false;
            CustomUpDown4.Size = new Size(150, 29);
            CustomUpDown4.Style = Sunny.UI.UIStyle.Custom;
            CustomUpDown4.TabIndex = 5;
            CustomUpDown4.Text = "uiIntegerUpDown1";
            CustomUpDown4.TextAlignment = ContentAlignment.MiddleCenter;
            // 
            // CompletedSwitch
            // 
            CompletedSwitch.ActiveColor = Color.Lime;
            CompletedSwitch.ActiveText = "Yes";
            CompletedSwitch.DisabledColor = Color.Red;
            CompletedSwitch.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            CompletedSwitch.InActiveColor = Color.Red;
            CompletedSwitch.InActiveText = "No";
            CompletedSwitch.Location = new Point(149, 280);
            CompletedSwitch.MinimumSize = new Size(1, 1);
            CompletedSwitch.Name = "CompletedSwitch";
            CompletedSwitch.Size = new Size(75, 29);
            CompletedSwitch.Style = Sunny.UI.UIStyle.Custom;
            CompletedSwitch.TabIndex = 13;
            CompletedSwitch.Text = "uiSwitch1";
            // 
            // CompletedLabel
            // 
            CompletedLabel.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            CompletedLabel.Location = new Point(14, 280);
            CompletedLabel.Name = "CompletedLabel";
            CompletedLabel.Size = new Size(129, 29);
            CompletedLabel.Style = Sunny.UI.UIStyle.Custom;
            CompletedLabel.TabIndex = 14;
            CompletedLabel.Text = "Completed";
            CompletedLabel.TextAlign = ContentAlignment.MiddleRight;
            // 
            // AddTaskForm
            // 
            AutoScaleMode = AutoScaleMode.None;
            BackColor = Color.White;
            ClientSize = new Size(318, 484);
            Controls.Add(CompletedLabel);
            Controls.Add(CompletedSwitch);
            Controls.Add(CustomUpDown4);
            Controls.Add(CustomUpDown3);
            Controls.Add(CustomUpDown2);
            Controls.Add(CustomUpDown1);
            Controls.Add(TotalNumericUpDown);
            Controls.Add(CancelButton);
            Controls.Add(OKButton);
            Controls.Add(PriorityComboBox);
            Controls.Add(TypeComboBox);
            Controls.Add(MainDateTimePicker);
            Controls.Add(CustomValueLabel4);
            Controls.Add(CustomValueLabel3);
            Controls.Add(CustomValueLabel2);
            Controls.Add(CustomValueLabel1);
            Controls.Add(TotalLabel);
            Controls.Add(UserTextBox);
            Controls.Add(UserTaskLabel);
            MaximizeBox = false;
            Name = "AddTaskForm";
            RectColor = Color.FromArgb(62, 81, 181);
            Style = Sunny.UI.UIStyle.Custom;
            Text = "Add/Update Task";
            TitleColor = Color.FromArgb(62, 81, 181);
            TopMost = true;
            ZoomScaleRect = new Rectangle(15, 15, 800, 450);
            ResumeLayout(false);
        }

        #endregion

        private Sunny.UI.UILabel UserTaskLabel;
        private Sunny.UI.UITextBox UserTextBox;
        private Sunny.UI.UILabel TotalLabel;
        private Sunny.UI.UILabel CustomValueLabel1;
        private Sunny.UI.UILabel CustomValueLabel2;
        private Sunny.UI.UILabel CustomValueLabel3;
        private Sunny.UI.UILabel CustomValueLabel4;
        private Sunny.UI.UIDatePicker MainDateTimePicker;
        private Sunny.UI.UIComboBox TypeComboBox;
        private Sunny.UI.UIComboBox PriorityComboBox;
        private Sunny.UI.UIButton OKButton;
        private Sunny.UI.UIButton CancelButton;
        private Sunny.UI.UIIntegerUpDown TotalNumericUpDown;
        private Sunny.UI.UIIntegerUpDown CustomUpDown1;
        private Sunny.UI.UIIntegerUpDown CustomUpDown2;
        private Sunny.UI.UIIntegerUpDown CustomUpDown3;
        private Sunny.UI.UIIntegerUpDown CustomUpDown4;
        private Sunny.UI.UISwitch CompletedSwitch;
        private Sunny.UI.UILabel CompletedLabel;
    }
}