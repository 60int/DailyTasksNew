﻿namespace ToolsForOffice.DailyTasks.Forms
{
    partial class AddTaskForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            OKButton = new Sunny.UI.UIButton();
            CancelButton = new Sunny.UI.UIButton();
            UserTaskLabel = new Label();
            TotalLabel = new Label();
            CustomValueLabel1 = new Label();
            CustomValueLabel2 = new Label();
            CustomValueLabel3 = new Label();
            CustomValueLabel4 = new Label();
            CompletedLabel = new Label();
            dateTimePicker1 = new DateTimePicker();
            uiComboBox1 = new Sunny.UI.UIComboBox();
            uiComboBox2 = new Sunny.UI.UIComboBox();
            uiTextBox1 = new Sunny.UI.UITextBox();
            uiIntegerUpDown1 = new Sunny.UI.UIIntegerUpDown();
            uiIntegerUpDown2 = new Sunny.UI.UIIntegerUpDown();
            uiIntegerUpDown3 = new Sunny.UI.UIIntegerUpDown();
            uiIntegerUpDown4 = new Sunny.UI.UIIntegerUpDown();
            uiIntegerUpDown5 = new Sunny.UI.UIIntegerUpDown();
            uiSwitch1 = new Sunny.UI.UISwitch();
            SuspendLayout();
            // 
            // OKButton
            // 
            OKButton.FillColor = Color.FromArgb(48, 48, 48);
            OKButton.FillColor2 = Color.FromArgb(48, 48, 48);
            OKButton.FillHoverColor = Color.FromArgb(109, 109, 103);
            OKButton.FillPressColor = Color.FromArgb(109, 109, 103);
            OKButton.FillSelectedColor = Color.FromArgb(109, 109, 103);
            OKButton.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            OKButton.Location = new Point(72, 448);
            OKButton.MinimumSize = new Size(1, 1);
            OKButton.Name = "OKButton";
            OKButton.RectColor = Color.FromArgb(48, 48, 48);
            OKButton.RectHoverColor = Color.FromArgb(109, 109, 103);
            OKButton.RectPressColor = Color.FromArgb(109, 109, 103);
            OKButton.RectSelectedColor = Color.FromArgb(109, 109, 103);
            OKButton.Size = new Size(117, 35);
            OKButton.Style = Sunny.UI.UIStyle.Custom;
            OKButton.TabIndex = 3;
            OKButton.Text = "OK";
            // 
            // CancelButton
            // 
            CancelButton.FillColor = Color.FromArgb(48, 48, 48);
            CancelButton.FillColor2 = Color.FromArgb(48, 48, 48);
            CancelButton.FillHoverColor = Color.FromArgb(109, 109, 103);
            CancelButton.FillPressColor = Color.FromArgb(109, 109, 103);
            CancelButton.FillSelectedColor = Color.FromArgb(109, 109, 103);
            CancelButton.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            CancelButton.Location = new Point(243, 448);
            CancelButton.MinimumSize = new Size(1, 1);
            CancelButton.Name = "CancelButton";
            CancelButton.RectColor = Color.FromArgb(48, 48, 48);
            CancelButton.RectHoverColor = Color.FromArgb(109, 109, 103);
            CancelButton.RectPressColor = Color.FromArgb(109, 109, 103);
            CancelButton.RectSelectedColor = Color.FromArgb(109, 109, 103);
            CancelButton.Size = new Size(117, 35);
            CancelButton.Style = Sunny.UI.UIStyle.Custom;
            CancelButton.TabIndex = 4;
            CancelButton.Text = "Cancel";
            // 
            // UserTaskLabel
            // 
            UserTaskLabel.AutoSize = true;
            UserTaskLabel.Location = new Point(102, 57);
            UserTaskLabel.Name = "UserTaskLabel";
            UserTaskLabel.Size = new Size(87, 21);
            UserTaskLabel.TabIndex = 5;
            UserTaskLabel.Text = "Username";
            // 
            // TotalLabel
            // 
            TotalLabel.AutoSize = true;
            TotalLabel.Location = new Point(141, 101);
            TotalLabel.Name = "TotalLabel";
            TotalLabel.Size = new Size(48, 21);
            TotalLabel.TabIndex = 6;
            TotalLabel.Text = "Total";
            // 
            // CustomValueLabel1
            // 
            CustomValueLabel1.AutoSize = true;
            CustomValueLabel1.Location = new Point(72, 140);
            CustomValueLabel1.Name = "CustomValueLabel1";
            CustomValueLabel1.Size = new Size(117, 21);
            CustomValueLabel1.TabIndex = 7;
            CustomValueLabel1.Text = "Custom Value";
            // 
            // CustomValueLabel2
            // 
            CustomValueLabel2.AutoSize = true;
            CustomValueLabel2.Location = new Point(72, 179);
            CustomValueLabel2.Name = "CustomValueLabel2";
            CustomValueLabel2.Size = new Size(117, 21);
            CustomValueLabel2.TabIndex = 8;
            CustomValueLabel2.Text = "Custom Value";
            // 
            // CustomValueLabel3
            // 
            CustomValueLabel3.AutoSize = true;
            CustomValueLabel3.Location = new Point(72, 218);
            CustomValueLabel3.Name = "CustomValueLabel3";
            CustomValueLabel3.Size = new Size(117, 21);
            CustomValueLabel3.TabIndex = 9;
            CustomValueLabel3.Text = "Custom Value";
            // 
            // CustomValueLabel4
            // 
            CustomValueLabel4.AutoSize = true;
            CustomValueLabel4.Location = new Point(72, 257);
            CustomValueLabel4.Name = "CustomValueLabel4";
            CustomValueLabel4.Size = new Size(117, 21);
            CustomValueLabel4.TabIndex = 10;
            CustomValueLabel4.Text = "Custom Value";
            // 
            // CompletedLabel
            // 
            CompletedLabel.AutoSize = true;
            CompletedLabel.Location = new Point(95, 294);
            CompletedLabel.Name = "CompletedLabel";
            CompletedLabel.Size = new Size(94, 21);
            CompletedLabel.TabIndex = 11;
            CompletedLabel.Text = "Completed";
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(72, 330);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(288, 29);
            dateTimePicker1.TabIndex = 12;
            // 
            // uiComboBox1
            // 
            uiComboBox1.DataSource = null;
            uiComboBox1.FillColor = Color.White;
            uiComboBox1.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            uiComboBox1.Location = new Point(72, 367);
            uiComboBox1.Margin = new Padding(4, 5, 4, 5);
            uiComboBox1.MinimumSize = new Size(63, 0);
            uiComboBox1.Name = "uiComboBox1";
            uiComboBox1.Padding = new Padding(0, 0, 30, 2);
            uiComboBox1.RectColor = Color.FromArgb(48, 48, 48);
            uiComboBox1.Size = new Size(288, 29);
            uiComboBox1.Style = Sunny.UI.UIStyle.Custom;
            uiComboBox1.TabIndex = 13;
            uiComboBox1.TextAlignment = ContentAlignment.MiddleLeft;
            uiComboBox1.Watermark = "";
            // 
            // uiComboBox2
            // 
            uiComboBox2.DataSource = null;
            uiComboBox2.FillColor = Color.White;
            uiComboBox2.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            uiComboBox2.Location = new Point(72, 406);
            uiComboBox2.Margin = new Padding(4, 5, 4, 5);
            uiComboBox2.MinimumSize = new Size(63, 0);
            uiComboBox2.Name = "uiComboBox2";
            uiComboBox2.Padding = new Padding(0, 0, 30, 2);
            uiComboBox2.RectColor = Color.FromArgb(48, 48, 48);
            uiComboBox2.Size = new Size(288, 29);
            uiComboBox2.Style = Sunny.UI.UIStyle.Custom;
            uiComboBox2.TabIndex = 1;
            uiComboBox2.TextAlignment = ContentAlignment.MiddleLeft;
            uiComboBox2.Watermark = "";
            // 
            // uiTextBox1
            // 
            uiTextBox1.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            uiTextBox1.Location = new Point(195, 54);
            uiTextBox1.Margin = new Padding(4, 5, 4, 5);
            uiTextBox1.MinimumSize = new Size(1, 16);
            uiTextBox1.Name = "uiTextBox1";
            uiTextBox1.Padding = new Padding(5);
            uiTextBox1.RectColor = Color.FromArgb(48, 48, 48);
            uiTextBox1.ShowText = false;
            uiTextBox1.Size = new Size(165, 29);
            uiTextBox1.Style = Sunny.UI.UIStyle.Custom;
            uiTextBox1.TabIndex = 1;
            uiTextBox1.TextAlignment = ContentAlignment.MiddleLeft;
            uiTextBox1.Watermark = "";
            // 
            // uiIntegerUpDown1
            // 
            uiIntegerUpDown1.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            uiIntegerUpDown1.Location = new Point(195, 93);
            uiIntegerUpDown1.Margin = new Padding(4, 5, 4, 5);
            uiIntegerUpDown1.MinimumSize = new Size(100, 0);
            uiIntegerUpDown1.Name = "uiIntegerUpDown1";
            uiIntegerUpDown1.RectColor = Color.FromArgb(48, 48, 48);
            uiIntegerUpDown1.ShowText = false;
            uiIntegerUpDown1.Size = new Size(165, 29);
            uiIntegerUpDown1.Style = Sunny.UI.UIStyle.Custom;
            uiIntegerUpDown1.TabIndex = 14;
            uiIntegerUpDown1.Text = "uiIntegerUpDown1";
            uiIntegerUpDown1.TextAlignment = ContentAlignment.MiddleCenter;
            // 
            // uiIntegerUpDown2
            // 
            uiIntegerUpDown2.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            uiIntegerUpDown2.Location = new Point(195, 132);
            uiIntegerUpDown2.Margin = new Padding(4, 5, 4, 5);
            uiIntegerUpDown2.MinimumSize = new Size(100, 0);
            uiIntegerUpDown2.Name = "uiIntegerUpDown2";
            uiIntegerUpDown2.RectColor = Color.FromArgb(48, 48, 48);
            uiIntegerUpDown2.ShowText = false;
            uiIntegerUpDown2.Size = new Size(165, 29);
            uiIntegerUpDown2.Style = Sunny.UI.UIStyle.Custom;
            uiIntegerUpDown2.TabIndex = 15;
            uiIntegerUpDown2.Text = "uiIntegerUpDown2";
            uiIntegerUpDown2.TextAlignment = ContentAlignment.MiddleCenter;
            // 
            // uiIntegerUpDown3
            // 
            uiIntegerUpDown3.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            uiIntegerUpDown3.Location = new Point(195, 171);
            uiIntegerUpDown3.Margin = new Padding(4, 5, 4, 5);
            uiIntegerUpDown3.MinimumSize = new Size(100, 0);
            uiIntegerUpDown3.Name = "uiIntegerUpDown3";
            uiIntegerUpDown3.RectColor = Color.FromArgb(48, 48, 48);
            uiIntegerUpDown3.ShowText = false;
            uiIntegerUpDown3.Size = new Size(165, 29);
            uiIntegerUpDown3.Style = Sunny.UI.UIStyle.Custom;
            uiIntegerUpDown3.TabIndex = 15;
            uiIntegerUpDown3.Text = "uiIntegerUpDown3";
            uiIntegerUpDown3.TextAlignment = ContentAlignment.MiddleCenter;
            // 
            // uiIntegerUpDown4
            // 
            uiIntegerUpDown4.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            uiIntegerUpDown4.Location = new Point(195, 210);
            uiIntegerUpDown4.Margin = new Padding(4, 5, 4, 5);
            uiIntegerUpDown4.MinimumSize = new Size(100, 0);
            uiIntegerUpDown4.Name = "uiIntegerUpDown4";
            uiIntegerUpDown4.RectColor = Color.FromArgb(48, 48, 48);
            uiIntegerUpDown4.ShowText = false;
            uiIntegerUpDown4.Size = new Size(165, 29);
            uiIntegerUpDown4.Style = Sunny.UI.UIStyle.Custom;
            uiIntegerUpDown4.TabIndex = 15;
            uiIntegerUpDown4.Text = "uiIntegerUpDown4";
            uiIntegerUpDown4.TextAlignment = ContentAlignment.MiddleCenter;
            // 
            // uiIntegerUpDown5
            // 
            uiIntegerUpDown5.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            uiIntegerUpDown5.Location = new Point(195, 249);
            uiIntegerUpDown5.Margin = new Padding(4, 5, 4, 5);
            uiIntegerUpDown5.MinimumSize = new Size(100, 0);
            uiIntegerUpDown5.Name = "uiIntegerUpDown5";
            uiIntegerUpDown5.RectColor = Color.FromArgb(48, 48, 48);
            uiIntegerUpDown5.ShowText = false;
            uiIntegerUpDown5.Size = new Size(165, 29);
            uiIntegerUpDown5.Style = Sunny.UI.UIStyle.Custom;
            uiIntegerUpDown5.TabIndex = 15;
            uiIntegerUpDown5.Text = "uiIntegerUpDown5";
            uiIntegerUpDown5.TextAlignment = ContentAlignment.MiddleCenter;
            // 
            // uiSwitch1
            // 
            uiSwitch1.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            uiSwitch1.Location = new Point(195, 286);
            uiSwitch1.MinimumSize = new Size(1, 1);
            uiSwitch1.Name = "uiSwitch1";
            uiSwitch1.Size = new Size(75, 29);
            uiSwitch1.Style = Sunny.UI.UIStyle.Custom;
            uiSwitch1.TabIndex = 16;
            uiSwitch1.Text = "uiSwitch1";
            // 
            // AddTaskForm
            // 
            AutoScaleMode = AutoScaleMode.None;
            BackColor = Color.White;
            ClientSize = new Size(440, 498);
            ControlBoxFillHoverColor = Color.FromArgb(109, 109, 103);
            Controls.Add(uiSwitch1);
            Controls.Add(uiIntegerUpDown5);
            Controls.Add(uiIntegerUpDown4);
            Controls.Add(uiIntegerUpDown3);
            Controls.Add(uiIntegerUpDown2);
            Controls.Add(uiIntegerUpDown1);
            Controls.Add(uiTextBox1);
            Controls.Add(uiComboBox2);
            Controls.Add(uiComboBox1);
            Controls.Add(dateTimePicker1);
            Controls.Add(CompletedLabel);
            Controls.Add(CustomValueLabel4);
            Controls.Add(CustomValueLabel3);
            Controls.Add(CustomValueLabel2);
            Controls.Add(CustomValueLabel1);
            Controls.Add(TotalLabel);
            Controls.Add(UserTaskLabel);
            Controls.Add(CancelButton);
            Controls.Add(OKButton);
            Name = "AddTaskForm";
            RectColor = Color.FromArgb(48, 48, 48);
            Style = Sunny.UI.UIStyle.Custom;
            Text = "Add/Update Task";
            TitleColor = Color.FromArgb(48, 48, 48);
            ZoomScaleRect = new Rectangle(15, 15, 800, 450);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Sunny.UI.UIButton OKButton;
        private Sunny.UI.UIButton CancelButton;
        private Label UserTaskLabel;
        private Label TotalLabel;
        private Label CustomValueLabel1;
        private Label CustomValueLabel2;
        private Label CustomValueLabel3;
        private Label CustomValueLabel4;
        private Label CompletedLabel;
        private DateTimePicker dateTimePicker1;
        private Sunny.UI.UIComboBox uiComboBox1;
        private Sunny.UI.UIComboBox uiComboBox2;
        private Sunny.UI.UITextBox uiTextBox1;
        private Sunny.UI.UIIntegerUpDown uiIntegerUpDown1;
        private Sunny.UI.UIIntegerUpDown uiIntegerUpDown2;
        private Sunny.UI.UIIntegerUpDown uiIntegerUpDown3;
        private Sunny.UI.UIIntegerUpDown uiIntegerUpDown4;
        private Sunny.UI.UIIntegerUpDown uiIntegerUpDown5;
        private Sunny.UI.UISwitch uiSwitch1;
    }
}