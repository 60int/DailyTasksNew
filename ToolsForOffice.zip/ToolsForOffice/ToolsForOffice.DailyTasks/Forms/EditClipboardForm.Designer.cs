﻿namespace ToolsForOffice.DailyTasks.Forms
{
    partial class EditClipboardForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            MainDataGridView = new DataGridView();
            CancelButton = new Sunny.UI.UIButton();
            OKButton = new Sunny.UI.UIButton();
            ((System.ComponentModel.ISupportInitialize)MainDataGridView).BeginInit();
            SuspendLayout();
            // 
            // MainDataGridView
            // 
            MainDataGridView.BackgroundColor = Color.White;
            MainDataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            MainDataGridView.Location = new Point(3, 38);
            MainDataGridView.Name = "MainDataGridView";
            MainDataGridView.RowTemplate.Height = 25;
            MainDataGridView.Size = new Size(791, 368);
            MainDataGridView.TabIndex = 0;
            // 
            // CancelButton
            // 
            CancelButton.DialogResult = DialogResult.Cancel;
            CancelButton.FillColor = Color.FromArgb(62, 81, 181);
            CancelButton.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            CancelButton.Location = new Point(393, 412);
            CancelButton.MinimumSize = new Size(1, 1);
            CancelButton.Name = "CancelButton";
            CancelButton.Size = new Size(100, 35);
            CancelButton.Style = Sunny.UI.UIStyle.Custom;
            CancelButton.TabIndex = 13;
            CancelButton.Text = "Cancel";
            // 
            // OKButton
            // 
            OKButton.DialogResult = DialogResult.OK;
            OKButton.FillColor = Color.FromArgb(62, 81, 181);
            OKButton.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            OKButton.Location = new Point(287, 412);
            OKButton.MinimumSize = new Size(1, 1);
            OKButton.Name = "OKButton";
            OKButton.Size = new Size(100, 35);
            OKButton.Style = Sunny.UI.UIStyle.Custom;
            OKButton.TabIndex = 12;
            OKButton.Text = "OK";
            // 
            // EditClipboardForm
            // 
            AutoScaleMode = AutoScaleMode.None;
            BackColor = Color.White;
            ClientSize = new Size(797, 454);
            Controls.Add(CancelButton);
            Controls.Add(OKButton);
            Controls.Add(MainDataGridView);
            Name = "EditClipboardForm";
            RectColor = Color.FromArgb(62, 81, 181);
            Style = Sunny.UI.UIStyle.Custom;
            Text = "EditClipboardForm";
            TitleColor = Color.FromArgb(62, 81, 181);
            ZoomScaleRect = new Rectangle(15, 15, 800, 450);
            ((System.ComponentModel.ISupportInitialize)MainDataGridView).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView MainDataGridView;
        private Sunny.UI.UIButton CancelButton;
        private Sunny.UI.UIButton OKButton;
    }
}