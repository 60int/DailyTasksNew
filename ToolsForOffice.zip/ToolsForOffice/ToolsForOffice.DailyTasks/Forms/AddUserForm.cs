﻿using MaterialSkin.Controls;
using ToolsForOffice.Shared;

namespace ToolsForOffice.DailyTasks.Forms
{
    public partial class AddUserForm : MaterialForm
    {
        User? user;

        internal User? User
        {
            get => user;
            set
            {
                user = value;
                UserNameTextBox.Text = user!.UserName;
            }
        }

        public AddUserForm()
        {
            InitializeComponent();
        }

        private void AddButton_Click(object sender, EventArgs e)
        {
            if (user == null)
            {
                if (UserNameTextBox.Text.Length >= 3)
                {
                    user = new User(UserNameTextBox.Text);
                }
                else
                {
                    MessageBox.Show("Username must be 3 or less characters long!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    UserNameTextBox.Focus();
                    DialogResult = DialogResult.None;
                }
            }
        }

        //Keep window on top always
        protected override CreateParams CreateParams
        {
            get
            {
                var cp = base.CreateParams;
                cp.ExStyle |= 8;  // Turn on WS_EX_TOPMOST
                return cp;
            }
        }
    }
}
