﻿using Sunny.UI;

namespace ToolsForOffice.DailyTasks.Forms
{
    public partial class AddUserForm : UIForm
    {
        public AddUserForm()
        {
            InitializeComponent();
        }
    }
}
