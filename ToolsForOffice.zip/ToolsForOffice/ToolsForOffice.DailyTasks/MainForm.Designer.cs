﻿namespace ToolsForOffice.DailyTasks
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            HomeTabControl = new Sunny.UI.UITabControl();
            HomeTabPage = new TabPage();
            HomeMenuStrip = new MenuStrip();
            CurrentUserMain = new Label();
            CurrentUserLabelMain = new Label();
            SunPanel = new Panel();
            ConditionsLabel = new Sunny.UI.UILabel();
            CelsiusLabel = new Sunny.UI.UILabel();
            LocationLabel = new Sunny.UI.UILabel();
            TasksTabPage = new TabPage();
            CurrentUser = new Label();
            CurrentUserLabel = new Label();
            MainListBox = new Sunny.UI.UIListBox();
            uiComboBox1 = new Sunny.UI.UIComboBox();
            ShareImageLabel = new Sunny.UI.UILabel();
            MainDateTimePicker = new Sunny.UI.UIDatePicker();
            MainDataGridView = new Sunny.UI.UIDataGridView();
            ShareImageButton = new Sunny.UI.UIButton();
            RemoveTaskButton = new Sunny.UI.UIButton();
            UpdateTaskButton = new Sunny.UI.UIButton();
            AddTaskButton = new Sunny.UI.UIButton();
            SortByWeekButton = new Sunny.UI.UIButton();
            ShowAllButton = new Sunny.UI.UIButton();
            MainMenuStrip = new MenuStrip();
            FileStripMenuItem = new ToolStripMenuItem();
            NewUserToolStripMenuItem = new ToolStripMenuItem();
            UsersToolStripMenuItem = new ToolStripMenuItem();
            ExitToolStripMenuItem = new ToolStripMenuItem();
            customValuesToolStripMenuItem = new ToolStripMenuItem();
            editToolStripMenuItem = new ToolStripMenuItem();
            customTypesToolStripMenuItem = new ToolStripMenuItem();
            editToolStripMenuItem1 = new ToolStripMenuItem();
            ToolsTabPage = new TabPage();
            ToolsMenuStrip = new MenuStrip();
            ShareImageTimer = new System.Windows.Forms.Timer(components);
            HomeTabControl.SuspendLayout();
            HomeTabPage.SuspendLayout();
            TasksTabPage.SuspendLayout();
            MainListBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)MainDataGridView).BeginInit();
            MainMenuStrip.SuspendLayout();
            ToolsTabPage.SuspendLayout();
            SuspendLayout();
            // 
            // HomeTabControl
            // 
            HomeTabControl.Controls.Add(HomeTabPage);
            HomeTabControl.Controls.Add(TasksTabPage);
            HomeTabControl.Controls.Add(ToolsTabPage);
            HomeTabControl.Dock = DockStyle.Fill;
            HomeTabControl.DrawMode = TabDrawMode.OwnerDrawFixed;
            HomeTabControl.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            HomeTabControl.ItemSize = new Size(150, 40);
            HomeTabControl.Location = new Point(0, 29);
            HomeTabControl.MainPage = "";
            HomeTabControl.Name = "HomeTabControl";
            HomeTabControl.SelectedIndex = 0;
            HomeTabControl.Size = new Size(1015, 558);
            HomeTabControl.SizeMode = TabSizeMode.Fixed;
            HomeTabControl.Style = Sunny.UI.UIStyle.Custom;
            HomeTabControl.TabIndex = 0;
            HomeTabControl.TabSelectedForeColor = Color.White;
            HomeTabControl.TabSelectedHighColor = Color.White;
            HomeTabControl.TabUnSelectedForeColor = Color.FromArgb(240, 240, 240);
            // 
            // HomeTabPage
            // 
            HomeTabPage.BackColor = Color.White;
            HomeTabPage.BorderStyle = BorderStyle.FixedSingle;
            HomeTabPage.Controls.Add(HomeMenuStrip);
            HomeTabPage.Controls.Add(CurrentUserMain);
            HomeTabPage.Controls.Add(CurrentUserLabelMain);
            HomeTabPage.Controls.Add(SunPanel);
            HomeTabPage.Controls.Add(ConditionsLabel);
            HomeTabPage.Controls.Add(CelsiusLabel);
            HomeTabPage.Controls.Add(LocationLabel);
            HomeTabPage.Location = new Point(0, 40);
            HomeTabPage.Name = "HomeTabPage";
            HomeTabPage.Size = new Size(1015, 518);
            HomeTabPage.TabIndex = 0;
            HomeTabPage.Text = "Home";
            // 
            // HomeMenuStrip
            // 
            HomeMenuStrip.BackColor = Color.FromArgb(56, 56, 56);
            HomeMenuStrip.Location = new Point(0, 0);
            HomeMenuStrip.Name = "HomeMenuStrip";
            HomeMenuStrip.Size = new Size(1013, 24);
            HomeMenuStrip.TabIndex = 16;
            HomeMenuStrip.Text = "menuStrip1";
            // 
            // CurrentUserMain
            // 
            CurrentUserMain.Location = new Point(903, 31);
            CurrentUserMain.Name = "CurrentUserMain";
            CurrentUserMain.Size = new Size(106, 32);
            CurrentUserMain.TabIndex = 15;
            CurrentUserMain.Text = "Gergő";
            CurrentUserMain.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // CurrentUserLabelMain
            // 
            CurrentUserLabelMain.Location = new Point(796, 30);
            CurrentUserLabelMain.Name = "CurrentUserLabelMain";
            CurrentUserLabelMain.Size = new Size(113, 35);
            CurrentUserLabelMain.TabIndex = 14;
            CurrentUserLabelMain.Text = "Current User:";
            CurrentUserLabelMain.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // SunPanel
            // 
            SunPanel.BackgroundImage = Properties.Resources.DailyTask_MainIcon;
            SunPanel.BackgroundImageLayout = ImageLayout.Zoom;
            SunPanel.Location = new Point(389, 117);
            SunPanel.Name = "SunPanel";
            SunPanel.Size = new Size(215, 200);
            SunPanel.TabIndex = 13;
            // 
            // ConditionsLabel
            // 
            ConditionsLabel.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            ConditionsLabel.Location = new Point(447, 416);
            ConditionsLabel.Name = "ConditionsLabel";
            ConditionsLabel.Size = new Size(100, 23);
            ConditionsLabel.Style = Sunny.UI.UIStyle.Custom;
            ConditionsLabel.TabIndex = 12;
            ConditionsLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // CelsiusLabel
            // 
            CelsiusLabel.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            CelsiusLabel.Location = new Point(447, 374);
            CelsiusLabel.Name = "CelsiusLabel";
            CelsiusLabel.Size = new Size(100, 23);
            CelsiusLabel.Style = Sunny.UI.UIStyle.Custom;
            CelsiusLabel.TabIndex = 11;
            CelsiusLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // LocationLabel
            // 
            LocationLabel.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            LocationLabel.Location = new Point(447, 330);
            LocationLabel.Name = "LocationLabel";
            LocationLabel.Size = new Size(100, 23);
            LocationLabel.Style = Sunny.UI.UIStyle.Custom;
            LocationLabel.TabIndex = 10;
            LocationLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // TasksTabPage
            // 
            TasksTabPage.BackColor = Color.White;
            TasksTabPage.BorderStyle = BorderStyle.FixedSingle;
            TasksTabPage.Controls.Add(CurrentUser);
            TasksTabPage.Controls.Add(CurrentUserLabel);
            TasksTabPage.Controls.Add(MainListBox);
            TasksTabPage.Controls.Add(ShareImageLabel);
            TasksTabPage.Controls.Add(MainDateTimePicker);
            TasksTabPage.Controls.Add(MainDataGridView);
            TasksTabPage.Controls.Add(ShareImageButton);
            TasksTabPage.Controls.Add(RemoveTaskButton);
            TasksTabPage.Controls.Add(UpdateTaskButton);
            TasksTabPage.Controls.Add(AddTaskButton);
            TasksTabPage.Controls.Add(SortByWeekButton);
            TasksTabPage.Controls.Add(ShowAllButton);
            TasksTabPage.Controls.Add(MainMenuStrip);
            TasksTabPage.Location = new Point(0, 40);
            TasksTabPage.Name = "TasksTabPage";
            TasksTabPage.Size = new Size(1015, 518);
            TasksTabPage.TabIndex = 1;
            TasksTabPage.Text = "Tasks";
            // 
            // CurrentUser
            // 
            CurrentUser.Location = new Point(903, 31);
            CurrentUser.Name = "CurrentUser";
            CurrentUser.Size = new Size(106, 32);
            CurrentUser.TabIndex = 11;
            CurrentUser.Text = "Gergő";
            CurrentUser.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // CurrentUserLabel
            // 
            CurrentUserLabel.Location = new Point(796, 30);
            CurrentUserLabel.Name = "CurrentUserLabel";
            CurrentUserLabel.Size = new Size(113, 35);
            CurrentUserLabel.TabIndex = 10;
            CurrentUserLabel.Text = "Current User:";
            CurrentUserLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // MainListBox
            // 
            MainListBox.Controls.Add(uiComboBox1);
            MainListBox.Font = new Font("Microsoft YaHei", 9F, FontStyle.Regular, GraphicsUnit.Point);
            MainListBox.HoverColor = Color.FromArgb(48, 48, 48);
            MainListBox.ItemSelectBackColor = Color.FromArgb(48, 48, 48);
            MainListBox.ItemSelectForeColor = Color.White;
            MainListBox.Location = new Point(5, 72);
            MainListBox.Margin = new Padding(4, 5, 4, 5);
            MainListBox.MinimumSize = new Size(1, 1);
            MainListBox.Name = "MainListBox";
            MainListBox.Padding = new Padding(2);
            MainListBox.RectColor = Color.FromArgb(48, 48, 48);
            MainListBox.ScrollBarColor = Color.FromArgb(48, 48, 48);
            MainListBox.ShowText = false;
            MainListBox.Size = new Size(189, 274);
            MainListBox.Style = Sunny.UI.UIStyle.Custom;
            MainListBox.TabIndex = 9;
            MainListBox.Text = null;
            MainListBox.DoubleClick += MainListBox_DoubleClick;
            // 
            // uiComboBox1
            // 
            uiComboBox1.DataSource = null;
            uiComboBox1.FillColor = Color.White;
            uiComboBox1.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            uiComboBox1.Location = new Point(16, 245);
            uiComboBox1.Margin = new Padding(4, 5, 4, 5);
            uiComboBox1.MinimumSize = new Size(63, 0);
            uiComboBox1.Name = "uiComboBox1";
            uiComboBox1.Padding = new Padding(0, 0, 30, 2);
            uiComboBox1.Size = new Size(150, 29);
            uiComboBox1.Style = Sunny.UI.UIStyle.Custom;
            uiComboBox1.TabIndex = 12;
            uiComboBox1.Text = "uiComboBox1";
            uiComboBox1.TextAlignment = ContentAlignment.MiddleLeft;
            uiComboBox1.Watermark = "";
            // 
            // ShareImageLabel
            // 
            ShareImageLabel.BackColor = Color.White;
            ShareImageLabel.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            ShareImageLabel.ForeColor = Color.White;
            ShareImageLabel.Location = new Point(501, 38);
            ShareImageLabel.Name = "ShareImageLabel";
            ShareImageLabel.Size = new Size(124, 23);
            ShareImageLabel.Style = Sunny.UI.UIStyle.Custom;
            ShareImageLabel.TabIndex = 8;
            ShareImageLabel.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // MainDateTimePicker
            // 
            MainDateTimePicker.FillColor = Color.White;
            MainDateTimePicker.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            MainDateTimePicker.Location = new Point(4, 29);
            MainDateTimePicker.Margin = new Padding(4, 5, 4, 5);
            MainDateTimePicker.MaxLength = 10;
            MainDateTimePicker.MinimumSize = new Size(63, 0);
            MainDateTimePicker.Name = "MainDateTimePicker";
            MainDateTimePicker.Padding = new Padding(0, 0, 30, 2);
            MainDateTimePicker.RectColor = Color.FromArgb(48, 48, 48);
            MainDateTimePicker.Size = new Size(192, 35);
            MainDateTimePicker.Style = Sunny.UI.UIStyle.Custom;
            MainDateTimePicker.SymbolDropDown = 61555;
            MainDateTimePicker.SymbolNormal = 61555;
            MainDateTimePicker.TabIndex = 1;
            MainDateTimePicker.Text = "2023-06-30";
            MainDateTimePicker.TextAlignment = ContentAlignment.MiddleCenter;
            MainDateTimePicker.Value = new DateTime(2023, 6, 30, 0, 0, 0, 0);
            MainDateTimePicker.Watermark = "";
            MainDateTimePicker.ValueChanged += MainDateTimePicker_ValueChanged;
            // 
            // MainDataGridView
            // 
            dataGridViewCellStyle1.BackColor = Color.White;
            MainDataGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            MainDataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            MainDataGridView.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            MainDataGridView.BackgroundColor = Color.White;
            MainDataGridView.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(48, 48, 48);
            dataGridViewCellStyle2.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = Color.White;
            dataGridViewCellStyle2.SelectionBackColor = Color.FromArgb(48, 48, 48);
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            MainDataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            MainDataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = SystemColors.Window;
            dataGridViewCellStyle3.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle3.ForeColor = Color.FromArgb(48, 48, 48);
            dataGridViewCellStyle3.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            MainDataGridView.DefaultCellStyle = dataGridViewCellStyle3;
            MainDataGridView.EnableHeadersVisualStyles = false;
            MainDataGridView.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            MainDataGridView.GridColor = Color.FromArgb(48, 48, 48);
            MainDataGridView.Location = new Point(201, 72);
            MainDataGridView.Name = "MainDataGridView";
            MainDataGridView.RectColor = Color.FromArgb(48, 48, 48);
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = Color.White;
            dataGridViewCellStyle4.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle4.ForeColor = Color.White;
            dataGridViewCellStyle4.SelectionBackColor = Color.FromArgb(48, 48, 48);
            dataGridViewCellStyle4.SelectionForeColor = Color.White;
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.True;
            MainDataGridView.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            dataGridViewCellStyle5.BackColor = Color.White;
            dataGridViewCellStyle5.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            MainDataGridView.RowsDefaultCellStyle = dataGridViewCellStyle5;
            MainDataGridView.RowTemplate.Height = 25;
            MainDataGridView.ScrollBarColor = Color.FromArgb(48, 48, 48);
            MainDataGridView.ScrollBarRectColor = Color.FromArgb(48, 48, 48);
            MainDataGridView.SelectedIndex = -1;
            MainDataGridView.Size = new Size(808, 440);
            MainDataGridView.StripeOddColor = Color.White;
            MainDataGridView.Style = Sunny.UI.UIStyle.Custom;
            MainDataGridView.TabIndex = 1;
            // 
            // ShareImageButton
            // 
            ShareImageButton.FillColor = Color.FromArgb(48, 48, 48);
            ShareImageButton.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            ShareImageButton.Location = new Point(5, 477);
            ShareImageButton.MinimumSize = new Size(1, 1);
            ShareImageButton.Name = "ShareImageButton";
            ShareImageButton.Size = new Size(190, 35);
            ShareImageButton.Style = Sunny.UI.UIStyle.Custom;
            ShareImageButton.TabIndex = 1;
            ShareImageButton.Text = "Share Screenshot";
            ShareImageButton.Click += ShareImageButton_Click;
            // 
            // RemoveTaskButton
            // 
            RemoveTaskButton.FillColor = Color.FromArgb(48, 48, 48);
            RemoveTaskButton.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            RemoveTaskButton.Location = new Point(5, 436);
            RemoveTaskButton.MinimumSize = new Size(1, 1);
            RemoveTaskButton.Name = "RemoveTaskButton";
            RemoveTaskButton.Size = new Size(190, 35);
            RemoveTaskButton.Style = Sunny.UI.UIStyle.Custom;
            RemoveTaskButton.TabIndex = 6;
            RemoveTaskButton.Text = "Remove";
            RemoveTaskButton.Click += RemoveTaskButton_Click;
            // 
            // UpdateTaskButton
            // 
            UpdateTaskButton.FillColor = Color.FromArgb(48, 48, 48);
            UpdateTaskButton.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            UpdateTaskButton.Location = new Point(5, 395);
            UpdateTaskButton.MinimumSize = new Size(1, 1);
            UpdateTaskButton.Name = "UpdateTaskButton";
            UpdateTaskButton.Size = new Size(191, 35);
            UpdateTaskButton.Style = Sunny.UI.UIStyle.Custom;
            UpdateTaskButton.TabIndex = 5;
            UpdateTaskButton.Text = "Update";
            UpdateTaskButton.Click += UpdateTaskButton_Click;
            // 
            // AddTaskButton
            // 
            AddTaskButton.FillColor = Color.FromArgb(48, 48, 48);
            AddTaskButton.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            AddTaskButton.Location = new Point(4, 354);
            AddTaskButton.MinimumSize = new Size(1, 1);
            AddTaskButton.Name = "AddTaskButton";
            AddTaskButton.Size = new Size(191, 35);
            AddTaskButton.Style = Sunny.UI.UIStyle.Custom;
            AddTaskButton.TabIndex = 1;
            AddTaskButton.Text = "Add Task";
            AddTaskButton.Click += AddTaskButton_Click;
            // 
            // SortByWeekButton
            // 
            SortByWeekButton.FillColor = Color.FromArgb(48, 48, 48);
            SortByWeekButton.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            SortByWeekButton.Location = new Point(333, 29);
            SortByWeekButton.MinimumSize = new Size(1, 1);
            SortByWeekButton.Name = "SortByWeekButton";
            SortByWeekButton.Size = new Size(124, 35);
            SortByWeekButton.Style = Sunny.UI.UIStyle.Custom;
            SortByWeekButton.TabIndex = 3;
            SortByWeekButton.Text = "Current Week";
            SortByWeekButton.Click += SortByWeekButton_Click;
            // 
            // ShowAllButton
            // 
            ShowAllButton.FillColor = Color.FromArgb(48, 48, 48);
            ShowAllButton.FillColor2 = Color.FromArgb(83, 67, 48);
            ShowAllButton.Font = new Font("Microsoft YaHei", 12F, FontStyle.Regular, GraphicsUnit.Point);
            ShowAllButton.Location = new Point(203, 29);
            ShowAllButton.MinimumSize = new Size(1, 1);
            ShowAllButton.Name = "ShowAllButton";
            ShowAllButton.RectColor = Color.FromArgb(48, 48, 48);
            ShowAllButton.Size = new Size(124, 35);
            ShowAllButton.Style = Sunny.UI.UIStyle.Custom;
            ShowAllButton.TabIndex = 2;
            ShowAllButton.Text = "Show All";
            ShowAllButton.Click += ShowAllButton_Click;
            // 
            // MainMenuStrip
            // 
            MainMenuStrip.BackColor = Color.FromArgb(56, 56, 56);
            MainMenuStrip.Items.AddRange(new ToolStripItem[] { FileStripMenuItem, customValuesToolStripMenuItem, customTypesToolStripMenuItem });
            MainMenuStrip.Location = new Point(0, 0);
            MainMenuStrip.Name = "MainMenuStrip";
            MainMenuStrip.Size = new Size(1013, 24);
            MainMenuStrip.TabIndex = 0;
            // 
            // FileStripMenuItem
            // 
            FileStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { NewUserToolStripMenuItem, UsersToolStripMenuItem, ExitToolStripMenuItem });
            FileStripMenuItem.ForeColor = Color.White;
            FileStripMenuItem.Name = "FileStripMenuItem";
            FileStripMenuItem.Size = new Size(93, 20);
            FileStripMenuItem.Text = "Manage Users";
            FileStripMenuItem.DropDownClosed += ToolStripMenuItem_DropDownClosed;
            FileStripMenuItem.DropDownOpened += ToolStripMenuItem_DropDownOpened;
            // 
            // NewUserToolStripMenuItem
            // 
            NewUserToolStripMenuItem.BackColor = Color.FromArgb(56, 56, 56);
            NewUserToolStripMenuItem.ForeColor = Color.White;
            NewUserToolStripMenuItem.Name = "NewUserToolStripMenuItem";
            NewUserToolStripMenuItem.Size = new Size(131, 22);
            NewUserToolStripMenuItem.Text = "New User";
            NewUserToolStripMenuItem.Click += NewUserToolStripMenuItem_Click;
            // 
            // UsersToolStripMenuItem
            // 
            UsersToolStripMenuItem.BackColor = Color.FromArgb(56, 56, 56);
            UsersToolStripMenuItem.ForeColor = Color.White;
            UsersToolStripMenuItem.Name = "UsersToolStripMenuItem";
            UsersToolStripMenuItem.Size = new Size(131, 22);
            UsersToolStripMenuItem.Text = "Select User";
            // 
            // ExitToolStripMenuItem
            // 
            ExitToolStripMenuItem.BackColor = Color.FromArgb(56, 56, 56);
            ExitToolStripMenuItem.ForeColor = Color.White;
            ExitToolStripMenuItem.Name = "ExitToolStripMenuItem";
            ExitToolStripMenuItem.Size = new Size(131, 22);
            ExitToolStripMenuItem.Text = "Exit";
            // 
            // customValuesToolStripMenuItem
            // 
            customValuesToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { editToolStripMenuItem });
            customValuesToolStripMenuItem.ForeColor = Color.White;
            customValuesToolStripMenuItem.Name = "customValuesToolStripMenuItem";
            customValuesToolStripMenuItem.Size = new Size(97, 20);
            customValuesToolStripMenuItem.Text = "Custom Values";
            customValuesToolStripMenuItem.DropDownClosed += ToolStripMenuItem_DropDownClosed;
            customValuesToolStripMenuItem.DropDownOpened += ToolStripMenuItem_DropDownOpened;
            // 
            // editToolStripMenuItem
            // 
            editToolStripMenuItem.BackColor = Color.FromArgb(48, 48, 48);
            editToolStripMenuItem.ForeColor = Color.White;
            editToolStripMenuItem.Name = "editToolStripMenuItem";
            editToolStripMenuItem.Size = new Size(94, 22);
            editToolStripMenuItem.Text = "Edit";
            // 
            // customTypesToolStripMenuItem
            // 
            customTypesToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { editToolStripMenuItem1 });
            customTypesToolStripMenuItem.ForeColor = Color.White;
            customTypesToolStripMenuItem.Name = "customTypesToolStripMenuItem";
            customTypesToolStripMenuItem.Size = new Size(93, 20);
            customTypesToolStripMenuItem.Text = "Custom Types";
            customTypesToolStripMenuItem.DropDownClosed += ToolStripMenuItem_DropDownClosed;
            customTypesToolStripMenuItem.DropDownOpened += ToolStripMenuItem_DropDownOpened;
            // 
            // editToolStripMenuItem1
            // 
            editToolStripMenuItem1.BackColor = Color.FromArgb(48, 48, 48);
            editToolStripMenuItem1.DisplayStyle = ToolStripItemDisplayStyle.Text;
            editToolStripMenuItem1.ForeColor = Color.White;
            editToolStripMenuItem1.Name = "editToolStripMenuItem1";
            editToolStripMenuItem1.Size = new Size(94, 22);
            editToolStripMenuItem1.Text = "Edit";
            // 
            // ToolsTabPage
            // 
            ToolsTabPage.BorderStyle = BorderStyle.FixedSingle;
            ToolsTabPage.Controls.Add(ToolsMenuStrip);
            ToolsTabPage.Location = new Point(0, 40);
            ToolsTabPage.Name = "ToolsTabPage";
            ToolsTabPage.Size = new Size(200, 60);
            ToolsTabPage.TabIndex = 2;
            ToolsTabPage.Text = "Tools";
            ToolsTabPage.UseVisualStyleBackColor = true;
            // 
            // ToolsMenuStrip
            // 
            ToolsMenuStrip.BackColor = Color.FromArgb(56, 56, 56);
            ToolsMenuStrip.Location = new Point(0, 0);
            ToolsMenuStrip.Name = "ToolsMenuStrip";
            ToolsMenuStrip.Size = new Size(198, 24);
            ToolsMenuStrip.TabIndex = 17;
            ToolsMenuStrip.Text = "menuStrip2";
            // 
            // ShareImageTimer
            // 
            ShareImageTimer.Interval = 1000;
            ShareImageTimer.Tick += ShareImageTimer_Tick;
            // 
            // MainForm
            // 
            AutoScaleMode = AutoScaleMode.None;
            BackColor = Color.White;
            ClientSize = new Size(1015, 587);
            Controls.Add(HomeTabControl);
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            Name = "MainForm";
            Padding = new Padding(0, 29, 0, 0);
            RectColor = Color.FromArgb(48, 48, 48);
            ShowRadius = false;
            ShowShadow = true;
            ShowTitleIcon = true;
            Style = Sunny.UI.UIStyle.Custom;
            Text = "";
            TitleColor = Color.FromArgb(48, 48, 48);
            TitleHeight = 29;
            ZoomScaleRect = new Rectangle(15, 15, 800, 450);
            Load += MainForm_Load;
            HomeTabControl.ResumeLayout(false);
            HomeTabPage.ResumeLayout(false);
            HomeTabPage.PerformLayout();
            TasksTabPage.ResumeLayout(false);
            TasksTabPage.PerformLayout();
            MainListBox.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)MainDataGridView).EndInit();
            MainMenuStrip.ResumeLayout(false);
            MainMenuStrip.PerformLayout();
            ToolsTabPage.ResumeLayout(false);
            ToolsTabPage.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Sunny.UI.UITabControl HomeTabControl;
        private TabPage TasksTabPage;
        private TabPage ToolsTabPage;
        private MenuStrip MainMenuStrip;
        private ToolStripMenuItem FileStripMenuItem;
        private ToolStripMenuItem NewUserToolStripMenuItem;
        private ToolStripMenuItem UsersToolStripMenuItem;
        private ToolStripMenuItem ExitToolStripMenuItem;
        private Sunny.UI.UIButton ShareImageButton;
        private Sunny.UI.UIButton RemoveTaskButton;
        private Sunny.UI.UIButton UpdateTaskButton;
        private Sunny.UI.UIButton AddTaskButton;
        private Sunny.UI.UIButton SortByWeekButton;
        private Sunny.UI.UIButton ShowAllButton;
        private Sunny.UI.UIDataGridView MainDataGridView;
        private Sunny.UI.UIDatePicker MainDateTimePicker;
        private System.Windows.Forms.Timer ShareImageTimer;
        private Sunny.UI.UILabel ShareImageLabel;
        private Sunny.UI.UIListBox MainListBox;
        private Sunny.UI.UIComboBox uiComboBox1;
        private Label CurrentUserLabel;
        private Label CurrentUser;
        private TabPage HomeTabPage;
        private MenuStrip HomeMenuStrip;
        private Label CurrentUserMain;
        private Label CurrentUserLabelMain;
        private Panel SunPanel;
        private Sunny.UI.UILabel ConditionsLabel;
        private Sunny.UI.UILabel CelsiusLabel;
        private Sunny.UI.UILabel LocationLabel;
        private MenuStrip ToolsMenuStrip;
        private ToolStripMenuItem customValuesToolStripMenuItem;
        private ToolStripMenuItem editToolStripMenuItem;
        private ToolStripMenuItem customTypesToolStripMenuItem;
        private ToolStripMenuItem editToolStripMenuItem1;
    }
}