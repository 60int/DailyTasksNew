using System.Text;
using MaterialSkin.Controls;
using ToolsForOffice.Shared;
using DailyTasks.Forms.Classes;
using ToolsForOffice.CopyClipboard;
using ToolsForOffice.DailyTasks.Forms;

namespace ToolsForOffice.DailyTasks
{
    public partial class MainForm : MaterialForm
    {
        #region Initialize/Data

        private Form activeForm = null!;

        FileSystemWatcher watcher = new();

        private readonly CancellationTokenSource cts = new();

        readonly string MainFolder = $"Daily Tasks/";
        readonly string SettingsFolder = $"Daily Tasks/Settings/";
        readonly string ClipboardFile = "Daily Tasks/Settings/CopyClipboard.txt";
        readonly string ImageFolder = $"Daily Tasks/Images/";
        readonly string UsersFile = $"Daily Tasks/Settings/Users.txt";

        #endregion

        private static string GetMainFile()
        {
            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string filePath = Path.Combine(desktopPath, "DailyTasks-MyUser.txt");
            string username = File.ReadAllText(filePath);
            return $"Daily Tasks/Daily Tasks - {username}.csv";
        }

        private static string GetUser()
        {
            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string filePath = Path.Combine(desktopPath, "DailyTasks-MyUser.txt");
            string username = File.ReadAllText(filePath);
            return username;
        }

        public MainForm()
        {
            InitializeComponent();
            InitializeDataGridView();
            OpenChildForm(new HomePageForm());
            CurrentUserLabel.Text = GetUser();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            try
            {
                try
                {
                    string[] directories = { MainFolder, ImageFolder, SettingsFolder };
                    foreach (string directory in directories)
                    {
                        if (!Directory.Exists(directory))
                        {
                            Directory.CreateDirectory(directory);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred while creating directories: " + ex.Message);
                }
                if (!File.Exists(ClipboardFile))
                {
                    StringBuilder sb = new();
                    for (int i = 1; i <= 8; i++)
                    {
                        sb.Append($"Drop Down item {i}");
                        for (int j = 1; j <= 8; j++)
                        {
                            sb.Append($",New Item (column {j}/{i})");
                        }
                        sb.AppendLine();
                    }

                    using StreamWriter writer = new(ClipboardFile, false, Encoding.UTF8);
                    writer.Write(sb.ToString());
                }

                CreateFileSystemWatcher();

                RefreshListBox();

                if (File.Exists(UsersFile))
                {
                    foreach (User userItem in User.Deserialize(UsersFile))
                    {
                        ToolStripItem item = UsersToolStripMenuItem.DropDownItems.Add(userItem.UserName);
                        item.Click += UserItem_Click;
                    }
                }
                else
                {
                    switch (MessageBox.Show("Users file is corrupted or doesn't exist! Do you want to create a new one?", "Error", MessageBoxButtons.YesNo, MessageBoxIcon.Information))
                    {
                        case DialogResult.Yes:
                            using (FileStream fs = File.Create(UsersFile))
                            {
                                char[] value = "Default\n".ToCharArray();
                                fs.Write(Encoding.UTF8.GetBytes(value), 0, value.Length);
                            }
                            MessageBox.Show("File created!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            break;
                        case DialogResult.Cancel:
                            Environment.Exit(0);
                            break;
                        case DialogResult.No:
                            Environment.Exit(0);
                            break;
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Application couldn't start" + ex, "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        List<DailyTask> LoadDataFromCsvFiles()
        {
            List<DailyTask> allTasks = new();

            if (CurrentUserLabel.Text == "Default")
            {
                string[] filePaths = Directory.GetFiles(MainFolder, "*.csv");

                foreach (string filePath in filePaths)
                {
                    allTasks.AddRange(DailyTask.Deserialize(filePath));
                }
            }
            else
            {
                string mainFile = GetMainFile();
                if (!File.Exists(mainFile))
                {
                    using FileStream fs = File.Create(mainFile);
                }

                allTasks.AddRange(DailyTask.Deserialize(mainFile));
            }

            return allTasks;
        }

        private void CreateFileSystemWatcher()
        {
            watcher = new FileSystemWatcher
            {
                Path = ImageFolder,
                NotifyFilter = NotifyFilters.FileName | NotifyFilters.Size,
                Filter = "*.jpg"
            };
            watcher.Created += new FileSystemEventHandler(OnImageCreated);
            watcher.EnableRaisingEvents = true;
        }

        void InitializeDataGridView()
        {
            MainDataGridView.AutoGenerateColumns = false;
            MainDataGridView.Columns.Add("Day of the Week", "Day Of Week");
            MainDataGridView.Columns.Add("Title", "User");
            MainDataGridView.Columns.Add("TotalSum", "Total Sum");
            MainDataGridView.Columns.Add("NotFinished", "Not Finished");
            MainDataGridView.Columns.Add("TotalOK", "Total OK");
            MainDataGridView.Columns.Add("TotalNG", "Total NG");
            MainDataGridView.Columns.Add("Task Type", "TaskType");
        }

        void RefreshListBox(bool showCurrentWeekOnly = true)
        {
            MainListBox.Items.Clear();
            MainDataGridView.Rows.Clear();

            // Load data from CSV files
            List<DailyTask> allTasks = LoadDataFromCsvFiles(); // Pass cellTypeFilename variable to LoadDataFromCsvFiles method

            // Calculate total sum, not finished, total OK and total NG by title
            var totalSumByTitle = DailyTask.TotalSumByTitle(allTasks.ToArray());
            var notFinishedByTitle = DailyTask.NotFinishedByTitle(allTasks.ToArray());
            var totalOKByTitle = DailyTask.TotalOKByTitle(allTasks.ToArray());
            var totalNGByTitle = DailyTask.TotalNGByTitle(allTasks.ToArray());

            // Group tasks by date and title
            var tasksGroupedByDateAndTitle = allTasks.GroupBy(t => new { t.StartTime!.Value.Date, t.Title });

            // Calculate start and end dates of current week
            DateTime startOfWeek = DateTime.Today.AddDays(-(int)DateTime.Today.DayOfWeek);
            DateTime endOfWeek = startOfWeek.AddDays(7);

            // Add a row for each group
            foreach (var group in tasksGroupedByDateAndTitle)
            {
                // Check if StartTime is within current week
                if (!showCurrentWeekOnly || (group.Key.Date >= startOfWeek && group.Key.Date < endOfWeek))
                {
                    string date = group.Key.Date.ToString("d");
                    string title = group.Key.Title!;
                    int totalSum = group.Sum(t => t.TotalAmount) ?? 0;
                    int notFinished = group.Sum(t => t.AmountLeft) ?? 0;
                    int totalOK = group.Sum(t => t.TotalAmount - (t.ScrapNG + t.OtherNG)) ?? 0;
                    int totalNG = group.Sum(t => t.ScrapNG + t.OtherNG) ?? 0;
                    string taskType = group.First().TaskType!.ToString(); // Change TaskType.ToString() to TaskType

                    MainDataGridView.Rows.Add(date, title, totalSum, notFinished, totalOK, totalNG, taskType);
                }
            }

            foreach (DailyTask item in allTasks)
            {
                MainListBox.Items.Add(item);
            }
        }

        private void UserItem_Click(object? sender, EventArgs e)
        {
            CurrentUserLabel.Text = (sender! as ToolStripItem)!.Text;

            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string filePath = Path.Combine(desktopPath, "DailyTasks-MyUser.txt");
            File.WriteAllText(filePath, CurrentUserLabel.Text);
            RefreshListBox();
        }

        private void NewUserToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddUserForm form = new();
            if (form.ShowDialog() == DialogResult.OK)
            {
                ToolStripItem newUserItem = new ToolStripMenuItem(form.User!.UserName);

                newUserItem.Click += UserItem_Click;

                UsersToolStripMenuItem.DropDownItems.Add(newUserItem);

                using StreamWriter writer = new(UsersFile, true, Encoding.UTF8);

                writer.WriteLine(form.User.CSVFormat());
            }
        }

        private void MainDateTimePicker_ValueChanged(object sender, EventArgs e)
        {
            // Get the selected date
            DateTime selectedDate = MainDateTimePicker.Value;

            MainListBox.Items.Clear();
            MainDataGridView.Rows.Clear();

            // Load data from CSV files
            List<DailyTask> allTasks = LoadDataFromCsvFiles();

            var totalSumByTitle = DailyTask.TotalSumByTitle(allTasks.ToArray());
            var notFinishedByTitle = DailyTask.NotFinishedByTitle(allTasks.ToArray());
            var totalOKByTitle = DailyTask.TotalOKByTitle(allTasks.ToArray());
            var totalNGByTitle = DailyTask.TotalNGByTitle(allTasks.ToArray());

            // Filter tasks by selected date
            var tasksBySelectedDate = allTasks.Where(t => t.StartTime.HasValue && t.StartTime.Value.Date == selectedDate.Date);

            // Group tasks by date and title
            var tasksGroupedByDateAndTitle = tasksBySelectedDate.GroupBy(t => new { t.StartTime!.Value.Date, t.Title });

            // Add a row for each group
            foreach (var group in tasksGroupedByDateAndTitle)
            {
                string date = group.Key.Date.ToString("d");
                string title = group.Key.Title!;
                int totalSum = group.Sum(t => t.TotalAmount) ?? 0;
                int notFinished = group.Sum(t => t.AmountLeft) ?? 0;
                int totalOK = group.Sum(t => t.TotalAmount - (t.ScrapNG + t.OtherNG)) ?? 0;
                int totalNG = group.Sum(t => t.ScrapNG + t.OtherNG) ?? 0;
                string taskType = group.First().TaskType!;

                MainDataGridView.Rows.Add(date, title, totalSum, notFinished, totalOK, totalNG, taskType);
            }

            foreach (DailyTask item in allTasks)
            {
                MainListBox.Items.Add(item);
            }
        }

        void SaveChanges()
        {
            DailyTask[] tasks = new DailyTask[MainListBox.Items.Count];
            int i = 0;
            foreach (DailyTask item in MainListBox.Items)
            {
                tasks[i] = item;
                i++;
            }
            string mainFile = GetMainFile();
            if (!File.Exists(mainFile))
            {
                using FileStream fs = File.Create(mainFile);
            }
            DailyTask.Serialize(mainFile, tasks);
        }

        #region Main Buttons / Visuals

        private void OpenChildForm(Form childForm)
        {
            activeForm?.Close();
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            MainDisplayPanel.Controls.Add(childForm);
            childForm.BringToFront();
            childForm.Show();
        }

        private void HomeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenChildForm(new HomePageForm());
        }

        private void TasksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            activeForm.Close();
        }
        private void EditClipboardToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenChildForm(new EditClipboardForm());
        }

        private void SortByWeekButton_Click(object sender, EventArgs e)
        {
            RefreshListBox(showCurrentWeekOnly: true);
        }

        private void ShowAllButton_Click(object sender, EventArgs e)
        {
            RefreshListBox(showCurrentWeekOnly: false);
        }

        private void AddTaskButton_Click(object sender, EventArgs e)
        {
            AddTaskForm form = new(ClipboardFile);
            if (form.ShowDialog() == DialogResult.OK)
            {
                MainListBox.Items.Add(form.Task!);
                SaveChanges();
                RefreshListBox();
            }
        }

        private void UpdateTaskButton_Click(object sender, EventArgs e)
        {
            if (MainListBox.SelectedItem != null)
            {
                AddTaskForm form = new(ClipboardFile)
                {
                    Task = (DailyTask)MainListBox.SelectedItem
                };
                if (form.ShowDialog() == DialogResult.OK)
                {
                    MainListBox.Items[MainListBox.SelectedIndex] = MainListBox.SelectedItem!;
                    SaveChanges();
                    RefreshListBox();
                }
            }
        }

        private void RemoveTaskButton_Click(object sender, EventArgs e)
        {
            if (MainListBox.SelectedIndex != -1 && MessageBox.Show("Do you want to delete this item?", "Delete item?", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                MainListBox.Items.RemoveAt(MainListBox.SelectedIndex);
                SaveChanges();
                RefreshListBox();
            }
        }

        private void MainListBox_DoubleClick(object sender, EventArgs e)
        {
            if (MainListBox.SelectedItem != null)
            {
                AddTaskForm form = new(ClipboardFile)
                {
                    Task = (DailyTask)MainListBox.SelectedItem
                };
                if (form.ShowDialog() == DialogResult.OK)
                {
                    MainListBox.Items[MainListBox.SelectedIndex] = MainListBox.SelectedItem!;
                    SaveChanges();
                    RefreshListBox();
                }
            }
        }

        private void ClipboardToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                CopyClipboardForm Form = new();

                Form.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while trying to open the form: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ShareImageTimer_Tick(object sender, EventArgs e)
        {
            ShareImageTimer.Stop();
            ShareImageLabel.Visible = false;
        }

        #endregion

        #region Share Image Function / Threading

        private delegate void UpdateImageDelegate(string notification);

        private void ImageAlert(string notification)
        {
            if (ShareImageLabel.InvokeRequired)
            {
                BeginInvoke(new UpdateImageDelegate(ImageAlert), new object[] { notification });
                return;
            }

            Notification.Notification.ShowInformation(notification, 5000);
        }

        private async void OnImageCreated(object sender, FileSystemEventArgs e)
        {
            try
            {
                watcher.EnableRaisingEvents = false;
                await ProcessAsync(cts.Token);
            }
            finally
            {
                watcher.EnableRaisingEvents = true;
            }
        }

        public static FileInfo GetNewestFile(DirectoryInfo directory)
        {
            return directory.GetFiles()
                .OrderByDescending(f => f.LastWriteTime)
                .FirstOrDefault()!;
        }

        private async Task ProcessAsync(CancellationToken cancellationToken)
        {
            FileInfo newestFile = GetNewestFile(new DirectoryInfo(ImageFolder));
            if (!File.Exists(newestFile.FullName))
            {
                return;
            }
            string alert = $"{newestFile.Name.Split(" - ").FirstOrDefault()!} sent an image";
            await Task.Run(() => ImageAlert(alert), cancellationToken);
        }


        private void ShareImageButton_Click(object sender, EventArgs e)
        {
            if (Clipboard.GetDataObject() != null)
            {
                IDataObject data = Clipboard.GetDataObject()!;

                if (data.GetDataPresent(DataFormats.Bitmap))
                {
                    Image image = (Image)data.GetData(DataFormats.Bitmap, true)!;
                    Bitmap bm = new(image);

                    using (var fileStream = new FileStream(ImageFolder + $"{CurrentUserLabel.Text} - " + $"{DateTime.Now:MMdd-HH-mm-ss}.jpg", FileMode.Create))
                    using (var bufferedStream = new BufferedStream(fileStream))
                    {
                        bm.Save(bufferedStream, System.Drawing.Imaging.ImageFormat.Jpeg);
                    }

                    ShareImageTimer.Start();
                    ShareImageLabel.Text = "Image sent!";
                    ShareImageLabel.Visible = true;
                    GC.Collect();
                }
                else
                {
                    ShareImageTimer.Start();
                    ShareImageLabel.Text = "Error";
                    ShareImageLabel.Visible = true;
                    MessageBox.Show("The Data In Clipboard is not as image format");
                    GC.Collect();
                }
            }
        }


        #endregion

        //Keep window on top always

        #region Window always on top function

        //[DllImport("user32.dll")]
        //static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);

        //static readonly IntPtr HWND_TOPMOST = new IntPtr(-1);
        //static readonly IntPtr HWND_NOTOPMOST = new IntPtr(-2);
        //const uint SWP_NOMOVE = 0x0002;
        //const uint SWP_NOSIZE = 0x0001;

        //private void AlwaysOnTopCheckBox_CheckedChanged(object sender, EventArgs e)
        //{
        //    if (AlwaysOnCheckBox.Checked)
        //    {
        //        // Turn on WS_EX_TOPMOST
        //        SetWindowPos(Handle, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
        //    }
        //    else
        //    {
        //        // Turn off WS_EX_TOPMOST
        //        SetWindowPos(Handle, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
        //    }
        //}
        #endregion` 

    }
}