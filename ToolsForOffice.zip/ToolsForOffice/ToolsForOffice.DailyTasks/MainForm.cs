using Sunny.UI;
using System.Text.Json;

namespace ToolsForOffice.DailyTasks
{
    public partial class MainForm : UIForm
    {
        private static readonly HttpClient client = new();

        public MainForm()
        {
            InitializeComponent();
            LoadWeatherData();
        }

        private void LoadWeatherData()
        {
            string apiKey = "21d566ff98366dd488938f59cf6d1376";
            string city = "Budapest";
            string url = $"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={apiKey}&units=metric";

            try
            {
                HttpResponseMessage response = client.GetAsync(url).Result;
                response.EnsureSuccessStatusCode();
                string json = response.Content.ReadAsStringAsync().Result;

                using JsonDocument doc = JsonDocument.Parse(json);
                JsonElement root = doc.RootElement;
                double temperature = root.GetProperty("main").GetProperty("temp").GetDouble();
                string conditions = root.GetProperty("weather")[0].GetProperty("main").GetString()!;
                LocationLabel.Text = city;
                ConditionsLabel.Text = conditions;
                CelsiusLabel.Text = $"{temperature}��C";
            }
            catch (HttpRequestException)
            {
                ConditionsLabel.Text = "Weather data is not available";
                CelsiusLabel.Text = "";
            }
            catch (JsonException)
            {
                ConditionsLabel.Text = "Weather data is not available";
                CelsiusLabel.Text = "";
            }
        }
    }
}