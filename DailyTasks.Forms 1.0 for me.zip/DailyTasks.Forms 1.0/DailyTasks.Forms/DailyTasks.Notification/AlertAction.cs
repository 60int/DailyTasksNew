﻿namespace DailyTasks.Notification
{
    public enum AlertAction
    {
        Start,
        Wait,
        Close
    }
}
