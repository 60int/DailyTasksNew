﻿namespace DailyTasks.Notification
{
    public enum AlertType
    {
        Success,
        Information,
        Warning,
        Error,
        Custom
    }
}
