﻿using DailyTasks.Forms.Classes;

namespace DailyTasks.Forms.Forms
{
    public partial class TaskForm : Form
    {
        DailyTask? task;
        internal DailyTask? Task
        {
            get => task;
            set
            {
                task = value;
                TitleTextBox.Text = task!.Title;
                TotalNumericUpDown.Value = (int)task.TotalAmount!;
                ScrapNGNumericUpDown.Value = (int)task.ScrapNG!;
                OtherNGNumericUpDown.Value = (int)task.OtherNG!;
                AmountLeftNumericUpDown.Value = (int)task.AmountLeft!;
                NGOKNumericUpDown.Value = (int)task.NgOK!;
                CompletedCheckBox.Checked = task.Completed;
                MainDateTimePicker.Value = (DateTime)task.StartTime!;
                TypeComboBox.SelectedItem = task.TaskType;
                PriorityComboBox.SelectedIndex = (int)task.Priority;
            }
        }

        public TaskForm(string cellTypeFilename)
        {
            InitializeComponent();
            string[] lines = File.ReadAllLines(cellTypeFilename);
            foreach (string line in lines)
            {
                string cellType = line.Split(',')[0];
                TypeComboBox.Items.Add(cellType);
            }
            PriorityComboBox.DataSource = Enum.GetValues(typeof(TaskPriority));
            MaximizeBox = false;
            TitleTextBox.Text = Properties.Settings.Default.Username;
        }


        //Keep window on top always
        protected override CreateParams CreateParams
        {
            get
            {
                var cp = base.CreateParams;
                cp.ExStyle |= 8;  // Turn on WS_EX_TOPMOST
                return cp;
            }
        }

        private void OKButton_Click(object sender, EventArgs e)
        {
            if (task == null)
            {
                if (TitleTextBox.Text.Length >= 3)
                {
                    task = new DailyTask(TitleTextBox.Text, (int)TotalNumericUpDown.Value, (int)ScrapNGNumericUpDown.Value, (int)OtherNGNumericUpDown.Value, (int)AmountLeftNumericUpDown.Value, (int)NGOKNumericUpDown.Value, CompletedCheckBox.Checked, MainDateTimePicker.Value, TypeComboBox.SelectedItem.ToString(), (TaskPriority)PriorityComboBox.SelectedIndex);
                }
                else
                {
                    MessageBox.Show("The title must be 3 or less characters long!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    TitleTextBox.Focus();
                    DialogResult = DialogResult.None;
                }
            }
            else
            {
                task.Title = TitleTextBox.Text;
                task.TotalAmount = (int)TotalNumericUpDown.Value;
                task.ScrapNG = (int)ScrapNGNumericUpDown.Value;
                task.OtherNG = (int)OtherNGNumericUpDown.Value;
                task.AmountLeft = (int)AmountLeftNumericUpDown.Value;
                task.NgOK = (int)NGOKNumericUpDown.Value;
                task.Completed = CompletedCheckBox.Checked;
                task.StartTime = MainDateTimePicker.Value;
                task.TaskType = TypeComboBox.SelectedItem.ToString();
                task.Priority = (TaskPriority)PriorityComboBox.SelectedIndex;
            }
        }
    }
}
