﻿using System.Text;
using System.Reflection;
using DailyTasks.Forms.Classes;
using DailyTasks.Forms.Properties;

namespace DailyTasks.Forms.Forms
{
    public partial class CopyClipboard : Form
    {
        static readonly List<TextCell> textCells = new();

        readonly string ImageFolder = $"Daily Tasks/Images/";

        #region Graphics

        Graphics? Canvas;
        Random? rnd;

        Effect[]? Effects;

        readonly int CloudCount = 50;
        readonly int SnowflakeCount = 300;
        readonly int GreenLeafCount = 100;

        bool isCloud;
        bool isSummer;
        bool isSpring;
        bool isFall;
        bool isSnow;

        readonly Bitmap cloud = new(Resources.SingleCloud64);
        readonly Bitmap snow = new(Resources.SingleSnowflake16);
        readonly Bitmap spring = new(Resources.SingleSpringLeaf16);
        readonly Bitmap summer = new(Resources.SingleGreenLeaf16);
        readonly Bitmap fall = new(Resources.SingleAutumnLeaf16);

        #endregion

        private static void ReadText()
        {
            using StreamReader reader = new("Daily Tasks/CopyClipboard.txt", Encoding.UTF8);
            while (!reader.EndOfStream)
            {
                textCells.Add(new TextCell(reader.ReadLine()));
            }
            reader.Close();
        }

        private static void ReadTheme()
        {
            using StreamReader reader = new("Daily Tasks/Settings/CurrentTheme.txt", Encoding.UTF8);
            while (!reader.EndOfStream)
            {
                textCells.Add(new TextCell(reader.ReadLine()));
            }
            reader.Close();
        }

        public CopyClipboard()
        {
            InitializeComponent();

            if (File.Exists("Daily Tasks/CopyClipboard.txt"))
            {
                MainComboBox.DataSource = null;

                MainComboBox.Items.Clear();

                if (textCells.Count == 0)
                {
                    ReadText();
                }

                MainComboBox.DataSource = textCells;

                MainComboBox.SelectedIndex = 0;

                #region Visuals / UI

                MaximizeBox = false;

                MainLabel.Visible = false;
                CopyLabel.Visible = false;

                SkinsButton.Visible = true;
                SkinsButton.Enabled = true;

                CancelButton.Visible = false;
                
                CloudButton.Visible = false;
                SnowButton.Visible = false;
                SpringButton.Visible = false;
                SummerButton.Visible = false;
                FallButton.Visible = false;

                #endregion
            }
            else
            {
                string DefaultText = "Drop Down item 1,New Item (column 1/1),New Item (column 2/1),New Item (column 3/1),New Item (column 4/1),New Item (column 5/1),New Item (column 6/1),New Item (column 7/1),New Item (column 8/1)" + "\n" +
                         "Drop Down item 2,New Item (column 1/2),New Item (column 2/2),New Item (column 3/2),New Item (column 4/2),New Item (column 5/2),New Item (column 6/2),New Item (column 7/2),New Item (column 8/2)" + "\n" +
                         "Drop Down item 3,New Item (column 1/3),New Item (column 2/3),New Item (column 3/3),New Item (column 4/3),New Item (column 5/3),New Item (column 6/3),New Item (column 7/3),New Item (column 8/3)" + "\n" +
                         "Drop Down item 4,New Item (column 1/4),New Item (column 2/4),New Item (column 3/4),New Item (column 4/4),New Item (column 5/4),New Item (column 6/4),New Item (column 7/4),New Item (column 8/4)" + "\n" +
                         "Drop Down item 5,New Item (column 1/5),New Item (column 2/5),New Item (column 3/5),New Item (column 4/5),New Item (column 5/5),New Item (column 6/5),New Item (column 7/5),New Item (column 8/5)" + "\n" +
                         "Drop Down item 6,New Item (column 1/6),New Item (column 2/6),New Item (column 3/6),New Item (column 4/6),New Item (column 5/6),New Item (column 6/6),New Item (column 7/6),New Item (column 8/6)" + "\n" +
                         "Drop Down item 7,New Item (column 1/7),New Item (column 2/7),New Item (column 3/7),New Item (column 4/7),New Item (column 5/7),New Item (column 6/7),New Item (column 7/7),New Item (column 8/7)" + "\n" +
                         "Drop Down item 8,New Item (column 1/8),New Item (column 2/8),New Item (column 3/8),New Item (column 4/8),New Item (column 5/8),New Item (column 6/8),New Item (column 7/8),New Item (column 8/8)" + "\n";

                switch (MessageBox.Show("Text file is corrupted or doesn't exist! Do you want to create a new one?", "Error", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning))
                {
                    case DialogResult.Yes:
                        using (FileStream fs = File.Create("Daily Tasks/CopyClipboard.txt"))
                        {
                            char[] value = DefaultText.ToCharArray();
                            fs.Write(Encoding.UTF8.GetBytes(value), 0, value.Length);
                        }
                        MessageBox.Show("Text file created! Please reopen the application.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        Environment.Exit(0);
                        break;
                    case DialogResult.Cancel:
                        Environment.Exit(0);
                        break;
                    case DialogResult.No:
                        Environment.Exit(0);
                        break;
                }
            }
        }

        private void MainComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                // Define an array of properties that correspond to each possible value of MainComboBox.SelectedIndex
                PropertyInfo[] properties = new PropertyInfo[] { typeof(TextCell).GetProperty("ColOne")!, typeof(TextCell).GetProperty("ColTwo")!, typeof(TextCell).GetProperty("ColThree")!,
                    typeof(TextCell).GetProperty("ColFour")!,typeof(TextCell).GetProperty("ColFive")!, typeof(TextCell).GetProperty("ColSix")!, typeof(TextCell).GetProperty("ColSeven")!,  typeof(TextCell).GetProperty("ColEight")!/* etc... */ };

                // Get the selected property based on the value of MainComboBox.SelectedIndex
                PropertyInfo selectedProperty = properties[MainComboBox.SelectedIndex];

                // Clear the MainListBox items
                MainListBox.Items.Clear();

                // Add the values of the selected property for each TextCell in textCells to MainListBox
                foreach (TextCell item in textCells)
                {
                    MainListBox.Items.Add(selectedProperty.GetValue(item)!);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hiba történt, indítsd újra a programot." + ex.Message, "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void MainListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (MainListBox.SelectedIndex != -1)
                {
                    MainLabel.Text = MainListBox.Text;
                    if (MainComboBox.SelectedIndex == 6)
                    {
                        string macro1 = "Sub Picture()\r\n'\r\n' Picture Macro\r\n'\r\n' Fast Key : Ctrl+q\r\n'\r\n    ActiveSheet.Paste\r\n    Selection.ShapeRange.LockAspectRatio = msoFalse\r\n    Selection.ShapeRange.Height = 144\r\n    Selection.ShapeRange.Width = 172.8\r\n    Selection.Placement = xlMoveAndSize\r\n    Selection.ShapeRange.IncrementTop 0.8823622047\r\n\r\nEnd Sub\r\n\r\n\r\n";
                        Clipboard.SetText(macro1);
                    }
                    else
                    {
                        Clipboard.SetText(MainLabel.Text);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hiba történt, indítsd újra a programot." + ex.Message, "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MainListBox_Click(object sender, EventArgs e)
        {
            CopyTimer.Interval = 1000;
            CopyTimer.Start();
            MainLabel.Visible = true;
            CopyLabel.Visible = true;
            MainListBox.Refresh();
            GC.Collect();
        }

        private void CopyTimer_Tick(object sender, EventArgs e)
        {
            CopyTimer.Stop();
            MainLabel.Visible = false;
            CopyLabel.Visible = false;
        }

        private void CameraButton_Click(object sender, EventArgs e)
        {
            if (Clipboard.GetDataObject() != null)
            {
                IDataObject data = Clipboard.GetDataObject()!;

                if (data.GetDataPresent(DataFormats.Bitmap))
                {
                    Image image = (Image)data.GetData(DataFormats.Bitmap, true)!;

                    Bitmap bm = new(image);

                    bm.Save(ImageFolder + $"{Properties.Settings.Default.Username} - " + $"{DateTime.Now:MMdd-HH-mm-ss}.jpg", System.Drawing.Imaging.ImageFormat.Jpeg);

                    CopyTimer.Interval = 1000;
                    CopyTimer.Start();
                    MainLabel.Text = "Image sent!";
                    MainLabel.Visible = true;
                    GC.Collect();
                }
                else
                {
                    CopyTimer.Interval = 1000;
                    CopyTimer.Start();
                    MainLabel.Text = "Error";
                    MainLabel.Visible = true;
                    MessageBox.Show("The Data In Clipboard is not as image format");
                    GC.Collect();
                }
            }
        }

        #region All Animations
        private void MakeCloud()
        {
            float addSpeed = 2 + (float)rnd!.NextDouble();

            for (int i = 0; i < CloudCount; i++)
            {
                Effects![i] = new Effect(rnd!.Next(-100, 550), rnd!.Next(0, 580), addSpeed, rnd!.Next(16, 64), 1, cloud);
            }
        }
        private void MakeSnow()
        {
            float addSpeed = 2 + (float)rnd!.NextDouble();

            for (int i = 0; i < SnowflakeCount; i++)
            {
                Effects![i] = new Effect(rnd!.Next(-100, 550), rnd!.Next(0, 580), addSpeed / 1.2F, rnd!.Next(8, 16), 1, snow);
            }
        }
        private void MakeSpring()
        {
            float addSpeed = 2 + (float)rnd!.NextDouble() + (float)rnd!.NextDouble() + (float)rnd!.NextDouble();

            for (int i = 0; i < SnowflakeCount; i++)
            {
                Effects![i] = new Effect(rnd!.Next(-100, 550), rnd!.Next(0, 580), addSpeed / 1.2F, rnd!.Next(8, 32), 1, spring);
            }
        }
        private void MakeSummer()
        {
            float addSpeed = 2 + (float)rnd!.NextDouble() + (float)rnd!.NextDouble() + (float)rnd!.NextDouble();

            for (int i = 0; i < GreenLeafCount; i++)
            {
                Effects![i] = new Effect(rnd!.Next(-100, 550), rnd!.Next(0, 580), addSpeed / 1.2F, rnd!.Next(8, 16), 1, summer);
            }
        }
        private void MakeAutumn()
        {
            float addSpeed = 2 + (float)rnd!.NextDouble() + (float)rnd!.NextDouble() + (float)rnd!.NextDouble();

            for (int i = 0; i < SnowflakeCount; i++)
            {
                Effects![i] = new Effect(rnd!.Next(-100, 550), rnd!.Next(0, 580), addSpeed / 1.5F, rnd!.Next(8, 16), 1, fall);
            }
        }
        private void StartSnow()
        {
            rnd = new Random();

            Bitmap myBitmap = new(Width, Height);

            MainPictureBox.Image = myBitmap;

            Canvas = Graphics.FromImage(MainPictureBox.Image);
            Effects = new Effect[SnowflakeCount];
            MakeSnow();
        }
        private void StartSpring()
        {
            rnd = new Random();

            Bitmap myBitmap = new(Width, Height);

            MainPictureBox.Image = myBitmap;

            Canvas = Graphics.FromImage(MainPictureBox.Image);
            Effects = new Effect[SnowflakeCount];
            MakeSpring();
        }
        private void StartSummer()
        {
            rnd = new Random();

            Bitmap myBitmap = new(Width, Height);

            MainPictureBox.Image = myBitmap;

            Canvas = Graphics.FromImage(MainPictureBox.Image);
            Effects = new Effect[GreenLeafCount];
            MakeSummer();
        }
        private void StartFall()
        {
            rnd = new Random();

            Bitmap myBitmap = new(Width, Height);

            MainPictureBox.Image = myBitmap;

            Canvas = Graphics.FromImage(MainPictureBox.Image);
            Effects = new Effect[SnowflakeCount];
            MakeAutumn();
        }
        private void StartCloud()
        {
            rnd = new Random();

            Bitmap myBitmap = new(Width, Height);

            MainPictureBox.Image = myBitmap;

            Canvas = Graphics.FromImage(MainPictureBox.Image);
            Effects = new Effect[CloudCount];
            MakeCloud();
        }

        private void MainPictureBox_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

            Canvas?.Clear(Color.White);

            if (isSnow)
            {
                for (int i = 0; i < SnowflakeCount; i++)
                {
                    Canvas!.DrawImage(Effects![i].Img, Effects[i].X, Effects[i].Y, Effects[i].Size, Effects[i].Size);

                    Effects[i].Time += 0.9f;

                    if (Effects[i].Y > 600)
                    {
                        Effects[i].Y = -25;
                        Effects[i].Time = 0;
                    }
                    if (Effects[i].X > 580 & Effects[i].X < -5)
                    {
                        Effects[i].X = rnd!.Next(0, 580);
                    }
                    else
                    {
                        Effects[i].Y += Effects[i].Speed + rnd!.Next(-1, 0);
                    }
                }
            }
            else if (isCloud)
            {
                for (int i = 0; i < CloudCount; i++)
                {
                    Canvas!.DrawImage(Effects![i].Img, Effects[i].X, Effects[i].Y, Effects[i].Size, Effects[i].Size);

                    Effects[i].Time += 0.9f;

                    if (Effects[i].X > 700)
                    {
                        Effects[i].X = -25;
                        Effects[i].Time = 0;
                    }
                    if (Effects[i].Y > 580 & Effects[i].Y < -5)
                    {
                        Effects[i].Y = rnd!.Next(0, 580);
                    }
                    else
                    {
                        Effects[i].X += Effects[i].Speed + rnd!.Next(-1, 0);
                    }
                }
            }
            else if (isFall)
            {
                for (int i = 0; i < SnowflakeCount; i++)
                {
                    Canvas!.DrawImage(Effects![i].Img, Effects[i].X, Effects[i].Y, Effects[i].Size, Effects[i].Size);

                    Effects[i].Time += 0.9f;
                    Effects[i].X += (float)Math.Sin(Effects[i].Time) * 2;

                    if (Effects[i].Y > 600)
                    {
                        Effects[i].Y = -15;
                        Effects[i].Time = 0;
                    }
                    if (Effects[i].X > 580 & Effects[i].X < -5)
                    {
                        Effects[i].X = rnd!.Next(0, 580);
                    }
                    else
                    {
                        Effects[i].Y += Effects[i].Speed + rnd!.Next(-1, 0);
                    }
                }
            }
            else if (isSpring)
            {
                for (int i = 0; i < SnowflakeCount; i++)
                {
                    Canvas!.DrawImage(Effects![i].Img, Effects[i].X, Effects[i].Y, Effects[i].Size, Effects[i].Size);

                    Effects[i].Time += 0.2f;

                    if (Effects[i].Y > 600)
                    {
                        Effects[i].Y = -15;
                        Effects[i].Time = 0;
                    }
                    if (Effects[i].X > 580 & Effects[i].X < -5)
                    {
                        Effects[i].X = rnd!.Next(0, 580);
                    }
                    else
                    {
                        Effects[i].Y += Effects[i].Speed + rnd!.Next(-1, 0);
                    }
                }
            }
            else if (isSummer)
            {
                for (int i = 0; i < GreenLeafCount; i++)
                {
                    Canvas!.DrawImage(Effects![i].Img, Effects[i].X, Effects[i].Y, Effects[i].Size, Effects[i].Size);

                    Effects[i].Time += 0.2f;

                    if (Effects[i].Y > 600)
                    {
                        Effects[i].Y = -15;
                        Effects[i].Time = 0;
                    }
                    if (Effects[i].X > 580 & Effects[i].X < -5)
                    {
                        Effects[i].X = rnd!.Next(0, 580);
                    }
                    else
                    {
                        Effects[i].Y += Effects[i].Speed + rnd!.Next(-1, 0);
                    }
                }
            }
        }


        #endregion

        private void TimerUpdate_Tick(object sender, EventArgs e)
        {
            MainPictureBox.Invalidate();
        }

        private void SkinsButton_Click(object sender, EventArgs e)
        {

            SkinsButton.Visible = false;
            SkinsButton.Enabled = false;
            CancelButton.Visible = true;
            CloudButton.Visible = true;
            SnowButton.Visible = true;
            SpringButton.Visible = true;
            SummerButton.Visible = true;
            FallButton.Visible = true;
        }

        private void CloudButton_Click(object sender, EventArgs e)
        {
            StartCloud();

            //Settings.Default = "Cloud";
            //Settings.Default.Save();

            isSpring = false;
            isSnow = false;
            isFall = false;
            isSummer = false;
            isCloud = true;

            MainPictureBox.Invalidate();
            SkinsButton.Visible = true;
            SkinsButton.Enabled = true;

            CancelButton.Visible = false;
            CloudButton.Visible = false;
            SnowButton.Visible = false;
            SpringButton.Visible = false;
            SummerButton.Visible = false;
            FallButton.Visible = false;
        }

        private void SummerButton_Click(object sender, EventArgs e)
        {
            StartSummer();

            //Settings.Default.gh = "Summer";
            //Settings.Default.Save();

            isCloud = false;
            isSpring = false;
            isSnow = false;
            isFall = false;
            isSummer = true;

            MainPictureBox.Invalidate();
            SkinsButton.Visible = true;
            SkinsButton.Enabled = true;

            CancelButton.Visible = false;
            CloudButton.Visible = false;
            SnowButton.Visible = false;
            SpringButton.Visible = false;
            SummerButton.Visible = false;
            FallButton.Visible = false;
        }

        private void SpringButton_Click(object sender, EventArgs e)
        {
            StartSpring();

            //Settings.Default.gh = "Spring";
            //Settings.Default.Save();

            isCloud = false;
            isSummer = false;
            isSnow = false;
            isFall = false;
            isSpring = true;

            MainPictureBox.Invalidate();
            SkinsButton.Visible = true;
            SkinsButton.Enabled = true;

            CancelButton.Visible = false;
            CloudButton.Visible = false;
            SnowButton.Visible = false;
            SpringButton.Visible = false;
            SummerButton.Visible = false;
            FallButton.Visible = false;
        }

        private void FallButton_Click(object sender, EventArgs e)
        {
            StartFall();

            //Settings.Default.gh = "Fall";
            //Settings.Default.Save();

            isCloud = false;
            isSpring = false;
            isSummer = false;
            isSnow = false;
            isFall = true;

            MainPictureBox.Invalidate();
            SkinsButton.Visible = true;
            SkinsButton.Enabled = true;

            CancelButton.Visible = false;
            CloudButton.Visible = false;
            SnowButton.Visible = false;
            SpringButton.Visible = false;
            SummerButton.Visible = false;
            FallButton.Visible = false;
        }

        private void SnowButton_Click(object sender, EventArgs e)
        {
            StartSnow();

            //Settings.Default.gh = "Snow";
            //Settings.Default.Save();

            isCloud = false;
            isSpring = false;
            isSummer = false;
            isFall = false;
            isSnow = true;

            MainPictureBox.Invalidate();
            SkinsButton.Visible = true;
            SkinsButton.Enabled = true;

            CancelButton.Visible = false;
            CloudButton.Visible = false;
            SnowButton.Visible = false;
            SpringButton.Visible = false;
            SummerButton.Visible = false;
            FallButton.Visible = false;
        }

        private void CancelButton_Click(object sender, EventArgs e)
        {
            isCloud = false;
            isSpring = false;
            isSummer = false;
            isFall = false;
            isSnow = false;

            MainPictureBox.Invalidate();
            SkinsButton.Visible = true;
            SkinsButton.Enabled = true;

            CancelButton.Visible = false;
            CloudButton.Visible = false;
            SnowButton.Visible = false;
            SpringButton.Visible = false;
            SummerButton.Visible = false;
            FallButton.Visible = false;
        }

        //Keep window on top always
        protected override CreateParams CreateParams
        {
            get
            {
                var cp = base.CreateParams;
                cp.ExStyle |= 8;  // Turn on WS_EX_TOPMOST
                return cp;
            }
        }
    }
}
