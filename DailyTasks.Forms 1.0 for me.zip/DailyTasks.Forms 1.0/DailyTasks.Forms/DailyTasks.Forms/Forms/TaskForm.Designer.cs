﻿namespace DailyTasks.Forms.Forms
{
    partial class TaskForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TaskForm));
            this.TaskTitleLabel = new System.Windows.Forms.Label();
            this.TotalLabel = new System.Windows.Forms.Label();
            this.CompletedCheckBox = new System.Windows.Forms.CheckBox();
            this.NGLabel = new System.Windows.Forms.Label();
            this.AmountLeftLabel = new System.Windows.Forms.Label();
            this.MainDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.TypeLabel = new System.Windows.Forms.Label();
            this.PriorityLabel = new System.Windows.Forms.Label();
            this.OKButton = new System.Windows.Forms.Button();
            this.CancelButton = new System.Windows.Forms.Button();
            this.TitleTextBox = new System.Windows.Forms.TextBox();
            this.TotalNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.ScrapNGNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.AmountLeftNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.TypeComboBox = new System.Windows.Forms.ComboBox();
            this.PriorityComboBox = new System.Windows.Forms.ComboBox();
            this.OtherNGNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.NGOKNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.NGOKLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.TotalNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ScrapNGNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AmountLeftNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.OtherNGNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NGOKNumericUpDown)).BeginInit();
            this.SuspendLayout();
            // 
            // TaskTitleLabel
            // 
            this.TaskTitleLabel.AutoSize = true;
            this.TaskTitleLabel.Location = new System.Drawing.Point(60, 16);
            this.TaskTitleLabel.Name = "TaskTitleLabel";
            this.TaskTitleLabel.Size = new System.Drawing.Size(30, 15);
            this.TaskTitleLabel.TabIndex = 0;
            this.TaskTitleLabel.Text = "User";
            // 
            // TotalLabel
            // 
            this.TotalLabel.AutoSize = true;
            this.TotalLabel.Location = new System.Drawing.Point(58, 44);
            this.TotalLabel.Name = "TotalLabel";
            this.TotalLabel.Size = new System.Drawing.Size(32, 15);
            this.TotalLabel.TabIndex = 1;
            this.TotalLabel.Text = "Total";
            // 
            // CompletedCheckBox
            // 
            this.CompletedCheckBox.AutoSize = true;
            this.CompletedCheckBox.Location = new System.Drawing.Point(96, 187);
            this.CompletedCheckBox.Name = "CompletedCheckBox";
            this.CompletedCheckBox.Size = new System.Drawing.Size(85, 19);
            this.CompletedCheckBox.TabIndex = 6;
            this.CompletedCheckBox.Text = "Completed";
            this.CompletedCheckBox.UseVisualStyleBackColor = true;
            // 
            // NGLabel
            // 
            this.NGLabel.AutoSize = true;
            this.NGLabel.Location = new System.Drawing.Point(11, 73);
            this.NGLabel.Name = "NGLabel";
            this.NGLabel.Size = new System.Drawing.Size(79, 15);
            this.NGLabel.TabIndex = 3;
            this.NGLabel.Text = "Scrap/Double";
            // 
            // AmountLeftLabel
            // 
            this.AmountLeftLabel.AutoSize = true;
            this.AmountLeftLabel.Location = new System.Drawing.Point(16, 131);
            this.AmountLeftLabel.Name = "AmountLeftLabel";
            this.AmountLeftLabel.Size = new System.Drawing.Size(74, 15);
            this.AmountLeftLabel.TabIndex = 4;
            this.AmountLeftLabel.Text = "Amount Left";
            // 
            // MainDateTimePicker
            // 
            this.MainDateTimePicker.Location = new System.Drawing.Point(96, 212);
            this.MainDateTimePicker.Name = "MainDateTimePicker";
            this.MainDateTimePicker.Size = new System.Drawing.Size(297, 23);
            this.MainDateTimePicker.TabIndex = 7;
            // 
            // TypeLabel
            // 
            this.TypeLabel.AutoSize = true;
            this.TypeLabel.Location = new System.Drawing.Point(59, 243);
            this.TypeLabel.Name = "TypeLabel";
            this.TypeLabel.Size = new System.Drawing.Size(31, 15);
            this.TypeLabel.TabIndex = 6;
            this.TypeLabel.Text = "Type";
            // 
            // PriorityLabel
            // 
            this.PriorityLabel.AutoSize = true;
            this.PriorityLabel.Location = new System.Drawing.Point(45, 272);
            this.PriorityLabel.Name = "PriorityLabel";
            this.PriorityLabel.Size = new System.Drawing.Size(45, 15);
            this.PriorityLabel.TabIndex = 7;
            this.PriorityLabel.Text = "Priority";
            // 
            // OKButton
            // 
            this.OKButton.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.OKButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Azure;
            this.OKButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Lavender;
            this.OKButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.OKButton.Location = new System.Drawing.Point(149, 303);
            this.OKButton.Name = "OKButton";
            this.OKButton.Size = new System.Drawing.Size(119, 26);
            this.OKButton.TabIndex = 10;
            this.OKButton.Text = "OK";
            this.OKButton.UseVisualStyleBackColor = true;
            this.OKButton.Click += new System.EventHandler(this.OKButton_Click);
            // 
            // CancelButton
            // 
            this.CancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.CancelButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Azure;
            this.CancelButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Lavender;
            this.CancelButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CancelButton.Location = new System.Drawing.Point(274, 303);
            this.CancelButton.Name = "CancelButton";
            this.CancelButton.Size = new System.Drawing.Size(119, 26);
            this.CancelButton.TabIndex = 11;
            this.CancelButton.Text = "Cancel";
            this.CancelButton.UseVisualStyleBackColor = true;
            // 
            // TitleTextBox
            // 
            this.TitleTextBox.Location = new System.Drawing.Point(96, 13);
            this.TitleTextBox.Name = "TitleTextBox";
            this.TitleTextBox.Size = new System.Drawing.Size(297, 23);
            this.TitleTextBox.TabIndex = 11;
            // 
            // TotalNumericUpDown
            // 
            this.TotalNumericUpDown.Location = new System.Drawing.Point(96, 42);
            this.TotalNumericUpDown.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.TotalNumericUpDown.Name = "TotalNumericUpDown";
            this.TotalNumericUpDown.Size = new System.Drawing.Size(297, 23);
            this.TotalNumericUpDown.TabIndex = 1;
            // 
            // ScrapNGNumericUpDown
            // 
            this.ScrapNGNumericUpDown.Location = new System.Drawing.Point(96, 71);
            this.ScrapNGNumericUpDown.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.ScrapNGNumericUpDown.Name = "ScrapNGNumericUpDown";
            this.ScrapNGNumericUpDown.Size = new System.Drawing.Size(297, 23);
            this.ScrapNGNumericUpDown.TabIndex = 2;
            // 
            // AmountLeftNumericUpDown
            // 
            this.AmountLeftNumericUpDown.Location = new System.Drawing.Point(96, 129);
            this.AmountLeftNumericUpDown.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.AmountLeftNumericUpDown.Name = "AmountLeftNumericUpDown";
            this.AmountLeftNumericUpDown.Size = new System.Drawing.Size(297, 23);
            this.AmountLeftNumericUpDown.TabIndex = 4;
            // 
            // TypeComboBox
            // 
            this.TypeComboBox.FormattingEnabled = true;
            this.TypeComboBox.Location = new System.Drawing.Point(96, 240);
            this.TypeComboBox.Name = "TypeComboBox";
            this.TypeComboBox.Size = new System.Drawing.Size(297, 23);
            this.TypeComboBox.TabIndex = 8;
            // 
            // PriorityComboBox
            // 
            this.PriorityComboBox.FormattingEnabled = true;
            this.PriorityComboBox.Location = new System.Drawing.Point(96, 269);
            this.PriorityComboBox.Name = "PriorityComboBox";
            this.PriorityComboBox.Size = new System.Drawing.Size(297, 23);
            this.PriorityComboBox.TabIndex = 9;
            // 
            // OtherNGNumericUpDown
            // 
            this.OtherNGNumericUpDown.Location = new System.Drawing.Point(96, 100);
            this.OtherNGNumericUpDown.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.OtherNGNumericUpDown.Name = "OtherNGNumericUpDown";
            this.OtherNGNumericUpDown.Size = new System.Drawing.Size(297, 23);
            this.OtherNGNumericUpDown.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 102);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 15);
            this.label1.TabIndex = 11;
            this.label1.Text = "Other NG";
            // 
            // NGOKNumericUpDown
            // 
            this.NGOKNumericUpDown.Location = new System.Drawing.Point(96, 158);
            this.NGOKNumericUpDown.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.NGOKNumericUpDown.Name = "NGOKNumericUpDown";
            this.NGOKNumericUpDown.Size = new System.Drawing.Size(297, 23);
            this.NGOKNumericUpDown.TabIndex = 5;
            // 
            // NGOKLabel
            // 
            this.NGOKLabel.AutoSize = true;
            this.NGOKLabel.Location = new System.Drawing.Point(45, 160);
            this.NGOKLabel.Name = "NGOKLabel";
            this.NGOKLabel.Size = new System.Drawing.Size(45, 15);
            this.NGOKLabel.TabIndex = 13;
            this.NGOKLabel.Text = "NG/OK";
            // 
            // TaskForm
            // 
            this.AcceptButton = this.OKButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(405, 344);
            this.Controls.Add(this.NGOKNumericUpDown);
            this.Controls.Add(this.NGOKLabel);
            this.Controls.Add(this.OtherNGNumericUpDown);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.PriorityComboBox);
            this.Controls.Add(this.TypeComboBox);
            this.Controls.Add(this.AmountLeftNumericUpDown);
            this.Controls.Add(this.ScrapNGNumericUpDown);
            this.Controls.Add(this.TotalNumericUpDown);
            this.Controls.Add(this.TitleTextBox);
            this.Controls.Add(this.CancelButton);
            this.Controls.Add(this.OKButton);
            this.Controls.Add(this.PriorityLabel);
            this.Controls.Add(this.TypeLabel);
            this.Controls.Add(this.MainDateTimePicker);
            this.Controls.Add(this.AmountLeftLabel);
            this.Controls.Add(this.NGLabel);
            this.Controls.Add(this.CompletedCheckBox);
            this.Controls.Add(this.TotalLabel);
            this.Controls.Add(this.TaskTitleLabel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "TaskForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add/Update Task";
            ((System.ComponentModel.ISupportInitialize)(this.TotalNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ScrapNGNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AmountLeftNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.OtherNGNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NGOKNumericUpDown)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label TaskTitleLabel;
        private Label TotalLabel;
        private CheckBox CompletedCheckBox;
        private Label NGLabel;
        private Label AmountLeftLabel;
        private DateTimePicker MainDateTimePicker;
        private Label TypeLabel;
        private Label PriorityLabel;
        private Button OKButton;
        private Button CancelButton;
        private TextBox TitleTextBox;
        private NumericUpDown TotalNumericUpDown;
        private NumericUpDown ScrapNGNumericUpDown;
        private NumericUpDown AmountLeftNumericUpDown;
        private ComboBox TypeComboBox;
        private ComboBox PriorityComboBox;
        private NumericUpDown OtherNGNumericUpDown;
        private Label label1;
        private NumericUpDown NGOKNumericUpDown;
        private Label NGOKLabel;
    }
}