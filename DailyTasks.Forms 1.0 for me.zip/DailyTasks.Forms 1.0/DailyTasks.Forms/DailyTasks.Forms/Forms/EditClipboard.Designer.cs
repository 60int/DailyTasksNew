﻿namespace DailyTasks.Forms.Forms
{
    partial class EditClipboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EditClipboard));
            MainDataGridView = new DataGridView();
            OKButton = new Button();
            CancelButton = new Button();
            ((System.ComponentModel.ISupportInitialize)MainDataGridView).BeginInit();
            SuspendLayout();
            // 
            // MainDataGridView
            // 
            MainDataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            MainDataGridView.Location = new Point(12, 12);
            MainDataGridView.Name = "MainDataGridView";
            MainDataGridView.RowTemplate.Height = 25;
            MainDataGridView.Size = new Size(696, 259);
            MainDataGridView.TabIndex = 0;
            // 
            // OKButton
            // 
            OKButton.DialogResult = DialogResult.OK;
            OKButton.FlatAppearance.MouseDownBackColor = Color.Azure;
            OKButton.FlatAppearance.MouseOverBackColor = Color.Lavender;
            OKButton.FlatStyle = FlatStyle.Flat;
            OKButton.Location = new Point(259, 277);
            OKButton.Name = "OKButton";
            OKButton.Size = new Size(119, 26);
            OKButton.TabIndex = 6;
            OKButton.Text = "OK";
            OKButton.UseVisualStyleBackColor = true;
            OKButton.Click += OKButton_Click;
            // 
            // CancelButton
            // 
            CancelButton.DialogResult = DialogResult.Cancel;
            CancelButton.FlatAppearance.MouseDownBackColor = Color.Azure;
            CancelButton.FlatAppearance.MouseOverBackColor = Color.Lavender;
            CancelButton.FlatStyle = FlatStyle.Flat;
            CancelButton.Location = new Point(384, 277);
            CancelButton.Name = "CancelButton";
            CancelButton.Size = new Size(119, 26);
            CancelButton.TabIndex = 7;
            CancelButton.Text = "Cancel";
            CancelButton.UseVisualStyleBackColor = true;
            // 
            // EditClipboard
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(720, 311);
            Controls.Add(CancelButton);
            Controls.Add(OKButton);
            Controls.Add(MainDataGridView);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "EditClipboard";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Edit Clipboard";
            ((System.ComponentModel.ISupportInitialize)MainDataGridView).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView MainDataGridView;
        private Button OKButton;
        private Button CancelButton;
    }
}