﻿namespace DailyTasks.Forms.Forms
{
    partial class CopyClipboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CopyClipboard));
            this.MainPictureBox = new System.Windows.Forms.PictureBox();
            this.MainComboBox = new System.Windows.Forms.ComboBox();
            this.SkinsButton = new System.Windows.Forms.Button();
            this.MainListBox = new System.Windows.Forms.ListBox();
            this.CameraButton = new System.Windows.Forms.Button();
            this.CopyTimer = new System.Windows.Forms.Timer(this.components);
            this.TimerUpdate = new System.Windows.Forms.Timer(this.components);
            this.CloudButton = new System.Windows.Forms.Button();
            this.SummerButton = new System.Windows.Forms.Button();
            this.SpringButton = new System.Windows.Forms.Button();
            this.FallButton = new System.Windows.Forms.Button();
            this.SnowButton = new System.Windows.Forms.Button();
            this.CancelButton = new System.Windows.Forms.Button();
            this.MainLabel = new System.Windows.Forms.Label();
            this.CopyLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.MainPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // MainPictureBox
            // 
            this.MainPictureBox.Location = new System.Drawing.Point(-18, 0);
            this.MainPictureBox.Name = "MainPictureBox";
            this.MainPictureBox.Size = new System.Drawing.Size(213, 200);
            this.MainPictureBox.TabIndex = 0;
            this.MainPictureBox.TabStop = false;
            this.MainPictureBox.Paint += new System.Windows.Forms.PaintEventHandler(this.MainPictureBox_Paint);
            // 
            // MainComboBox
            // 
            this.MainComboBox.FormattingEnabled = true;
            this.MainComboBox.Location = new System.Drawing.Point(12, 12);
            this.MainComboBox.Name = "MainComboBox";
            this.MainComboBox.Size = new System.Drawing.Size(155, 23);
            this.MainComboBox.TabIndex = 1;
            this.MainComboBox.SelectedIndexChanged += new System.EventHandler(this.MainComboBox_SelectedIndexChanged);
            // 
            // SkinsButton
            // 
            this.SkinsButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SkinsButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SkinsButton.Location = new System.Drawing.Point(173, 12);
            this.SkinsButton.Name = "SkinsButton";
            this.SkinsButton.Size = new System.Drawing.Size(10, 23);
            this.SkinsButton.TabIndex = 2;
            this.SkinsButton.UseVisualStyleBackColor = true;
            this.SkinsButton.Click += new System.EventHandler(this.SkinsButton_Click);
            // 
            // MainListBox
            // 
            this.MainListBox.FormattingEnabled = true;
            this.MainListBox.ItemHeight = 15;
            this.MainListBox.Location = new System.Drawing.Point(12, 41);
            this.MainListBox.Name = "MainListBox";
            this.MainListBox.Size = new System.Drawing.Size(171, 124);
            this.MainListBox.TabIndex = 3;
            this.MainListBox.Click += new System.EventHandler(this.MainListBox_Click);
            this.MainListBox.SelectedIndexChanged += new System.EventHandler(this.MainListBox_SelectedIndexChanged);
            // 
            // CameraButton
            // 
            this.CameraButton.BackColor = System.Drawing.Color.Transparent;
            this.CameraButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("CameraButton.BackgroundImage")));
            this.CameraButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.CameraButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CameraButton.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.CameraButton.Location = new System.Drawing.Point(161, 144);
            this.CameraButton.Name = "CameraButton";
            this.CameraButton.Size = new System.Drawing.Size(20, 20);
            this.CameraButton.TabIndex = 4;
            this.CameraButton.UseVisualStyleBackColor = false;
            this.CameraButton.Click += new System.EventHandler(this.CameraButton_Click);
            // 
            // CopyTimer
            // 
            this.CopyTimer.Tick += new System.EventHandler(this.CopyTimer_Tick);
            // 
            // TimerUpdate
            // 
            this.TimerUpdate.Enabled = true;
            this.TimerUpdate.Interval = 30;
            this.TimerUpdate.Tick += new System.EventHandler(this.TimerUpdate_Tick);
            // 
            // CloudButton
            // 
            this.CloudButton.BackColor = System.Drawing.Color.SkyBlue;
            this.CloudButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CloudButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CloudButton.ForeColor = System.Drawing.Color.SkyBlue;
            this.CloudButton.Location = new System.Drawing.Point(12, 171);
            this.CloudButton.Name = "CloudButton";
            this.CloudButton.Size = new System.Drawing.Size(10, 23);
            this.CloudButton.TabIndex = 5;
            this.CloudButton.UseVisualStyleBackColor = false;
            this.CloudButton.Click += new System.EventHandler(this.CloudButton_Click);
            // 
            // SummerButton
            // 
            this.SummerButton.BackColor = System.Drawing.Color.Green;
            this.SummerButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SummerButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SummerButton.ForeColor = System.Drawing.Color.Green;
            this.SummerButton.Location = new System.Drawing.Point(28, 171);
            this.SummerButton.Name = "SummerButton";
            this.SummerButton.Size = new System.Drawing.Size(10, 23);
            this.SummerButton.TabIndex = 6;
            this.SummerButton.UseVisualStyleBackColor = false;
            this.SummerButton.Click += new System.EventHandler(this.SummerButton_Click);
            // 
            // SpringButton
            // 
            this.SpringButton.BackColor = System.Drawing.Color.Pink;
            this.SpringButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SpringButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SpringButton.ForeColor = System.Drawing.Color.Pink;
            this.SpringButton.Location = new System.Drawing.Point(44, 171);
            this.SpringButton.Name = "SpringButton";
            this.SpringButton.Size = new System.Drawing.Size(10, 23);
            this.SpringButton.TabIndex = 7;
            this.SpringButton.UseVisualStyleBackColor = false;
            this.SpringButton.Click += new System.EventHandler(this.SpringButton_Click);
            // 
            // FallButton
            // 
            this.FallButton.BackColor = System.Drawing.Color.Orange;
            this.FallButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.FallButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.FallButton.ForeColor = System.Drawing.Color.Orange;
            this.FallButton.Location = new System.Drawing.Point(60, 171);
            this.FallButton.Name = "FallButton";
            this.FallButton.Size = new System.Drawing.Size(10, 23);
            this.FallButton.TabIndex = 8;
            this.FallButton.UseVisualStyleBackColor = false;
            this.FallButton.Click += new System.EventHandler(this.FallButton_Click);
            // 
            // SnowButton
            // 
            this.SnowButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SnowButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SnowButton.Location = new System.Drawing.Point(76, 171);
            this.SnowButton.Name = "SnowButton";
            this.SnowButton.Size = new System.Drawing.Size(10, 23);
            this.SnowButton.TabIndex = 9;
            this.SnowButton.UseVisualStyleBackColor = true;
            this.SnowButton.Click += new System.EventHandler(this.SnowButton_Click);
            // 
            // CancelButton
            // 
            this.CancelButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CancelButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CancelButton.Location = new System.Drawing.Point(108, 170);
            this.CancelButton.Name = "CancelButton";
            this.CancelButton.Size = new System.Drawing.Size(75, 23);
            this.CancelButton.TabIndex = 10;
            this.CancelButton.Text = "Cancel";
            this.CancelButton.UseVisualStyleBackColor = true;
            this.CancelButton.Click += new System.EventHandler(this.CancelButton_Click);
            // 
            // MainLabel
            // 
            this.MainLabel.BackColor = System.Drawing.Color.Transparent;
            this.MainLabel.Location = new System.Drawing.Point(12, 165);
            this.MainLabel.Name = "MainLabel";
            this.MainLabel.Size = new System.Drawing.Size(171, 18);
            this.MainLabel.TabIndex = 11;
            this.MainLabel.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // CopyLabel
            // 
            this.CopyLabel.AutoSize = true;
            this.CopyLabel.BackColor = System.Drawing.Color.Transparent;
            this.CopyLabel.Location = new System.Drawing.Point(76, 183);
            this.CopyLabel.Name = "CopyLabel";
            this.CopyLabel.Size = new System.Drawing.Size(46, 15);
            this.CopyLabel.TabIndex = 12;
            this.CopyLabel.Text = "copied!";
            // 
            // CopyClipboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(195, 200);
            this.Controls.Add(this.CopyLabel);
            this.Controls.Add(this.MainLabel);
            this.Controls.Add(this.CancelButton);
            this.Controls.Add(this.SnowButton);
            this.Controls.Add(this.FallButton);
            this.Controls.Add(this.SpringButton);
            this.Controls.Add(this.SummerButton);
            this.Controls.Add(this.CloudButton);
            this.Controls.Add(this.CameraButton);
            this.Controls.Add(this.MainListBox);
            this.Controls.Add(this.SkinsButton);
            this.Controls.Add(this.MainComboBox);
            this.Controls.Add(this.MainPictureBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "CopyClipboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            ((System.ComponentModel.ISupportInitialize)(this.MainPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PictureBox MainPictureBox;
        private ComboBox MainComboBox;
        private Button SkinsButton;
        private ListBox MainListBox;
        private Button CameraButton;
        private System.Windows.Forms.Timer CopyTimer;
        private System.Windows.Forms.Timer TimerUpdate;
        private Button CloudButton;
        private Button SummerButton;
        private Button SpringButton;
        private Button FallButton;
        private Button SnowButton;
        private Button CancelButton;
        private Label MainLabel;
        private Label CopyLabel;
    }
}