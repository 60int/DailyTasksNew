﻿using System.Text;

namespace DailyTasks.Forms.Classes
{
    class SelectedTheme
    {
        string? selectedTheme;

        public string? Theme { get => selectedTheme; set => selectedTheme = value; }

        public SelectedTheme(string selectedTheme)
        {
            Theme = selectedTheme;
        }

        public override string ToString()
        {
            return selectedTheme!;
        }

        public string CSVFormat()
        {
            return $"{selectedTheme}";
        }

        public static User[] Deserialize(string filename)
        {
            string[] lines = File.ReadAllLines(filename, Encoding.UTF8).ToArray();
            User[] users = new User[lines.Length];
            for (int i = 0; i < lines.Length; i++)
            {
                string[] line = lines[i].Split(',');
                users[i] = new User(line[0]);
            }
            return users;
        }

        public static void Serialize(string filename, User[] users)
        {
            StreamWriter writer = new(filename, false, Encoding.UTF8);
            foreach (User item in users)
            {
                writer.WriteLine(item.CSVFormat());
            }
            writer.Close();
        }
    }
}
