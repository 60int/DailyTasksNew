﻿namespace DailyTasks.Forms.Classes
{
    public class TextCell
    {
        string cellType;
        string colOne;
        string colTwo;
        string colThree;
        string colFour;
        string colFive;
        string colSix;
        string colSeven;
        string colEight;

        public string Type
        {
            get => cellType;
            set
            {
                if (value != "" && value.Length <= 24 && !value.Contains(','))
                {
                    cellType = value;
                }
                else
                {
                    MessageBox.Show("Drop Down item can't be longer than 24 characters, null or contain a comma (,)", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }
        public string ColOne
        {
            get => colOne;
            set
            {
                if (value != "" && value.Length <= 24 && !value.Contains(','))
                {
                    colOne = value;
                }
                else
                {
                    MessageBox.Show("Column item 1 can't be longer than 24 characters, null or contain a comma (,)", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }
        public string ColTwo
        {
            get => colTwo; set
            {
                if (value != "" && value.Length <= 24 && !value.Contains(','))
                {
                    colTwo = value;
                }
                else
                {
                    MessageBox.Show("Column item 2 can't be longer than 24 characters, null or contain a comma (,)", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }
        public string ColThree
        {
            get => colThree; set
            {
                if (value != "" && value.Length <= 24 && !value.Contains(','))
                {
                    colThree = value;
                }
                else
                {
                    MessageBox.Show("Column item 3 can't be longer than 24 characters, null or contain a comma (,)", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }
        public string ColFour
        {
            get => colFour; set
            {
                if (value != "" && value.Length <= 24 && !value.Contains(','))
                {
                    colFour = value;
                }
                else
                {
                    MessageBox.Show("Column item 4 can't be longer than 24 characters, null or contain a comma (,)", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }
        public string ColFive
        {
            get => colFive; set
            {
                if (value != "" && value.Length <= 24 && !value.Contains(','))
                {
                    colFive = value;
                }
                else
                {
                    MessageBox.Show("Column item 5 can't be longer than 24 characters, null or contain a comma (,)", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }
        public string ColSix
        {
            get => colSix; set
            {
                if (value != "" && value.Length <= 24 && !value.Contains(','))
                {
                    colSix = value;
                }
                else
                {
                    MessageBox.Show("Column item 6 can't be longer than 24 characters, null or contain a comma (,)", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }
        public string ColSeven
        {
            get => colSeven; set
            {
                if (value != "" && value.Length <= 24 && !value.Contains(','))
                {
                    colSeven = value;
                }
                else
                {
                    MessageBox.Show("Column item 7 can't be longer than 24 characters, null or contain a comma (,)", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }
        public string ColEight
        {
            get => colEight; set
            {
                if (value != "" && value.Length <= 24 && !value.Contains(','))
                {
                    colEight = value;
                }
                else
                {
                    MessageBox.Show("Column item 8 can't be longer than 24 characters, null or contain a comma (,)", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        public TextCell(string? lines)
        {
            string[] Cols = lines!.Split(',');
            Type = cellType = Cols[0];
            ColOne = colOne = Cols[1];
            ColTwo = colTwo = Cols[2];
            ColThree = colThree = Cols[3];
            ColFour = colFour = Cols[4];
            ColFive = colFive = Cols[5];
            ColSix = colSix = Cols[6];
            ColSeven = colSeven = Cols[7];
            ColEight = colEight = Cols[8];
        }

        public override string ToString()
        {
            return Type;
        }

        public string ToMainLB()
        {
            return Type + ',' + ColOne + ',' + ColTwo + ',' + ColThree + ',' + ColFour + ',' + ColFive + ',' + ColSix + ',' + ColSeven + ',' + ColEight;
        }
    }
}
