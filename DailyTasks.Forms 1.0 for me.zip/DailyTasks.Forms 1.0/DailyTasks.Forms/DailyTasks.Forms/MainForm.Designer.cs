﻿namespace DailyTasks.Forms
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            MainPicturebox = new PictureBox();
            MainMenuStrip = new MenuStrip();
            FileToolStripMenuItem = new ToolStripMenuItem();
            NewUserToolStripMenuItem = new ToolStripMenuItem();
            UsersToolStripMenuItem = new ToolStripMenuItem();
            ExitToolStripMenuItem = new ToolStripMenuItem();
            ClipboardToolStripMenuItem = new ToolStripMenuItem();
            OpenCBToolStripMenuItem = new ToolStripMenuItem();
            EditCBToolStripMenuItem = new ToolStripMenuItem();
            AddButton = new Button();
            UpdateButton = new Button();
            RemoveButton = new Button();
            ShareImageButton = new Button();
            MainListBox = new ListBox();
            ShareImageTimer = new System.Windows.Forms.Timer(components);
            ShareImageLabel = new Label();
            CurrentUser = new Label();
            CurrentUserLabel = new Label();
            UserGroupBox = new GroupBox();
            SortWeekButton = new Button();
            ShowAllButton = new Button();
            MainDateTimePicker = new DateTimePicker();
            MainDataGridView = new DataGridView();
            AlwaysOnTopCheckBox = new CheckBox();
            ((System.ComponentModel.ISupportInitialize)MainPicturebox).BeginInit();
            MainMenuStrip.SuspendLayout();
            UserGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)MainDataGridView).BeginInit();
            SuspendLayout();
            // 
            // MainPicturebox
            // 
            MainPicturebox.Dock = DockStyle.Fill;
            MainPicturebox.Location = new Point(0, 24);
            MainPicturebox.Name = "MainPicturebox";
            MainPicturebox.Size = new Size(938, 504);
            MainPicturebox.TabIndex = 0;
            MainPicturebox.TabStop = false;
            // 
            // MainMenuStrip
            // 
            MainMenuStrip.BackColor = Color.RoyalBlue;
            MainMenuStrip.Items.AddRange(new ToolStripItem[] { FileToolStripMenuItem, ClipboardToolStripMenuItem });
            MainMenuStrip.Location = new Point(0, 0);
            MainMenuStrip.Name = "MainMenuStrip";
            MainMenuStrip.Size = new Size(938, 24);
            MainMenuStrip.TabIndex = 1;
            MainMenuStrip.Text = "menuStrip1";
            // 
            // FileToolStripMenuItem
            // 
            FileToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { NewUserToolStripMenuItem, UsersToolStripMenuItem, ExitToolStripMenuItem });
            FileToolStripMenuItem.ForeColor = Color.White;
            FileToolStripMenuItem.Name = "FileToolStripMenuItem";
            FileToolStripMenuItem.Size = new Size(37, 20);
            FileToolStripMenuItem.Text = "File";
            FileToolStripMenuItem.DropDownClosed += FileToolStripMenuItem_DropDownClosed;
            FileToolStripMenuItem.DropDownOpened += FileToolStripMenuItem_DropDownOpened;
            // 
            // NewUserToolStripMenuItem
            // 
            NewUserToolStripMenuItem.Name = "NewUserToolStripMenuItem";
            NewUserToolStripMenuItem.Size = new Size(124, 22);
            NewUserToolStripMenuItem.Text = "New User";
            NewUserToolStripMenuItem.Click += NewUserToolStripMenuItem_Click;
            // 
            // UsersToolStripMenuItem
            // 
            UsersToolStripMenuItem.Name = "UsersToolStripMenuItem";
            UsersToolStripMenuItem.Size = new Size(124, 22);
            UsersToolStripMenuItem.Text = "Users";
            // 
            // ExitToolStripMenuItem
            // 
            ExitToolStripMenuItem.Name = "ExitToolStripMenuItem";
            ExitToolStripMenuItem.Size = new Size(124, 22);
            ExitToolStripMenuItem.Text = "Exit";
            // 
            // ClipboardToolStripMenuItem
            // 
            ClipboardToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { OpenCBToolStripMenuItem, EditCBToolStripMenuItem });
            ClipboardToolStripMenuItem.ForeColor = Color.White;
            ClipboardToolStripMenuItem.Name = "ClipboardToolStripMenuItem";
            ClipboardToolStripMenuItem.Size = new Size(71, 20);
            ClipboardToolStripMenuItem.Text = "Clipboard";
            ClipboardToolStripMenuItem.DropDownClosed += ClipboardToolStripMenuItem_DropDownClosed;
            ClipboardToolStripMenuItem.DropDownOpened += ClipboardToolStripMenuItem_DropDownOpened;
            // 
            // OpenCBToolStripMenuItem
            // 
            OpenCBToolStripMenuItem.Name = "OpenCBToolStripMenuItem";
            OpenCBToolStripMenuItem.Size = new Size(103, 22);
            OpenCBToolStripMenuItem.Text = "Open";
            OpenCBToolStripMenuItem.Click += OpenCBToolStripMenuItem_Click;
            // 
            // EditCBToolStripMenuItem
            // 
            EditCBToolStripMenuItem.Name = "EditCBToolStripMenuItem";
            EditCBToolStripMenuItem.Size = new Size(103, 22);
            EditCBToolStripMenuItem.Text = "Edit";
            EditCBToolStripMenuItem.Click += EditCBToolStripMenuItem_Click;
            // 
            // AddButton
            // 
            AddButton.FlatAppearance.MouseDownBackColor = Color.Azure;
            AddButton.FlatAppearance.MouseOverBackColor = Color.LightSteelBlue;
            AddButton.FlatStyle = FlatStyle.Flat;
            AddButton.Location = new Point(12, 391);
            AddButton.Name = "AddButton";
            AddButton.Size = new Size(162, 26);
            AddButton.TabIndex = 1;
            AddButton.Text = "Add Task";
            AddButton.UseVisualStyleBackColor = true;
            AddButton.Click += AddButton_Click;
            // 
            // UpdateButton
            // 
            UpdateButton.FlatAppearance.MouseDownBackColor = Color.Azure;
            UpdateButton.FlatAppearance.MouseOverBackColor = Color.LightSteelBlue;
            UpdateButton.FlatStyle = FlatStyle.Flat;
            UpdateButton.Location = new Point(12, 423);
            UpdateButton.Name = "UpdateButton";
            UpdateButton.Size = new Size(162, 26);
            UpdateButton.TabIndex = 2;
            UpdateButton.Text = "Update";
            UpdateButton.UseVisualStyleBackColor = true;
            UpdateButton.Click += UpdateButton_Click;
            // 
            // RemoveButton
            // 
            RemoveButton.FlatAppearance.MouseDownBackColor = Color.Azure;
            RemoveButton.FlatAppearance.MouseOverBackColor = Color.LightSteelBlue;
            RemoveButton.FlatStyle = FlatStyle.Flat;
            RemoveButton.Location = new Point(12, 455);
            RemoveButton.Name = "RemoveButton";
            RemoveButton.Size = new Size(162, 26);
            RemoveButton.TabIndex = 3;
            RemoveButton.Text = "Remove";
            RemoveButton.UseVisualStyleBackColor = true;
            RemoveButton.Click += RemoveButton_Click;
            // 
            // ShareImageButton
            // 
            ShareImageButton.FlatAppearance.MouseDownBackColor = Color.Azure;
            ShareImageButton.FlatAppearance.MouseOverBackColor = Color.LightSteelBlue;
            ShareImageButton.FlatStyle = FlatStyle.Flat;
            ShareImageButton.Location = new Point(12, 487);
            ShareImageButton.Name = "ShareImageButton";
            ShareImageButton.Size = new Size(162, 26);
            ShareImageButton.TabIndex = 4;
            ShareImageButton.Text = "Share Image";
            ShareImageButton.UseVisualStyleBackColor = true;
            ShareImageButton.Click += ShareImageButton_Click;
            // 
            // MainListBox
            // 
            MainListBox.FormattingEnabled = true;
            MainListBox.ItemHeight = 15;
            MainListBox.Location = new Point(12, 82);
            MainListBox.Name = "MainListBox";
            MainListBox.Size = new Size(162, 304);
            MainListBox.TabIndex = 5;
            MainListBox.DoubleClick += MainListBox_DoubleClick;
            // 
            // ShareImageTimer
            // 
            ShareImageTimer.Interval = 1000;
            ShareImageTimer.Tick += ShareImageTimer_Tick;
            // 
            // ShareImageLabel
            // 
            ShareImageLabel.AutoSize = true;
            ShareImageLabel.Location = new Point(68, 513);
            ShareImageLabel.Name = "ShareImageLabel";
            ShareImageLabel.Size = new Size(0, 15);
            ShareImageLabel.TabIndex = 16;
            // 
            // CurrentUser
            // 
            CurrentUser.AutoSize = true;
            CurrentUser.Location = new Point(6, 19);
            CurrentUser.Name = "CurrentUser";
            CurrentUser.Size = new Size(76, 15);
            CurrentUser.TabIndex = 23;
            CurrentUser.Text = "Current User:";
            // 
            // CurrentUserLabel
            // 
            CurrentUserLabel.Location = new Point(78, 9);
            CurrentUserLabel.Name = "CurrentUserLabel";
            CurrentUserLabel.Size = new Size(45, 34);
            CurrentUserLabel.TabIndex = 24;
            CurrentUserLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // UserGroupBox
            // 
            UserGroupBox.Controls.Add(SortWeekButton);
            UserGroupBox.Controls.Add(ShowAllButton);
            UserGroupBox.Controls.Add(MainDateTimePicker);
            UserGroupBox.Controls.Add(CurrentUser);
            UserGroupBox.Controls.Add(CurrentUserLabel);
            UserGroupBox.Location = new Point(12, 27);
            UserGroupBox.Name = "UserGroupBox";
            UserGroupBox.Size = new Size(911, 49);
            UserGroupBox.TabIndex = 25;
            UserGroupBox.TabStop = false;
            // 
            // SortWeekButton
            // 
            SortWeekButton.FlatStyle = FlatStyle.Flat;
            SortWeekButton.Location = new Point(580, 17);
            SortWeekButton.Name = "SortWeekButton";
            SortWeekButton.Size = new Size(86, 23);
            SortWeekButton.TabIndex = 30;
            SortWeekButton.Text = "Sort by Week";
            SortWeekButton.UseVisualStyleBackColor = true;
            SortWeekButton.Click += SortWeekButton_Click;
            // 
            // ShowAllButton
            // 
            ShowAllButton.FlatStyle = FlatStyle.Flat;
            ShowAllButton.Location = new Point(488, 17);
            ShowAllButton.Name = "ShowAllButton";
            ShowAllButton.Size = new Size(86, 23);
            ShowAllButton.TabIndex = 29;
            ShowAllButton.Text = "Show All";
            ShowAllButton.UseVisualStyleBackColor = true;
            ShowAllButton.Click += ShowAllButton_Click;
            // 
            // MainDateTimePicker
            // 
            MainDateTimePicker.Location = new Point(282, 17);
            MainDateTimePicker.Name = "MainDateTimePicker";
            MainDateTimePicker.Size = new Size(200, 23);
            MainDateTimePicker.TabIndex = 28;
            MainDateTimePicker.ValueChanged += MainDateTimePicker_ValueChanged;
            // 
            // MainDataGridView
            // 
            MainDataGridView.BackgroundColor = Color.RoyalBlue;
            MainDataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            MainDataGridView.Location = new Point(180, 82);
            MainDataGridView.Name = "MainDataGridView";
            MainDataGridView.Size = new Size(743, 431);
            MainDataGridView.TabIndex = 26;
            // 
            // AlwaysOnTopCheckBox
            // 
            AlwaysOnTopCheckBox.AutoSize = true;
            AlwaysOnTopCheckBox.BackColor = Color.RoyalBlue;
            AlwaysOnTopCheckBox.ForeColor = Color.White;
            AlwaysOnTopCheckBox.Location = new Point(825, 4);
            AlwaysOnTopCheckBox.Name = "AlwaysOnTopCheckBox";
            AlwaysOnTopCheckBox.Size = new Size(101, 19);
            AlwaysOnTopCheckBox.TabIndex = 27;
            AlwaysOnTopCheckBox.Text = "Always on top";
            AlwaysOnTopCheckBox.UseVisualStyleBackColor = false;
            AlwaysOnTopCheckBox.CheckedChanged += AlwaysOnTopCheckBox_CheckedChanged;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(938, 528);
            Controls.Add(AlwaysOnTopCheckBox);
            Controls.Add(MainDataGridView);
            Controls.Add(UserGroupBox);
            Controls.Add(ShareImageLabel);
            Controls.Add(MainListBox);
            Controls.Add(ShareImageButton);
            Controls.Add(RemoveButton);
            Controls.Add(UpdateButton);
            Controls.Add(AddButton);
            Controls.Add(MainPicturebox);
            Controls.Add(MainMenuStrip);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            Name = "MainForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Daily Tasks";
            Load += MainForm_Load;
            ((System.ComponentModel.ISupportInitialize)MainPicturebox).EndInit();
            MainMenuStrip.ResumeLayout(false);
            MainMenuStrip.PerformLayout();
            UserGroupBox.ResumeLayout(false);
            UserGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)MainDataGridView).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox MainPicturebox;
        private MenuStrip MainMenuStrip;
        private ToolStripMenuItem FileToolStripMenuItem;
        private ToolStripMenuItem NewUserToolStripMenuItem;
        private ToolStripMenuItem UsersToolStripMenuItem;
        private ToolStripMenuItem ExitToolStripMenuItem;
        private ToolStripMenuItem ClipboardToolStripMenuItem;
        private ToolStripMenuItem OpenCBToolStripMenuItem;
        private ToolStripMenuItem EditCBToolStripMenuItem;
        private Button AddButton;
        private Button UpdateButton;
        private Button RemoveButton;
        private Button ShareImageButton;
        private ListBox MainListBox;
        private System.Windows.Forms.Timer ShareImageTimer;
        private Label ShareImageLabel;
        private Label CurrentUser;
        private Label CurrentUserLabel;
        private GroupBox UserGroupBox;
        private DataGridView MainDataGridView;
        private CheckBox AlwaysOnTopCheckBox;
        private DateTimePicker MainDateTimePicker;
        private Button ShowAllButton;
        private Button SortWeekButton;
    }
}