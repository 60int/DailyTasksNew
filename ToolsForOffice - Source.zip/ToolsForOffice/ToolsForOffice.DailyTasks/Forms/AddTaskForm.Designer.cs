﻿namespace ToolsForOffice.DailyTasks.Forms
{
    partial class AddTaskForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            NGOKNumericUpDown = new NumericUpDown();
            NGOKLabel = new Label();
            OtherNGNumericUpDown = new NumericUpDown();
            label1 = new Label();
            PriorityComboBox = new ComboBox();
            TypeComboBox = new ComboBox();
            AmountLeftNumericUpDown = new NumericUpDown();
            ScrapNGNumericUpDown = new NumericUpDown();
            TotalNumericUpDown = new NumericUpDown();
            UserTextBox = new TextBox();
            PriorityLabel = new Label();
            TypeLabel = new Label();
            MainDateTimePicker = new DateTimePicker();
            AmountLeftLabel = new Label();
            NGLabel = new Label();
            CompletedCheckBox = new CheckBox();
            TotalLabel = new Label();
            TaskTitleLabel = new Label();
            OKButton = new MaterialSkin.Controls.MaterialButton();
            CancelButton = new MaterialSkin.Controls.MaterialButton();
            ((System.ComponentModel.ISupportInitialize)NGOKNumericUpDown).BeginInit();
            ((System.ComponentModel.ISupportInitialize)OtherNGNumericUpDown).BeginInit();
            ((System.ComponentModel.ISupportInitialize)AmountLeftNumericUpDown).BeginInit();
            ((System.ComponentModel.ISupportInitialize)ScrapNGNumericUpDown).BeginInit();
            ((System.ComponentModel.ISupportInitialize)TotalNumericUpDown).BeginInit();
            SuspendLayout();
            // 
            // NGOKNumericUpDown
            // 
            NGOKNumericUpDown.Location = new Point(96, 182);
            NGOKNumericUpDown.Maximum = new decimal(new int[] { 100000, 0, 0, 0 });
            NGOKNumericUpDown.Name = "NGOKNumericUpDown";
            NGOKNumericUpDown.Size = new Size(297, 23);
            NGOKNumericUpDown.TabIndex = 22;
            // 
            // NGOKLabel
            // 
            NGOKLabel.AutoSize = true;
            NGOKLabel.BackColor = SystemColors.Control;
            NGOKLabel.Location = new Point(45, 184);
            NGOKLabel.Name = "NGOKLabel";
            NGOKLabel.Size = new Size(45, 15);
            NGOKLabel.TabIndex = 33;
            NGOKLabel.Text = "NG/OK";
            // 
            // OtherNGNumericUpDown
            // 
            OtherNGNumericUpDown.Location = new Point(96, 124);
            OtherNGNumericUpDown.Maximum = new decimal(new int[] { 100000, 0, 0, 0 });
            OtherNGNumericUpDown.Name = "OtherNGNumericUpDown";
            OtherNGNumericUpDown.Size = new Size(297, 23);
            OtherNGNumericUpDown.TabIndex = 19;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = SystemColors.Control;
            label1.Location = new Point(33, 126);
            label1.Name = "label1";
            label1.Size = new Size(57, 15);
            label1.TabIndex = 31;
            label1.Text = "Other NG";
            // 
            // PriorityComboBox
            // 
            PriorityComboBox.FormattingEnabled = true;
            PriorityComboBox.Location = new Point(96, 293);
            PriorityComboBox.Name = "PriorityComboBox";
            PriorityComboBox.Size = new Size(297, 23);
            PriorityComboBox.TabIndex = 28;
            // 
            // TypeComboBox
            // 
            TypeComboBox.FormattingEnabled = true;
            TypeComboBox.Location = new Point(96, 264);
            TypeComboBox.Name = "TypeComboBox";
            TypeComboBox.Size = new Size(297, 23);
            TypeComboBox.TabIndex = 27;
            // 
            // AmountLeftNumericUpDown
            // 
            AmountLeftNumericUpDown.Location = new Point(96, 153);
            AmountLeftNumericUpDown.Maximum = new decimal(new int[] { 100000, 0, 0, 0 });
            AmountLeftNumericUpDown.Name = "AmountLeftNumericUpDown";
            AmountLeftNumericUpDown.Size = new Size(297, 23);
            AmountLeftNumericUpDown.TabIndex = 21;
            // 
            // ScrapNGNumericUpDown
            // 
            ScrapNGNumericUpDown.Location = new Point(96, 95);
            ScrapNGNumericUpDown.Maximum = new decimal(new int[] { 100000, 0, 0, 0 });
            ScrapNGNumericUpDown.Name = "ScrapNGNumericUpDown";
            ScrapNGNumericUpDown.Size = new Size(297, 23);
            ScrapNGNumericUpDown.TabIndex = 17;
            // 
            // TotalNumericUpDown
            // 
            TotalNumericUpDown.Location = new Point(96, 66);
            TotalNumericUpDown.Maximum = new decimal(new int[] { 100000, 0, 0, 0 });
            TotalNumericUpDown.Name = "TotalNumericUpDown";
            TotalNumericUpDown.Size = new Size(297, 23);
            TotalNumericUpDown.TabIndex = 16;
            // 
            // UserTextBox
            // 
            UserTextBox.Location = new Point(96, 37);
            UserTextBox.Name = "UserTextBox";
            UserTextBox.Size = new Size(297, 23);
            UserTextBox.TabIndex = 32;
            // 
            // PriorityLabel
            // 
            PriorityLabel.AutoSize = true;
            PriorityLabel.BackColor = SystemColors.Control;
            PriorityLabel.Location = new Point(45, 296);
            PriorityLabel.Name = "PriorityLabel";
            PriorityLabel.Size = new Size(45, 15);
            PriorityLabel.TabIndex = 25;
            PriorityLabel.Text = "Priority";
            // 
            // TypeLabel
            // 
            TypeLabel.AutoSize = true;
            TypeLabel.BackColor = SystemColors.Control;
            TypeLabel.Location = new Point(59, 267);
            TypeLabel.Name = "TypeLabel";
            TypeLabel.Size = new Size(31, 15);
            TypeLabel.TabIndex = 23;
            TypeLabel.Text = "Type";
            // 
            // MainDateTimePicker
            // 
            MainDateTimePicker.Location = new Point(96, 236);
            MainDateTimePicker.Name = "MainDateTimePicker";
            MainDateTimePicker.Size = new Size(297, 23);
            MainDateTimePicker.TabIndex = 26;
            // 
            // AmountLeftLabel
            // 
            AmountLeftLabel.AutoSize = true;
            AmountLeftLabel.BackColor = SystemColors.Control;
            AmountLeftLabel.Location = new Point(16, 155);
            AmountLeftLabel.Name = "AmountLeftLabel";
            AmountLeftLabel.Size = new Size(74, 15);
            AmountLeftLabel.TabIndex = 20;
            AmountLeftLabel.Text = "Amount Left";
            // 
            // NGLabel
            // 
            NGLabel.AutoSize = true;
            NGLabel.BackColor = SystemColors.Control;
            NGLabel.Location = new Point(11, 97);
            NGLabel.Name = "NGLabel";
            NGLabel.Size = new Size(79, 15);
            NGLabel.TabIndex = 18;
            NGLabel.Text = "Scrap/Double";
            // 
            // CompletedCheckBox
            // 
            CompletedCheckBox.AutoSize = true;
            CompletedCheckBox.BackColor = SystemColors.Control;
            CompletedCheckBox.Location = new Point(96, 211);
            CompletedCheckBox.Name = "CompletedCheckBox";
            CompletedCheckBox.Size = new Size(85, 19);
            CompletedCheckBox.TabIndex = 24;
            CompletedCheckBox.Text = "Completed";
            CompletedCheckBox.UseVisualStyleBackColor = false;
            // 
            // TotalLabel
            // 
            TotalLabel.AutoSize = true;
            TotalLabel.BackColor = SystemColors.Control;
            TotalLabel.Location = new Point(58, 68);
            TotalLabel.Name = "TotalLabel";
            TotalLabel.Size = new Size(32, 15);
            TotalLabel.TabIndex = 15;
            TotalLabel.Text = "Total";
            // 
            // TaskTitleLabel
            // 
            TaskTitleLabel.AutoSize = true;
            TaskTitleLabel.BackColor = SystemColors.Control;
            TaskTitleLabel.Location = new Point(60, 40);
            TaskTitleLabel.Name = "TaskTitleLabel";
            TaskTitleLabel.Size = new Size(30, 15);
            TaskTitleLabel.TabIndex = 14;
            TaskTitleLabel.Text = "User";
            // 
            // OKButton
            // 
            OKButton.AutoSize = false;
            OKButton.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            OKButton.Cursor = Cursors.Hand;
            OKButton.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            OKButton.Depth = 0;
            OKButton.DialogResult = DialogResult.OK;
            OKButton.HighEmphasis = true;
            OKButton.Icon = null;
            OKButton.Location = new Point(233, 325);
            OKButton.Margin = new Padding(4, 6, 4, 6);
            OKButton.MouseState = MaterialSkin.MouseState.HOVER;
            OKButton.Name = "OKButton";
            OKButton.NoAccentTextColor = Color.Empty;
            OKButton.Size = new Size(75, 36);
            OKButton.TabIndex = 34;
            OKButton.Text = "OK";
            OKButton.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            OKButton.UseAccentColor = false;
            OKButton.UseVisualStyleBackColor = true;
            OKButton.Click += OKButton_Click;
            // 
            // CancelButton
            // 
            CancelButton.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            CancelButton.Cursor = Cursors.Hand;
            CancelButton.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            CancelButton.Depth = 0;
            CancelButton.DialogResult = DialogResult.Cancel;
            CancelButton.HighEmphasis = true;
            CancelButton.Icon = null;
            CancelButton.Location = new Point(316, 325);
            CancelButton.Margin = new Padding(4, 6, 4, 6);
            CancelButton.MouseState = MaterialSkin.MouseState.HOVER;
            CancelButton.Name = "CancelButton";
            CancelButton.NoAccentTextColor = Color.Empty;
            CancelButton.Size = new Size(77, 36);
            CancelButton.TabIndex = 35;
            CancelButton.Text = "Cancel";
            CancelButton.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            CancelButton.UseAccentColor = false;
            CancelButton.UseVisualStyleBackColor = true;
            // 
            // AddTaskForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(405, 372);
            Controls.Add(CancelButton);
            Controls.Add(OKButton);
            Controls.Add(NGOKNumericUpDown);
            Controls.Add(NGOKLabel);
            Controls.Add(OtherNGNumericUpDown);
            Controls.Add(label1);
            Controls.Add(PriorityComboBox);
            Controls.Add(TypeComboBox);
            Controls.Add(AmountLeftNumericUpDown);
            Controls.Add(ScrapNGNumericUpDown);
            Controls.Add(TotalNumericUpDown);
            Controls.Add(UserTextBox);
            Controls.Add(PriorityLabel);
            Controls.Add(TypeLabel);
            Controls.Add(MainDateTimePicker);
            Controls.Add(AmountLeftLabel);
            Controls.Add(NGLabel);
            Controls.Add(CompletedCheckBox);
            Controls.Add(TotalLabel);
            Controls.Add(TaskTitleLabel);
            FormStyle = FormStyles.ActionBar_None;
            Name = "AddTaskForm";
            Padding = new Padding(3, 24, 3, 3);
            StartPosition = FormStartPosition.CenterScreen;
            Text = "AddTaskForm";
            ((System.ComponentModel.ISupportInitialize)NGOKNumericUpDown).EndInit();
            ((System.ComponentModel.ISupportInitialize)OtherNGNumericUpDown).EndInit();
            ((System.ComponentModel.ISupportInitialize)AmountLeftNumericUpDown).EndInit();
            ((System.ComponentModel.ISupportInitialize)ScrapNGNumericUpDown).EndInit();
            ((System.ComponentModel.ISupportInitialize)TotalNumericUpDown).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private NumericUpDown NGOKNumericUpDown;
        private Label NGOKLabel;
        private NumericUpDown OtherNGNumericUpDown;
        private Label label1;
        private ComboBox PriorityComboBox;
        private ComboBox TypeComboBox;
        private NumericUpDown AmountLeftNumericUpDown;
        private NumericUpDown ScrapNGNumericUpDown;
        private NumericUpDown TotalNumericUpDown;
        private TextBox UserTextBox;
        private Label PriorityLabel;
        private Label TypeLabel;
        private DateTimePicker MainDateTimePicker;
        private Label AmountLeftLabel;
        private Label NGLabel;
        private CheckBox CompletedCheckBox;
        private Label TotalLabel;
        private Label TaskTitleLabel;
        private MaterialSkin.Controls.MaterialButton OKButton;
        private MaterialSkin.Controls.MaterialButton CancelButton;
    }
}