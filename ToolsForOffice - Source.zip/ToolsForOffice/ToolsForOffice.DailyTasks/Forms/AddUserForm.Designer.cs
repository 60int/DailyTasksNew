﻿namespace ToolsForOffice.DailyTasks.Forms
{
    partial class AddUserForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            CancelButton = new MaterialSkin.Controls.MaterialButton();
            AddButton = new MaterialSkin.Controls.MaterialButton();
            UserNameTextBox = new MaterialSkin.Controls.MaterialTextBox();
            SuspendLayout();
            // 
            // CancelButton
            // 
            CancelButton.AutoSize = false;
            CancelButton.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            CancelButton.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            CancelButton.Depth = 0;
            CancelButton.DialogResult = DialogResult.Cancel;
            CancelButton.HighEmphasis = true;
            CancelButton.Icon = null;
            CancelButton.Location = new Point(160, 84);
            CancelButton.Margin = new Padding(4, 6, 4, 6);
            CancelButton.MouseState = MaterialSkin.MouseState.HOVER;
            CancelButton.Name = "CancelButton";
            CancelButton.NoAccentTextColor = Color.Empty;
            CancelButton.Size = new Size(145, 36);
            CancelButton.TabIndex = 5;
            CancelButton.Text = "Cancel";
            CancelButton.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            CancelButton.UseAccentColor = false;
            CancelButton.UseVisualStyleBackColor = true;
            // 
            // AddButton
            // 
            AddButton.AutoSize = false;
            AddButton.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            AddButton.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            AddButton.Depth = 0;
            AddButton.DialogResult = DialogResult.OK;
            AddButton.HighEmphasis = true;
            AddButton.Icon = null;
            AddButton.Location = new Point(7, 84);
            AddButton.Margin = new Padding(4, 6, 4, 6);
            AddButton.MouseState = MaterialSkin.MouseState.HOVER;
            AddButton.Name = "AddButton";
            AddButton.NoAccentTextColor = Color.Empty;
            AddButton.Size = new Size(145, 36);
            AddButton.TabIndex = 4;
            AddButton.Text = "OK";
            AddButton.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            AddButton.UseAccentColor = false;
            AddButton.UseVisualStyleBackColor = true;
            AddButton.Click += AddButton_Click;
            // 
            // UserNameTextBox
            // 
            UserNameTextBox.AnimateReadOnly = false;
            UserNameTextBox.BorderStyle = BorderStyle.None;
            UserNameTextBox.Depth = 0;
            UserNameTextBox.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point);
            UserNameTextBox.LeadingIcon = null;
            UserNameTextBox.Location = new Point(7, 27);
            UserNameTextBox.MaxLength = 50;
            UserNameTextBox.MouseState = MaterialSkin.MouseState.OUT;
            UserNameTextBox.Multiline = false;
            UserNameTextBox.Name = "UserNameTextBox";
            UserNameTextBox.Size = new Size(298, 50);
            UserNameTextBox.TabIndex = 6;
            UserNameTextBox.Text = "Username";
            UserNameTextBox.TrailingIcon = null;
            // 
            // AddUserForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(313, 127);
            Controls.Add(UserNameTextBox);
            Controls.Add(CancelButton);
            Controls.Add(AddButton);
            FormStyle = FormStyles.ActionBar_None;
            MaximizeBox = false;
            Name = "AddUserForm";
            Padding = new Padding(3, 24, 3, 3);
            StartPosition = FormStartPosition.CenterScreen;
            Text = "AddUserForm";
            ResumeLayout(false);
        }

        #endregion

        private MaterialSkin.Controls.MaterialButton CancelButton;
        private MaterialSkin.Controls.MaterialButton AddButton;
        private MaterialSkin.Controls.MaterialTextBox UserNameTextBox;
    }
}