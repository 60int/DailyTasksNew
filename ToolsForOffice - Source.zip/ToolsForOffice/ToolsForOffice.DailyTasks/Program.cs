namespace ToolsForOffice.DailyTasks
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string filePath = Path.Combine(desktopPath, "DailyTasks-MyUser.txt");
            if (!File.Exists(filePath))
            {
                using StreamWriter writer = File.CreateText(filePath);
                writer.Write("Default");
            }
            ApplicationConfiguration.Initialize();
            Application.Run(new MainForm());
        }

    }
}