﻿namespace ToolsForOffice.Notification
{
    public enum NotificationType
    {
        Success,
        Information
    }
}
