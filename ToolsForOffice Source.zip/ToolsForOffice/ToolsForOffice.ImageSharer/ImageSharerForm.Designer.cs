﻿namespace ToolsForOffice.ImageSharer
{
    partial class ImageSharerForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ImageSharerForm));
            CaptureButton = new MaterialSkin.Controls.MaterialButton();
            SendButton = new MaterialSkin.Controls.MaterialButton();
            SettingsButton = new MaterialSkin.Controls.MaterialButton();
            AlwaysOnCheckBox = new CheckBox();
            ShareImageLabel = new Label();
            ShareImageTimer = new System.Windows.Forms.Timer(components);
            label1 = new Label();
            SuspendLayout();
            // 
            // CaptureButton
            // 
            CaptureButton.AutoSize = false;
            CaptureButton.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            CaptureButton.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            CaptureButton.Depth = 0;
            CaptureButton.HighEmphasis = true;
            CaptureButton.Icon = null;
            CaptureButton.Location = new Point(7, 45);
            CaptureButton.Margin = new Padding(4, 6, 4, 6);
            CaptureButton.MouseState = MaterialSkin.MouseState.HOVER;
            CaptureButton.Name = "CaptureButton";
            CaptureButton.NoAccentTextColor = Color.Empty;
            CaptureButton.Size = new Size(75, 36);
            CaptureButton.TabIndex = 0;
            CaptureButton.Text = "Capture";
            CaptureButton.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            CaptureButton.UseAccentColor = false;
            CaptureButton.UseVisualStyleBackColor = true;
            CaptureButton.Click += CaptureButton_Click;
            // 
            // SendButton
            // 
            SendButton.AutoSize = false;
            SendButton.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            SendButton.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            SendButton.Depth = 0;
            SendButton.HighEmphasis = true;
            SendButton.Icon = null;
            SendButton.Location = new Point(90, 45);
            SendButton.Margin = new Padding(4, 6, 4, 6);
            SendButton.MouseState = MaterialSkin.MouseState.HOVER;
            SendButton.Name = "SendButton";
            SendButton.NoAccentTextColor = Color.Empty;
            SendButton.Size = new Size(75, 36);
            SendButton.TabIndex = 1;
            SendButton.Text = "Send";
            SendButton.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            SendButton.UseAccentColor = false;
            SendButton.UseVisualStyleBackColor = true;
            SendButton.Click += SendButton_Click;
            // 
            // SettingsButton
            // 
            SettingsButton.AutoSize = false;
            SettingsButton.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            SettingsButton.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            SettingsButton.Depth = 0;
            SettingsButton.HighEmphasis = true;
            SettingsButton.Icon = null;
            SettingsButton.Location = new Point(173, 45);
            SettingsButton.Margin = new Padding(4, 6, 4, 6);
            SettingsButton.MouseState = MaterialSkin.MouseState.HOVER;
            SettingsButton.Name = "SettingsButton";
            SettingsButton.NoAccentTextColor = Color.Empty;
            SettingsButton.Size = new Size(75, 36);
            SettingsButton.TabIndex = 2;
            SettingsButton.Text = "Settings";
            SettingsButton.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            SettingsButton.UseAccentColor = false;
            SettingsButton.UseVisualStyleBackColor = true;
            SettingsButton.Click += SettingsButton_Click;
            // 
            // AlwaysOnCheckBox
            // 
            AlwaysOnCheckBox.AutoSize = true;
            AlwaysOnCheckBox.BackColor = Color.FromArgb(62, 81, 181);
            AlwaysOnCheckBox.Location = new Point(191, 5);
            AlwaysOnCheckBox.Name = "AlwaysOnCheckBox";
            AlwaysOnCheckBox.Size = new Size(15, 14);
            AlwaysOnCheckBox.TabIndex = 5;
            AlwaysOnCheckBox.UseVisualStyleBackColor = false;
            AlwaysOnCheckBox.CheckedChanged += AlwaysOnCheckBox_CheckedChanged;
            // 
            // ShareImageLabel
            // 
            ShareImageLabel.AutoSize = true;
            ShareImageLabel.Location = new Point(92, 26);
            ShareImageLabel.Name = "ShareImageLabel";
            ShareImageLabel.Size = new Size(0, 15);
            ShareImageLabel.TabIndex = 6;
            // 
            // ShareImageTimer
            // 
            ShareImageTimer.Interval = 1500;
            ShareImageTimer.Tick += ShareImageTimer_Tick;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.ForeColor = Color.White;
            label1.Location = new Point(7, 5);
            label1.Name = "label1";
            label1.Size = new Size(72, 15);
            label1.TabIndex = 7;
            label1.Text = "Image Share";
            // 
            // ImageSharerForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(259, 90);
            Controls.Add(label1);
            Controls.Add(ShareImageLabel);
            Controls.Add(AlwaysOnCheckBox);
            Controls.Add(SettingsButton);
            Controls.Add(SendButton);
            Controls.Add(CaptureButton);
            FormStyle = FormStyles.ActionBar_None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            Name = "ImageSharerForm";
            Padding = new Padding(3, 24, 3, 3);
            Sizable = false;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Image Share";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MaterialSkin.Controls.MaterialButton CaptureButton;
        private MaterialSkin.Controls.MaterialButton SendButton;
        private MaterialSkin.Controls.MaterialButton SettingsButton;
        private CheckBox AlwaysOnCheckBox;
        private Label ShareImageLabel;
        private System.Windows.Forms.Timer ShareImageTimer;
        private Label label1;
    }
}