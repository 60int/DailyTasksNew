﻿namespace ToolsForOffice.ImageSharer
{
    partial class SettingsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            UserNameTextBox = new MaterialSkin.Controls.MaterialTextBox();
            UserLabel = new MaterialSkin.Controls.MaterialLabel();
            ChangeFolderButton = new MaterialSkin.Controls.MaterialButton();
            SaveButton = new MaterialSkin.Controls.MaterialButton();
            CancelButton = new MaterialSkin.Controls.MaterialButton();
            FolderLabel = new Label();
            FolderNameLabel = new MaterialSkin.Controls.MaterialLabel();
            SuspendLayout();
            // 
            // UserNameTextBox
            // 
            UserNameTextBox.AnimateReadOnly = false;
            UserNameTextBox.BorderStyle = BorderStyle.None;
            UserNameTextBox.Depth = 0;
            UserNameTextBox.Font = new Font("Microsoft Sans Serif", 16F, FontStyle.Regular, GraphicsUnit.Pixel);
            UserNameTextBox.LeadingIcon = null;
            UserNameTextBox.Location = new Point(97, 39);
            UserNameTextBox.MaxLength = 50;
            UserNameTextBox.MouseState = MaterialSkin.MouseState.OUT;
            UserNameTextBox.Multiline = false;
            UserNameTextBox.Name = "UserNameTextBox";
            UserNameTextBox.Size = new Size(212, 50);
            UserNameTextBox.TabIndex = 0;
            UserNameTextBox.Text = "";
            UserNameTextBox.TrailingIcon = null;
            // 
            // UserLabel
            // 
            UserLabel.AutoSize = true;
            UserLabel.Depth = 0;
            UserLabel.Font = new Font("Roboto", 14F, FontStyle.Regular, GraphicsUnit.Pixel);
            UserLabel.Location = new Point(15, 55);
            UserLabel.MouseState = MaterialSkin.MouseState.HOVER;
            UserLabel.Name = "UserLabel";
            UserLabel.Size = new Size(76, 19);
            UserLabel.TabIndex = 1;
            UserLabel.Text = "Username:";
            // 
            // ChangeFolderButton
            // 
            ChangeFolderButton.AutoSize = false;
            ChangeFolderButton.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            ChangeFolderButton.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            ChangeFolderButton.Depth = 0;
            ChangeFolderButton.HighEmphasis = true;
            ChangeFolderButton.Icon = null;
            ChangeFolderButton.Location = new Point(81, 152);
            ChangeFolderButton.Margin = new Padding(4, 6, 4, 6);
            ChangeFolderButton.MouseState = MaterialSkin.MouseState.HOVER;
            ChangeFolderButton.Name = "ChangeFolderButton";
            ChangeFolderButton.NoAccentTextColor = Color.Empty;
            ChangeFolderButton.Size = new Size(158, 36);
            ChangeFolderButton.TabIndex = 3;
            ChangeFolderButton.Text = "Change Folder";
            ChangeFolderButton.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            ChangeFolderButton.UseAccentColor = false;
            ChangeFolderButton.UseVisualStyleBackColor = true;
            ChangeFolderButton.Click += ChangeFolderButton_Click;
            // 
            // SaveButton
            // 
            SaveButton.AutoSize = false;
            SaveButton.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            SaveButton.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            SaveButton.Depth = 0;
            SaveButton.DialogResult = DialogResult.OK;
            SaveButton.HighEmphasis = true;
            SaveButton.Icon = null;
            SaveButton.Location = new Point(81, 232);
            SaveButton.Margin = new Padding(4, 6, 4, 6);
            SaveButton.MouseState = MaterialSkin.MouseState.HOVER;
            SaveButton.Name = "SaveButton";
            SaveButton.NoAccentTextColor = Color.Empty;
            SaveButton.Size = new Size(75, 36);
            SaveButton.TabIndex = 4;
            SaveButton.Text = "Save";
            SaveButton.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            SaveButton.UseAccentColor = false;
            SaveButton.UseVisualStyleBackColor = true;
            SaveButton.Click += SaveButton_Click;
            // 
            // CancelButton
            // 
            CancelButton.AutoSize = false;
            CancelButton.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            CancelButton.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            CancelButton.Depth = 0;
            CancelButton.DialogResult = DialogResult.Cancel;
            CancelButton.HighEmphasis = true;
            CancelButton.Icon = null;
            CancelButton.Location = new Point(164, 232);
            CancelButton.Margin = new Padding(4, 6, 4, 6);
            CancelButton.MouseState = MaterialSkin.MouseState.HOVER;
            CancelButton.Name = "CancelButton";
            CancelButton.NoAccentTextColor = Color.Empty;
            CancelButton.Size = new Size(75, 36);
            CancelButton.TabIndex = 5;
            CancelButton.Text = "Cancel";
            CancelButton.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            CancelButton.UseAccentColor = false;
            CancelButton.UseVisualStyleBackColor = true;
            // 
            // FolderLabel
            // 
            FolderLabel.AutoSize = true;
            FolderLabel.Location = new Point(97, 114);
            FolderLabel.Name = "FolderLabel";
            FolderLabel.Size = new Size(0, 15);
            FolderLabel.TabIndex = 6;
            // 
            // FolderNameLabel
            // 
            FolderNameLabel.AutoSize = true;
            FolderNameLabel.Depth = 0;
            FolderNameLabel.Font = new Font("Roboto", 14F, FontStyle.Regular, GraphicsUnit.Pixel);
            FolderNameLabel.Location = new Point(42, 113);
            FolderNameLabel.MouseState = MaterialSkin.MouseState.HOVER;
            FolderNameLabel.Name = "FolderNameLabel";
            FolderNameLabel.Size = new Size(49, 19);
            FolderNameLabel.TabIndex = 7;
            FolderNameLabel.Text = "Folder:";
            // 
            // SettingsForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(329, 277);
            Controls.Add(FolderNameLabel);
            Controls.Add(FolderLabel);
            Controls.Add(CancelButton);
            Controls.Add(SaveButton);
            Controls.Add(ChangeFolderButton);
            Controls.Add(UserLabel);
            Controls.Add(UserNameTextBox);
            FormStyle = FormStyles.ActionBar_None;
            Name = "SettingsForm";
            Padding = new Padding(3, 24, 3, 3);
            Sizable = false;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "SettingsForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MaterialSkin.Controls.MaterialTextBox UserNameTextBox;
        private MaterialSkin.Controls.MaterialLabel UserLabel;
        private MaterialSkin.Controls.MaterialButton ChangeFolderButton;
        private MaterialSkin.Controls.MaterialButton SaveButton;
        private MaterialSkin.Controls.MaterialButton CancelButton;
        private Label FolderLabel;
        private MaterialSkin.Controls.MaterialLabel FolderNameLabel;
    }
}