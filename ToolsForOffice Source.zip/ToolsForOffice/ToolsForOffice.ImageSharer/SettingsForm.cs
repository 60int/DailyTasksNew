﻿using MaterialSkin.Controls;

namespace ToolsForOffice.ImageSharer
{
    public partial class SettingsForm : MaterialForm
    {
        private static string GetUser()
        {
            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string filePath = Path.Combine(desktopPath, "DailyTasks-MyUser.txt");
            string username = File.ReadAllText(filePath);
            return username;
        }

        private static string GetFolder()
        {
            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string filePath = Path.Combine(desktopPath, "DailyTasks-MyFolder.bin");
            string folderPath;
            using (var binaryReader = new BinaryReader(File.Open(filePath, FileMode.Open)))
            {
                folderPath = binaryReader.ReadString();
            }
            return folderPath + @"\";
        }

        public SettingsForm()
        {
            InitializeComponent();
            if (GetUser() == string.Empty)
            {
                string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
                string filePath = Path.Combine(desktopPath, "DailyTasks-MyUser.txt");
                File.WriteAllText(filePath, "Default");
            }
            UserNameTextBox.Text = GetUser();
            AcceptButton = SaveButton;
            string text = GetFolder();
            string[] folders = text.Split('\\');
            if (folders.Length > 4)
            {
                text = string.Join("\\", folders.Take(2)) + "\\...\\"
                    + string.Join("\\", folders.Skip(folders.Length - 3));
            }
            FolderLabel.Text = text;


        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string filePath = Path.Combine(desktopPath, "DailyTasks-MyUser.txt");
            File.WriteAllText(filePath, UserNameTextBox.Text);
        }

        private void ChangeFolderButton_Click(object sender, EventArgs e)
        {
            using var folderBrowserDialog = new FolderBrowserDialog();
            if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
            {
                string selectedPath = folderBrowserDialog.SelectedPath;
                // Save the selected path to a binary file
                string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
                string filePath = Path.Combine(desktopPath, "DailyTasks-MyFolder.bin");
                using var binaryWriter = new BinaryWriter(File.Open(filePath, FileMode.Create));
                binaryWriter.Write(selectedPath);
            }
        }
    }
}
