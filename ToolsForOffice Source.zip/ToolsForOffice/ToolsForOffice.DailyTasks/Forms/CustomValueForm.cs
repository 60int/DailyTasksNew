﻿using MaterialSkin.Controls;

namespace ToolsForOffice.DailyTasks.Forms
{
    public partial class CustomValueForm : MaterialForm
    {
        public CustomValueForm()
        {
            InitializeComponent();
        }

        public string CustomValue1 => textBox1.Text;
        public string CustomValue2 => textBox2.Text;
        public string CustomValue3 => textBox3.Text;
        public string CustomValue4 => textBox4.Text;
    }
}
