﻿namespace ToolsForOffice.DailyTasks.Forms
{
    partial class CustomValueForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            CancelButton = new MaterialSkin.Controls.MaterialButton();
            OKButton = new MaterialSkin.Controls.MaterialButton();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            SuspendLayout();
            // 
            // CancelButton
            // 
            CancelButton.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            CancelButton.Cursor = Cursors.Hand;
            CancelButton.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            CancelButton.Depth = 0;
            CancelButton.DialogResult = DialogResult.Cancel;
            CancelButton.HighEmphasis = true;
            CancelButton.Icon = null;
            CancelButton.Location = new Point(129, 172);
            CancelButton.Margin = new Padding(4, 6, 4, 6);
            CancelButton.MouseState = MaterialSkin.MouseState.HOVER;
            CancelButton.Name = "CancelButton";
            CancelButton.NoAccentTextColor = Color.Empty;
            CancelButton.Size = new Size(77, 36);
            CancelButton.TabIndex = 37;
            CancelButton.Text = "Cancel";
            CancelButton.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            CancelButton.UseAccentColor = false;
            CancelButton.UseVisualStyleBackColor = true;
            // 
            // OKButton
            // 
            OKButton.AutoSize = false;
            OKButton.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            OKButton.Cursor = Cursors.Hand;
            OKButton.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            OKButton.Depth = 0;
            OKButton.DialogResult = DialogResult.OK;
            OKButton.HighEmphasis = true;
            OKButton.Icon = null;
            OKButton.Location = new Point(46, 172);
            OKButton.Margin = new Padding(4, 6, 4, 6);
            OKButton.MouseState = MaterialSkin.MouseState.HOVER;
            OKButton.Name = "OKButton";
            OKButton.NoAccentTextColor = Color.Empty;
            OKButton.Size = new Size(75, 36);
            OKButton.TabIndex = 36;
            OKButton.Text = "OK";
            OKButton.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            OKButton.UseAccentColor = false;
            OKButton.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(62, 41);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(144, 23);
            textBox1.TabIndex = 38;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(62, 70);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(144, 23);
            textBox2.TabIndex = 39;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(62, 99);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(144, 23);
            textBox3.TabIndex = 40;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(62, 128);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(144, 23);
            textBox4.TabIndex = 41;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 44);
            label1.Name = "label1";
            label1.Size = new Size(44, 15);
            label1.TabIndex = 42;
            label1.Text = "Value 1";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 73);
            label2.Name = "label2";
            label2.Size = new Size(44, 15);
            label2.TabIndex = 43;
            label2.Text = "Value 2";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 102);
            label3.Name = "label3";
            label3.Size = new Size(44, 15);
            label3.TabIndex = 44;
            label3.Text = "Value 3";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(12, 131);
            label4.Name = "label4";
            label4.Size = new Size(44, 15);
            label4.TabIndex = 45;
            label4.Text = "Value 4";
            // 
            // CustomValueForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(222, 218);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(CancelButton);
            Controls.Add(OKButton);
            FormStyle = FormStyles.ActionBar_None;
            MaximizeBox = false;
            Name = "CustomValueForm";
            Padding = new Padding(3, 24, 3, 3);
            Sizable = false;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "CustomValueForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MaterialSkin.Controls.MaterialButton CancelButton;
        private MaterialSkin.Controls.MaterialButton OKButton;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private TextBox textBox4;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
    }
}