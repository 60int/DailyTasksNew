﻿using MaterialSkin.Controls;
using DailyTasks.Forms.Classes;
using ToolsForOffice.DailyTasks.Classes;

namespace ToolsForOffice.DailyTasks.Forms
{
    public partial class AddTaskForm : MaterialForm
    {
        readonly string[] customValueNames = Utils.GetCustomValueNames();

        DailyTask? task;
        internal DailyTask? Task
        {
            get => task;
            set
            {
                task = value;
                UserTextBox.Text = task!.Title;
                TotalNumericUpDown.Value = (int)task.TotalAmount!;
                ScrapNGNumericUpDown.Value = (int)task.CustomValue1!;
                OtherNGNumericUpDown.Value = (int)task.CustomValue2!;
                AmountLeftNumericUpDown.Value = (int)task.CustomValue3!;
                NGOKNumericUpDown.Value = (int)task.CustomValue4!;
                CompletedCheckBox.Checked = task.Completed;
                MainDateTimePicker.Value = (DateTime)task.StartTime!;
                TypeComboBox.SelectedItem = task.TaskType;
                PriorityComboBox.SelectedIndex = (int)task.Priority;
            }
        }

        private static string GetUser()
        {
            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string filePath = Path.Combine(desktopPath, "DailyTasks-MyUser.txt");
            string username = File.ReadAllText(filePath);
            return username;
        }

        public AddTaskForm(string cellTypeFilename)
        {
            InitializeComponent();
            string[] lines = File.ReadAllLines(cellTypeFilename);
            foreach (string line in lines)
            {
                string cellType = line.Split(',')[0];
                TypeComboBox.Items.Add(cellType);
            }
            TypeComboBox.SelectedIndex = 0;
            PriorityComboBox.DataSource = Enum.GetValues(typeof(TaskPriority));
            MaximizeBox = false;
            UserTextBox.Text = GetUser();
            AcceptButton = OKButton;

            CustomValueLabel1.Text = customValueNames[0];
            CustomValueLabel2.Text = customValueNames[1];
            CustomValueLabel3.Text = customValueNames[2];
            CustomValueLabel4.Text = customValueNames[3];
        }


        private void OKButton_Click(object sender, EventArgs e)
        {
            if (task == null)
            {
                if (UserTextBox.Text.Length >= 3)
                {
                    task = new DailyTask(UserTextBox.Text, (int)TotalNumericUpDown.Value, (int)ScrapNGNumericUpDown.Value, (int)OtherNGNumericUpDown.Value, (int)AmountLeftNumericUpDown.Value, (int)NGOKNumericUpDown.Value, CompletedCheckBox.Checked, MainDateTimePicker.Value, TypeComboBox.SelectedItem.ToString(), (TaskPriority)PriorityComboBox.SelectedIndex);
                }
                else
                {
                    MessageBox.Show("The title must be 3 or less characters long!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    UserTextBox.Focus();
                    DialogResult = DialogResult.None;
                }
            }
            else
            {
                task.Title = UserTextBox.Text;
                task.TotalAmount = (int)TotalNumericUpDown.Value;
                task.CustomValue1 = (int)ScrapNGNumericUpDown.Value;
                task.CustomValue2 = (int)OtherNGNumericUpDown.Value;
                task.CustomValue3 = (int)AmountLeftNumericUpDown.Value;
                task.CustomValue4 = (int)NGOKNumericUpDown.Value;
                task.Completed = CompletedCheckBox.Checked;
                task.StartTime = MainDateTimePicker.Value;
                task.TaskType = TypeComboBox.SelectedItem.ToString();
                task.Priority = (TaskPriority)PriorityComboBox.SelectedIndex;
            }
        }

        //Keep window on top always
        protected override CreateParams CreateParams
        {
            get
            {
                var cp = base.CreateParams;
                cp.ExStyle |= 8;  // Turn on WS_EX_TOPMOST
                return cp;
            }
        }

    }
}
