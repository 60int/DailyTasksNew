﻿namespace ToolsForOffice.DailyTasks
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            MainMenuStrip = new MenuStrip();
            HomeToolStripMenuItem = new MaterialSkin.Controls.MaterialToolStripMenuItem();
            FileToolStripMenuItem = new MaterialSkin.Controls.MaterialToolStripMenuItem();
            NewUserToolStripMenuItem = new MaterialSkin.Controls.MaterialToolStripMenuItem();
            UsersToolStripMenuItem = new MaterialSkin.Controls.MaterialToolStripMenuItem();
            materialToolStripMenuItem2 = new MaterialSkin.Controls.MaterialToolStripMenuItem();
            ExitToolStripMenuItem = new MaterialSkin.Controls.MaterialToolStripMenuItem();
            TasksToolStripMenuItem = new MaterialSkin.Controls.MaterialToolStripMenuItem();
            ToolsToolStripMenuItem = new MaterialSkin.Controls.MaterialToolStripMenuItem();
            ClipboardToolStripMenuItem = new MaterialSkin.Controls.MaterialToolStripMenuItem();
            EditClipboardToolStripMenuItem = new MaterialSkin.Controls.MaterialToolStripMenuItem();
            materialToolStripMenuItem1 = new MaterialSkin.Controls.MaterialToolStripMenuItem();
            MainDisplayPanel = new Panel();
            ShareImageLabel = new MaterialSkin.Controls.MaterialLabel();
            SortByWeekButton = new MaterialSkin.Controls.MaterialButton();
            ShowAllButton = new MaterialSkin.Controls.MaterialButton();
            CurrentUserLabel = new MaterialSkin.Controls.MaterialLabel();
            CurrentUser = new MaterialSkin.Controls.MaterialLabel();
            MainDateTimePicker = new DateTimePicker();
            MainListBox = new ListBox();
            MainDataGridView = new DataGridView();
            ShareImageButton = new MaterialSkin.Controls.MaterialButton();
            RemoveTaskButton = new MaterialSkin.Controls.MaterialButton();
            UpdateTaskButton = new MaterialSkin.Controls.MaterialButton();
            AddTaskButton = new MaterialSkin.Controls.MaterialButton();
            DailyTasksLabel = new Label();
            ShareImageTimer = new System.Windows.Forms.Timer(components);
            AlwaysOnCheckBox = new CheckBox();
            CustomValueToolStripMenuItem = new MaterialSkin.Controls.MaterialToolStripMenuItem();
            MainMenuStrip.SuspendLayout();
            MainDisplayPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)MainDataGridView).BeginInit();
            SuspendLayout();
            // 
            // MainMenuStrip
            // 
            MainMenuStrip.Items.AddRange(new ToolStripItem[] { HomeToolStripMenuItem, FileToolStripMenuItem, TasksToolStripMenuItem, ToolsToolStripMenuItem });
            MainMenuStrip.Location = new Point(3, 24);
            MainMenuStrip.Name = "MainMenuStrip";
            MainMenuStrip.Size = new Size(911, 36);
            MainMenuStrip.TabIndex = 1;
            // 
            // HomeToolStripMenuItem
            // 
            HomeToolStripMenuItem.AutoSize = false;
            HomeToolStripMenuItem.Name = "HomeToolStripMenuItem";
            HomeToolStripMenuItem.Size = new Size(80, 32);
            HomeToolStripMenuItem.Text = "Home";
            HomeToolStripMenuItem.Click += HomeToolStripMenuItem_Click;
            // 
            // FileToolStripMenuItem
            // 
            FileToolStripMenuItem.AutoSize = false;
            FileToolStripMenuItem.DisplayStyle = ToolStripItemDisplayStyle.Text;
            FileToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { NewUserToolStripMenuItem, UsersToolStripMenuItem, materialToolStripMenuItem2, ExitToolStripMenuItem });
            FileToolStripMenuItem.Name = "FileToolStripMenuItem";
            FileToolStripMenuItem.Size = new Size(122, 32);
            FileToolStripMenuItem.Text = "File";
            // 
            // NewUserToolStripMenuItem
            // 
            NewUserToolStripMenuItem.AutoSize = false;
            NewUserToolStripMenuItem.Name = "NewUserToolStripMenuItem";
            NewUserToolStripMenuItem.Size = new Size(128, 32);
            NewUserToolStripMenuItem.Text = "New User";
            NewUserToolStripMenuItem.Click += NewUserToolStripMenuItem_Click;
            // 
            // UsersToolStripMenuItem
            // 
            UsersToolStripMenuItem.AutoSize = false;
            UsersToolStripMenuItem.Name = "UsersToolStripMenuItem";
            UsersToolStripMenuItem.Size = new Size(128, 32);
            UsersToolStripMenuItem.Text = "Select User";
            // 
            // materialToolStripMenuItem2
            // 
            materialToolStripMenuItem2.AutoSize = false;
            materialToolStripMenuItem2.Name = "materialToolStripMenuItem2";
            materialToolStripMenuItem2.Size = new Size(128, 32);
            materialToolStripMenuItem2.Text = "Settings";
            // 
            // ExitToolStripMenuItem
            // 
            ExitToolStripMenuItem.AutoSize = false;
            ExitToolStripMenuItem.Name = "ExitToolStripMenuItem";
            ExitToolStripMenuItem.Size = new Size(128, 32);
            ExitToolStripMenuItem.Text = "Exit";
            // 
            // TasksToolStripMenuItem
            // 
            TasksToolStripMenuItem.AutoSize = false;
            TasksToolStripMenuItem.DisplayStyle = ToolStripItemDisplayStyle.Text;
            TasksToolStripMenuItem.Name = "TasksToolStripMenuItem";
            TasksToolStripMenuItem.Size = new Size(80, 32);
            TasksToolStripMenuItem.Text = "Tasks";
            TasksToolStripMenuItem.Click += TasksToolStripMenuItem_Click;
            // 
            // ToolsToolStripMenuItem
            // 
            ToolsToolStripMenuItem.AutoSize = false;
            ToolsToolStripMenuItem.DisplayStyle = ToolStripItemDisplayStyle.Text;
            ToolsToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { ClipboardToolStripMenuItem, EditClipboardToolStripMenuItem, materialToolStripMenuItem1, CustomValueToolStripMenuItem });
            ToolsToolStripMenuItem.Name = "ToolsToolStripMenuItem";
            ToolsToolStripMenuItem.Size = new Size(122, 32);
            ToolsToolStripMenuItem.Text = "Tools";
            // 
            // ClipboardToolStripMenuItem
            // 
            ClipboardToolStripMenuItem.AutoSize = false;
            ClipboardToolStripMenuItem.Name = "ClipboardToolStripMenuItem";
            ClipboardToolStripMenuItem.Size = new Size(128, 32);
            ClipboardToolStripMenuItem.Text = "Clipboard";
            ClipboardToolStripMenuItem.Click += ClipboardToolStripMenuItem_Click;
            // 
            // EditClipboardToolStripMenuItem
            // 
            EditClipboardToolStripMenuItem.AutoSize = false;
            EditClipboardToolStripMenuItem.Name = "EditClipboardToolStripMenuItem";
            EditClipboardToolStripMenuItem.Size = new Size(128, 32);
            EditClipboardToolStripMenuItem.Text = "Edit Clipboard";
            EditClipboardToolStripMenuItem.Click += EditClipboardToolStripMenuItem_Click;
            // 
            // materialToolStripMenuItem1
            // 
            materialToolStripMenuItem1.AutoSize = false;
            materialToolStripMenuItem1.Name = "materialToolStripMenuItem1";
            materialToolStripMenuItem1.Size = new Size(128, 32);
            materialToolStripMenuItem1.Text = "ImageShare";
            // 
            // MainDisplayPanel
            // 
            MainDisplayPanel.Controls.Add(ShareImageLabel);
            MainDisplayPanel.Controls.Add(SortByWeekButton);
            MainDisplayPanel.Controls.Add(ShowAllButton);
            MainDisplayPanel.Controls.Add(CurrentUserLabel);
            MainDisplayPanel.Controls.Add(CurrentUser);
            MainDisplayPanel.Controls.Add(MainDateTimePicker);
            MainDisplayPanel.Controls.Add(MainListBox);
            MainDisplayPanel.Controls.Add(MainDataGridView);
            MainDisplayPanel.Controls.Add(ShareImageButton);
            MainDisplayPanel.Controls.Add(RemoveTaskButton);
            MainDisplayPanel.Controls.Add(UpdateTaskButton);
            MainDisplayPanel.Controls.Add(AddTaskButton);
            MainDisplayPanel.Dock = DockStyle.Fill;
            MainDisplayPanel.Location = new Point(3, 60);
            MainDisplayPanel.Name = "MainDisplayPanel";
            MainDisplayPanel.Size = new Size(911, 482);
            MainDisplayPanel.TabIndex = 2;
            // 
            // ShareImageLabel
            // 
            ShareImageLabel.AutoSize = true;
            ShareImageLabel.BackColor = Color.FromArgb(30, 0, 0, 0);
            ShareImageLabel.Depth = 0;
            ShareImageLabel.Font = new Font("Roboto", 14F, FontStyle.Regular, GraphicsUnit.Pixel);
            ShareImageLabel.Location = new Point(523, 16);
            ShareImageLabel.MouseState = MaterialSkin.MouseState.HOVER;
            ShareImageLabel.Name = "ShareImageLabel";
            ShareImageLabel.Size = new Size(1, 0);
            ShareImageLabel.TabIndex = 25;
            // 
            // SortByWeekButton
            // 
            SortByWeekButton.AutoSize = false;
            SortByWeekButton.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            SortByWeekButton.Cursor = Cursors.Hand;
            SortByWeekButton.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            SortByWeekButton.Depth = 0;
            SortByWeekButton.HighEmphasis = true;
            SortByWeekButton.Icon = null;
            SortByWeekButton.Location = new Point(322, 12);
            SortByWeekButton.Margin = new Padding(4, 6, 4, 6);
            SortByWeekButton.MouseState = MaterialSkin.MouseState.HOVER;
            SortByWeekButton.Name = "SortByWeekButton";
            SortByWeekButton.NoAccentTextColor = Color.Empty;
            SortByWeekButton.Size = new Size(105, 25);
            SortByWeekButton.TabIndex = 24;
            SortByWeekButton.Text = "Sort by Week";
            SortByWeekButton.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            SortByWeekButton.UseAccentColor = false;
            SortByWeekButton.UseVisualStyleBackColor = true;
            SortByWeekButton.Click += SortByWeekButton_Click;
            // 
            // ShowAllButton
            // 
            ShowAllButton.AutoSize = false;
            ShowAllButton.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            ShowAllButton.Cursor = Cursors.Hand;
            ShowAllButton.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            ShowAllButton.Depth = 0;
            ShowAllButton.HighEmphasis = true;
            ShowAllButton.Icon = null;
            ShowAllButton.Location = new Point(209, 12);
            ShowAllButton.Margin = new Padding(4, 6, 4, 6);
            ShowAllButton.MouseState = MaterialSkin.MouseState.HOVER;
            ShowAllButton.Name = "ShowAllButton";
            ShowAllButton.NoAccentTextColor = Color.Empty;
            ShowAllButton.Size = new Size(105, 25);
            ShowAllButton.TabIndex = 23;
            ShowAllButton.Text = "Show All";
            ShowAllButton.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            ShowAllButton.UseAccentColor = false;
            ShowAllButton.UseVisualStyleBackColor = true;
            ShowAllButton.Click += ShowAllButton_Click;
            // 
            // CurrentUserLabel
            // 
            CurrentUserLabel.BackColor = Color.FromArgb(30, 0, 0, 0);
            CurrentUserLabel.Depth = 0;
            CurrentUserLabel.Font = new Font("Roboto", 14F, FontStyle.Regular, GraphicsUnit.Pixel);
            CurrentUserLabel.Location = new Point(835, 13);
            CurrentUserLabel.MouseState = MaterialSkin.MouseState.HOVER;
            CurrentUserLabel.Name = "CurrentUserLabel";
            CurrentUserLabel.Size = new Size(71, 23);
            CurrentUserLabel.TabIndex = 22;
            CurrentUserLabel.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // CurrentUser
            // 
            CurrentUser.AutoSize = true;
            CurrentUser.BackColor = Color.FromArgb(30, 0, 0, 0);
            CurrentUser.Depth = 0;
            CurrentUser.Font = new Font("Roboto", 14F, FontStyle.Regular, GraphicsUnit.Pixel);
            CurrentUser.Location = new Point(739, 15);
            CurrentUser.MouseState = MaterialSkin.MouseState.HOVER;
            CurrentUser.Name = "CurrentUser";
            CurrentUser.Size = new Size(91, 19);
            CurrentUser.TabIndex = 21;
            CurrentUser.Text = "Current User:";
            // 
            // MainDateTimePicker
            // 
            MainDateTimePicker.Location = new Point(2, 12);
            MainDateTimePicker.Name = "MainDateTimePicker";
            MainDateTimePicker.Size = new Size(200, 23);
            MainDateTimePicker.TabIndex = 20;
            // 
            // MainListBox
            // 
            MainListBox.FormattingEnabled = true;
            MainListBox.ItemHeight = 15;
            MainListBox.Location = new Point(3, 50);
            MainListBox.Name = "MainListBox";
            MainListBox.Size = new Size(158, 274);
            MainListBox.TabIndex = 12;
            MainListBox.DoubleClick += MainListBox_DoubleClick;
            // 
            // MainDataGridView
            // 
            MainDataGridView.BackgroundColor = Color.FromArgb(62, 81, 181);
            MainDataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            MainDataGridView.Location = new Point(167, 50);
            MainDataGridView.Name = "MainDataGridView";
            MainDataGridView.RowTemplate.Height = 25;
            MainDataGridView.Size = new Size(743, 431);
            MainDataGridView.TabIndex = 16;
            // 
            // ShareImageButton
            // 
            ShareImageButton.AutoSize = false;
            ShareImageButton.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            ShareImageButton.Cursor = Cursors.Hand;
            ShareImageButton.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            ShareImageButton.Depth = 0;
            ShareImageButton.HighEmphasis = true;
            ShareImageButton.Icon = null;
            ShareImageButton.Location = new Point(2, 443);
            ShareImageButton.Margin = new Padding(4, 6, 4, 6);
            ShareImageButton.MouseState = MaterialSkin.MouseState.HOVER;
            ShareImageButton.Name = "ShareImageButton";
            ShareImageButton.NoAccentTextColor = Color.Empty;
            ShareImageButton.Size = new Size(158, 36);
            ShareImageButton.TabIndex = 15;
            ShareImageButton.Text = "Share Screenshot";
            ShareImageButton.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            ShareImageButton.UseAccentColor = false;
            ShareImageButton.UseVisualStyleBackColor = true;
            ShareImageButton.Click += ShareImageButton_Click;
            // 
            // RemoveTaskButton
            // 
            RemoveTaskButton.AutoSize = false;
            RemoveTaskButton.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            RemoveTaskButton.Cursor = Cursors.Hand;
            RemoveTaskButton.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            RemoveTaskButton.Depth = 0;
            RemoveTaskButton.HighEmphasis = true;
            RemoveTaskButton.Icon = null;
            RemoveTaskButton.Location = new Point(2, 405);
            RemoveTaskButton.Margin = new Padding(4, 6, 4, 6);
            RemoveTaskButton.MouseState = MaterialSkin.MouseState.HOVER;
            RemoveTaskButton.Name = "RemoveTaskButton";
            RemoveTaskButton.NoAccentTextColor = Color.Empty;
            RemoveTaskButton.Size = new Size(158, 36);
            RemoveTaskButton.TabIndex = 14;
            RemoveTaskButton.Text = "Remove";
            RemoveTaskButton.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            RemoveTaskButton.UseAccentColor = false;
            RemoveTaskButton.UseVisualStyleBackColor = true;
            RemoveTaskButton.Click += RemoveTaskButton_Click;
            // 
            // UpdateTaskButton
            // 
            UpdateTaskButton.AutoSize = false;
            UpdateTaskButton.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            UpdateTaskButton.Cursor = Cursors.Hand;
            UpdateTaskButton.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            UpdateTaskButton.Depth = 0;
            UpdateTaskButton.HighEmphasis = true;
            UpdateTaskButton.Icon = null;
            UpdateTaskButton.Location = new Point(2, 367);
            UpdateTaskButton.Margin = new Padding(4, 6, 4, 6);
            UpdateTaskButton.MouseState = MaterialSkin.MouseState.HOVER;
            UpdateTaskButton.Name = "UpdateTaskButton";
            UpdateTaskButton.NoAccentTextColor = Color.Empty;
            UpdateTaskButton.Size = new Size(158, 36);
            UpdateTaskButton.TabIndex = 13;
            UpdateTaskButton.Text = "Update";
            UpdateTaskButton.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            UpdateTaskButton.UseAccentColor = false;
            UpdateTaskButton.UseVisualStyleBackColor = true;
            UpdateTaskButton.Click += UpdateTaskButton_Click;
            // 
            // AddTaskButton
            // 
            AddTaskButton.AutoSize = false;
            AddTaskButton.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            AddTaskButton.Cursor = Cursors.Hand;
            AddTaskButton.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            AddTaskButton.Depth = 0;
            AddTaskButton.HighEmphasis = true;
            AddTaskButton.Icon = null;
            AddTaskButton.Location = new Point(3, 329);
            AddTaskButton.Margin = new Padding(4, 6, 4, 6);
            AddTaskButton.MouseState = MaterialSkin.MouseState.HOVER;
            AddTaskButton.Name = "AddTaskButton";
            AddTaskButton.NoAccentTextColor = Color.Empty;
            AddTaskButton.Size = new Size(158, 36);
            AddTaskButton.TabIndex = 12;
            AddTaskButton.Text = "Add Task";
            AddTaskButton.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            AddTaskButton.UseAccentColor = false;
            AddTaskButton.UseVisualStyleBackColor = true;
            AddTaskButton.Click += AddTaskButton_Click;
            // 
            // DailyTasksLabel
            // 
            DailyTasksLabel.AutoSize = true;
            DailyTasksLabel.BackColor = Color.FromArgb(48, 62, 159);
            DailyTasksLabel.ForeColor = SystemColors.Control;
            DailyTasksLabel.Location = new Point(7, 4);
            DailyTasksLabel.Name = "DailyTasksLabel";
            DailyTasksLabel.Size = new Size(63, 15);
            DailyTasksLabel.TabIndex = 3;
            DailyTasksLabel.Text = "Daily Tasks";
            // 
            // ShareImageTimer
            // 
            ShareImageTimer.Interval = 1000;
            ShareImageTimer.Tick += ShareImageTimer_Tick;
            // 
            // AlwaysOnCheckBox
            // 
            AlwaysOnCheckBox.AutoSize = true;
            AlwaysOnCheckBox.BackColor = Color.FromArgb(62, 81, 181);
            AlwaysOnCheckBox.Location = new Point(847, 5);
            AlwaysOnCheckBox.Name = "AlwaysOnCheckBox";
            AlwaysOnCheckBox.Size = new Size(15, 14);
            AlwaysOnCheckBox.TabIndex = 4;
            AlwaysOnCheckBox.UseVisualStyleBackColor = false;
            AlwaysOnCheckBox.CheckedChanged += AlwaysOnCheckBox_CheckedChanged;
            // 
            // CustomValueToolStripMenuItem
            // 
            CustomValueToolStripMenuItem.AutoSize = false;
            CustomValueToolStripMenuItem.Name = "CustomValueToolStripMenuItem";
            CustomValueToolStripMenuItem.Size = new Size(128, 32);
            CustomValueToolStripMenuItem.Text = "Custom Values";
            CustomValueToolStripMenuItem.Click += CustomValueToolStripMenuItem_Click;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(917, 545);
            Controls.Add(AlwaysOnCheckBox);
            Controls.Add(DailyTasksLabel);
            Controls.Add(MainDisplayPanel);
            Controls.Add(MainMenuStrip);
            FormStyle = FormStyles.ActionBar_None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            Name = "MainForm";
            Padding = new Padding(3, 24, 3, 3);
            Sizable = false;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Daily Tasks";
            Load += MainForm_Load;
            MainMenuStrip.ResumeLayout(false);
            MainMenuStrip.PerformLayout();
            MainDisplayPanel.ResumeLayout(false);
            MainDisplayPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)MainDataGridView).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private MenuStrip MainMenuStrip;
        private MaterialSkin.Controls.MaterialToolStripMenuItem HomeToolStripMenuItem;
        private MaterialSkin.Controls.MaterialToolStripMenuItem FileToolStripMenuItem;
        private MaterialSkin.Controls.MaterialToolStripMenuItem NewUserToolStripMenuItem;
        private MaterialSkin.Controls.MaterialToolStripMenuItem UsersToolStripMenuItem;
        private MaterialSkin.Controls.MaterialToolStripMenuItem ExitToolStripMenuItem;
        private MaterialSkin.Controls.MaterialToolStripMenuItem TasksToolStripMenuItem;
        private MaterialSkin.Controls.MaterialToolStripMenuItem ToolsToolStripMenuItem;
        private Panel MainDisplayPanel;
        private Label DailyTasksLabel;
        private DataGridView MainDataGridView;
        private MaterialSkin.Controls.MaterialButton ShareImageButton;
        private MaterialSkin.Controls.MaterialButton RemoveTaskButton;
        private MaterialSkin.Controls.MaterialButton UpdateTaskButton;
        private MaterialSkin.Controls.MaterialButton AddTaskButton;
        private ListBox MainListBox;
        private System.Windows.Forms.Timer ShareImageTimer;
        private MaterialSkin.Controls.MaterialButton SortByWeekButton;
        private MaterialSkin.Controls.MaterialButton ShowAllButton;
        private MaterialSkin.Controls.MaterialLabel CurrentUserLabel;
        private MaterialSkin.Controls.MaterialLabel CurrentUser;
        private DateTimePicker MainDateTimePicker;
        private MaterialSkin.Controls.MaterialLabel ShareImageLabel;
        private MaterialSkin.Controls.MaterialToolStripMenuItem ClipboardToolStripMenuItem;
        private MaterialSkin.Controls.MaterialToolStripMenuItem EditClipboardToolStripMenuItem;
        private CheckBox AlwaysOnCheckBox;
        private MaterialSkin.Controls.MaterialToolStripMenuItem materialToolStripMenuItem1;
        private MaterialSkin.Controls.MaterialToolStripMenuItem materialToolStripMenuItem2;
        private MaterialSkin.Controls.MaterialToolStripMenuItem CustomValueToolStripMenuItem;
    }
}