namespace ToolsForOffice.DailyTasks
{
    internal static class Program
    {
        [STAThread]
        public static void EnsureValuesFileExists()
        {
            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string valuesFilePath = Path.Combine(desktopPath, "DailyTasks-Values.bin");

            if (!File.Exists(valuesFilePath))
            {
                string[] defaultValues = new[] { "CustomValue1", "CustomValue2", "CustomValue3", "CustomValue4" };
                File.WriteAllLines(valuesFilePath, defaultValues);
            }
        }

        static void Main()
        {
            EnsureValuesFileExists();

            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string filePath = Path.Combine(desktopPath, "DailyTasks-MyUser.txt");
            if (!File.Exists(filePath))
            {
                using StreamWriter writer = File.CreateText(filePath);
                writer.Write("Default");
            }
            ApplicationConfiguration.Initialize();
            Application.Run(new MainForm());
        }

    }
}