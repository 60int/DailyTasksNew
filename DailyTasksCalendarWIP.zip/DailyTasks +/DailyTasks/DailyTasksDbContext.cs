﻿using System;
using DailyTasks.Models;
using Microsoft.EntityFrameworkCore;

namespace DailyTasks
{
    public class DailyTasksDbContext : DbContext
    {
        public DbSet<User> Users { get; set; }
        public DbSet<DailyTask> DailyTasks { get; set; }
        public DbSet<DailyEvent> DailyEvents { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite($"Data Source={AppDomain.CurrentDomain.BaseDirectory}DailyTasksDB.db");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<DailyTask>().ToTable("DailyTasks");
            modelBuilder.Entity<DailyEvent>().ToTable("DailyEvents");
        }
    }
}