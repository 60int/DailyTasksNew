﻿using System;
using DailyTasks.ViewModels;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using DailyTasks.ViewModels.EventCalendar;

namespace DailyTasks.Models
{
    public enum HolidayType
    {
        Sick,
        Holiday,
        Family,
        Special
    }

    public class DailyEvent : ViewModelBase, ICalendarEvent
    {
        private int id;
        private int userId;
        private string label;
        private User user;
        private DateTime? dateFrom;
        private DateTime? dateTo;
        private string? comment;
        private HolidayType holidayType;

        public int Id
        {
            get { return id; }
            set { id = value; OnPropertyChanged(nameof(Id)); }
        }

        public int UserId
        {
            get { return userId; }
            set { userId = value; OnPropertyChanged(nameof(UserId)); }
        }

        public User User
        {
            get { return user; }
            set { user = value; OnPropertyChanged(nameof(User)); }
        }

        public string Label
        {
            get { return label; }
            set { label = value; OnPropertyChanged(nameof(Label)); }
        }

        public DateTime? DateFrom
        {
            get { return dateFrom; }
            set { dateFrom = value; OnPropertyChanged(nameof(DateFrom)); }
        }

        public DateTime? DateTo
        {
            get { return dateTo; }
            set { dateTo = value; OnPropertyChanged(nameof(DateTo)); }
        }

        public string? Comment
        {
            get { return comment; }
            set { comment = value; OnPropertyChanged(nameof(Comment)); }
        }

        public HolidayType HolidayType
        {
            get { return holidayType; }
            set { holidayType = value; OnPropertyChanged(nameof(HolidayType)); }
        }

        private ObservableCollection<DailyEvent>? dailyEvents;
        public ObservableCollection<DailyEvent>? DailyEvents
        {
            get => dailyEvents;
            set { dailyEvents = value; OnPropertyChanged(nameof(DailyEvents)); }
        }

        public DailyEvent()
        {
            DailyEvents = new ObservableCollection<DailyEvent>();
        }
        private void HolidaysModels_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            OnPropertyChanged(nameof(DailyEvents));
        }
    }

}
