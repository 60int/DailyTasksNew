﻿using DailyTasks.ViewModels;
using System.Collections.ObjectModel;
using System.Collections.Specialized;

namespace DailyTasks.Models
{
    public class User : ViewModelBase
    {
        public int Id { get; set; }

        public string? UserName { get; set; }

        public ObservableCollection<DailyTask> DailyTasks { get; set; }
        public ObservableCollection<DailyEvent> Holidays { get; set; }

        public User()
        {
            DailyTasks = new ObservableCollection<DailyTask>();
            Holidays = new ObservableCollection<DailyEvent>();
        }

        private ObservableCollection<User>? users;

        public ObservableCollection<User>? Users
        {
            get => users!;
            set { users = value; OnPropertyChanged(nameof(users)); }
        }

        private void DailyTasksModels_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            OnPropertyChanged(nameof(Users));
        }
    }
}
