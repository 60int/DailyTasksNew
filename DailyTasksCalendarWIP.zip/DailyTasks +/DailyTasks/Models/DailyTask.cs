﻿using System;
using DailyTasks.ViewModels;
using System.Collections.ObjectModel;
using System.Collections.Specialized;

namespace DailyTasks.Models
{
    public enum TaskPriority
    {
        Normal,
        Important,
        Urgent
    }

    public class DailyTask : ViewModelBase
    {
        private int id;
        private int userId;
        User user;
        private int? totalAmount;
        private int? customValue1;
        private int? customValue2;
        private int? customValue3;
        private int? customValue4;
        private bool completed;
        private DateTime? startTime;
        private DateTime? endTime;
        TaskPriority priority;
        private string? taskType;

        public int Id
        {
            get => id;
            set { id = value; OnPropertyChanged(nameof(Id)); }
        }
        public int UserId
        {
            get => userId;
            set { userId = value; OnPropertyChanged(nameof(UserId)); }
        }

        public User User
        {
            get => user;
            set { user = value; OnPropertyChanged(nameof(User)); }
        }

        public int? TotalAmount
        {
            get => totalAmount!;
            set { totalAmount = value; OnPropertyChanged(nameof(TotalAmount)); }
        }

        public int? CustomValue1
        {
            get => customValue1!;
            set { customValue1 = value; OnPropertyChanged(nameof(CustomValue1)); }
        }

        public int? CustomValue2
        {
            get => customValue2!;
            set { customValue2 = value; OnPropertyChanged(nameof(CustomValue2)); }
        }

        public int? CustomValue3
        {
            get => customValue3!;
            set { customValue3 = value; OnPropertyChanged(nameof(CustomValue3)); }
        }

        public int? CustomValue4
        {
            get => customValue4!;
            set { customValue4 = value; OnPropertyChanged(nameof(CustomValue4)); }
        }

        public bool Completed
        {
            get => completed!;
            set { completed = value; OnPropertyChanged(nameof(Completed)); }
        }

        public DateTime? StartTime
        {
            get => startTime!;
            set { startTime = value; OnPropertyChanged(nameof(StartTime)); }
        }

        public DateTime? EndTime
        {
            get => endTime!;
            set { endTime = value; OnPropertyChanged(nameof(EndTime)); }
        }

        public TaskPriority Priority
        {
            get => priority!;
            set { priority = value; OnPropertyChanged(nameof(Priority)); }
        }

        public string? TaskType
        {
            get => taskType!;
            set { taskType = value; OnPropertyChanged(nameof(TaskType)); }
        }

        private ObservableCollection<DailyTask>? dailyTasks;
        public ObservableCollection<DailyTask>? DailyTasks
        {
            get => dailyTasks!;
            set { dailyTasks = value; OnPropertyChanged(nameof(DailyTasks)); }
        }

        public DailyTask()
        {
            DailyTasks = new ObservableCollection<DailyTask>();
        }
        private void DailyTasksModels_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            OnPropertyChanged(nameof(DailyTasks));
        }
    }

}