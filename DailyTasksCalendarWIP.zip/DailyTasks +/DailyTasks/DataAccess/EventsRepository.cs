﻿using DailyTasks.Models;
using System.Threading.Tasks;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace DailyTasks.DataAccess
{
    public class EventsRepository
    {
        private readonly DailyTasksDbContext? _dbContext = null;
        public DailyTasksDbContext DbContext => _dbContext;
        public EventsRepository()
        {
            _dbContext = new DailyTasksDbContext();
        }
        public async Task<DailyEvent> Get(int id)
        {
            return await _dbContext!.DailyEvents.Include(t => t.User).FirstOrDefaultAsync(t => t.Id == id);
        }
        public async Task<IEnumerable<DailyEvent>> GetAll()
        {
            return await _dbContext!.DailyEvents.Include(t => t.User).ToListAsync();
        }
        public async Task AddDailyEvent(DailyEvent dailyEvent)
        {
            if (dailyEvent != null)
            {
                await _dbContext!.DailyEvents.AddAsync(dailyEvent);
                await _dbContext.SaveChangesAsync();
            }
        }
        public async Task UpdateDailyEvent(DailyEvent dailyEvent)
        {
            var eventToUpdate = await Get(dailyEvent.Id);
            if (eventToUpdate != null)
            {
                eventToUpdate.User = dailyEvent.User;
                eventToUpdate.Label = dailyEvent.Label;
                eventToUpdate.DateFrom = dailyEvent.DateFrom;
                eventToUpdate.DateTo= dailyEvent.DateTo;
                eventToUpdate.HolidayType = dailyEvent.HolidayType;
                eventToUpdate.Comment = dailyEvent.Comment;

                await _dbContext!.SaveChangesAsync();
            }
        }
        public async Task RemoveDailyEvent(int id)
        {
            var dailyEvents = await _dbContext!.DailyEvents.FindAsync(id);
            if (dailyEvents != null)
            {
                _dbContext.DailyEvents.Remove(dailyEvents);
                await _dbContext.SaveChangesAsync();
            }
        }
    }
}
