﻿using DailyTasks.Views.EventCalendar;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using Wpf.Ui.Input;

namespace DailyTasks.ViewModels.EventCalendar
{
    public class CalendarMonthViewModel : ViewModelBase
    {
        public ICommand CalendarEventDoubleClickedCommand { get; }
        public ICommand CalendarEventClickedCommand { get; }

        public event EventHandler<CalendarEventView> CalendarEventDoubleClickedEvent;

        public ObservableCollection<CalendarDay> DaysInCurrentMonth { get; set; }

        private IEnumerable<object> _events;
        public IEnumerable<object> Events
        {
            get { return _events; }
            set { SetProperty(ref _events, value); }
        }

        private DateTime _currentDate;
        public DateTime CurrentDate
        {
            get { return _currentDate; }
            set
            {
                if (_currentDate != value)
                {
                    _currentDate = value;
                    OnPropertyChanged(nameof(CurrentDate));
                    // Update SelectedMonth and SelectedYear based on CurrentDate
                    SelectedMonth = CurrentDate.Month;
                    SelectedYear = CurrentDate.Year;
                }
            }
        }

        private int _selectedMonth;
        public int SelectedMonth
        {
            get { return _selectedMonth; }
            set
            {
                if (_selectedMonth != value)
                {
                    _selectedMonth = value;
                    OnPropertyChanged(nameof(SelectedMonth));
                    // Update CurrentDate based on SelectedMonth and SelectedYear
                    CurrentDate = new DateTime(SelectedYear, SelectedMonth, 1);
                }
            }
        }

        private int _selectedYear;
        public int SelectedYear
        {
            get { return _selectedYear; }
            set
            {
                if (_selectedYear != value)
                {
                    _selectedYear = value;
                    OnPropertyChanged(nameof(SelectedYear));
                    // Update CurrentDate based on SelectedMonth and SelectedYear
                    CurrentDate = new DateTime(SelectedYear, SelectedMonth, 1);
                }
            }
        }


        public CalendarMonthViewModel()
        {
            DaysInCurrentMonth = new ObservableCollection<CalendarDay>();
            CalendarEventDoubleClickedCommand = new RelayCommand<CalendarEventView>(CalendarEventDoubleClicked);
            CalendarEventClickedCommand = new RelayCommand<CalendarEventView>(CalendarEventClicked);
        }
        public void CalendarEventDoubleClicked(CalendarEventView calendarEventView)
        {
            CalendarEventDoubleClickedEvent?.Invoke(this, calendarEventView);
        }

        public void CalendarEventClicked(CalendarEventView eventToSelect)
        {
            //foreach (CalendarDayViewModel day in DaysInCurrentMonth)
            //{
            //    foreach (CalendarEventViewModel e in day.Events)
            //    {
            //        if (e.Event == eventToSelect.Event)
            //        {
            //            e.BackgroundColor = HighlightColor;
            //        }
            //        else
            //        {
            //            e.BackgroundColor = e.DefaultBackgroundColor;
            //        }
            //    }
            //}
        }

        public ObservableCollection<CalendarDay> Days { get; } = new ObservableCollection<CalendarDay>();
        public void DrawDays()
        {
            Days.Clear();
            DaysInCurrentMonth.Clear();

            DateTime firstDayOfMonth = new(CurrentDate.Year, CurrentDate.Month, 1);
            DateTime lastDayOfMonth = firstDayOfMonth.AddMonths(1).AddDays(-1);

            for (DateTime date = firstDayOfMonth; date.Date <= lastDayOfMonth; date = date.AddDays(1))
            {
                CalendarDay newDay = new()
                {
                    BorderThickness = new Thickness((double)0.5 / 2), // /2 because neighbor day has border too, so two half borders next to each other will create final border
                    BorderBrush = Brushes.White,
                    Date = date
                };
                DaysInCurrentMonth.Add(newDay);
            }

            int row = 0;
            int column = 0;

            for (int i = 0; i < DaysInCurrentMonth.Count; i++)
            {
                switch (DaysInCurrentMonth[i].Date.DayOfWeek)
                {
                    case DayOfWeek.Monday:
                        column = 0;
                        break;
                    case DayOfWeek.Tuesday:
                        column = 1;
                        break;
                    case DayOfWeek.Wednesday:
                        column = 2;
                        break;
                    case DayOfWeek.Thursday:
                        column = 3;
                        break;
                    case DayOfWeek.Friday:
                        column = 4;
                        break;
                    case DayOfWeek.Saturday:
                        column = 5;
                        break;
                    case DayOfWeek.Sunday:
                        column = 6;
                        break;
                }

                Grid.SetRow(DaysInCurrentMonth[i], row);
                Grid.SetColumn(DaysInCurrentMonth[i], column);
                Days.Add(DaysInCurrentMonth[i]);

                if (column == 6)
                {
                    row++;
                }
            }

            DrawTopBorder();
            DrawBottomBorder();
            DrawRightBorder();
            DrawLeftBorder();

            // set some background today
            CalendarDay today = DaysInCurrentMonth.Where(d => d.Date == DateTime.Today).FirstOrDefault();
            if (today != null)
            {
                today.Foreground = Brushes.Black;
                today.Background = Brushes.SkyBlue;
            }

            DrawEvents();
        }
        private void DrawTopBorder()
        {
            // draw top border line to be the same as inner lines in calendar
            for (int i = 0; i < 7; i++)
            {
                DaysInCurrentMonth[i].BorderThickness = new Thickness(DaysInCurrentMonth[i].BorderThickness.Left, 0.5, DaysInCurrentMonth[i].BorderThickness.Right, DaysInCurrentMonth[i].BorderThickness.Bottom);
                DaysInCurrentMonth[i].BorderBrush = Brushes.White;
            }
        }

        private void DrawBottomBorder()
        {
            // draw bottom border line to be the same as inner lines in calendar
            int daysInCurrentMonth = DateTime.DaysInMonth(CurrentDate.Year, CurrentDate.Month);
            for (int i = daysInCurrentMonth - 1; i >= daysInCurrentMonth - 7; i--)
            {
                DaysInCurrentMonth[i].BorderThickness = new Thickness(DaysInCurrentMonth[i].BorderThickness.Left, DaysInCurrentMonth[i].BorderThickness.Top, DaysInCurrentMonth[i].BorderThickness.Right, 0.5);
                DaysInCurrentMonth[i].BorderBrush = Brushes.White;
            }
        }

        private void DrawRightBorder()
        {
            // draw right border line to be the same as inner lines in calendar
            IEnumerable<CalendarDay> sundays = DaysInCurrentMonth.Where(d => d.Date.DayOfWeek == DayOfWeek.Sunday);
            foreach (var sunday in sundays)
            {
                sunday.BorderThickness = new Thickness(sunday.BorderThickness.Left, sunday.BorderThickness.Top, 0.5, sunday.BorderThickness.Bottom);
                sunday.BorderBrush = Brushes.White;
            }
            // right border for last day in month
            var lastDay = DaysInCurrentMonth.Last();
            lastDay.BorderThickness = new Thickness(lastDay.BorderThickness.Left, lastDay.BorderThickness.Top, 0.5, lastDay.BorderThickness.Bottom);
            lastDay.BorderBrush = Brushes.White;

        }

        private void DrawLeftBorder()
        {
            // draw left border line to be the same as inner lines in calendar
            IEnumerable<CalendarDay> mondays = DaysInCurrentMonth.Where(d => d.Date.DayOfWeek == DayOfWeek.Monday);
            foreach (var monday in mondays)
            {
                monday.BorderThickness = new Thickness(0.5, monday.BorderThickness.Top, monday.BorderThickness.Right, monday.BorderThickness.Bottom);
                monday.BorderBrush = Brushes.White;
            }
            // left border for first day in month
            var firstDay = DaysInCurrentMonth.First();
            firstDay.BorderThickness = new Thickness(0.5, firstDay.BorderThickness.Top, firstDay.BorderThickness.Right, firstDay.BorderThickness.Bottom);
            firstDay.BorderBrush = Brushes.White;
        }
        public ObservableCollection<CalendarEventView> EventViews { get; } = new ObservableCollection<CalendarEventView>();

        private void DrawEvents()
        {
            // Clear the collection
            EventViews.Clear();

            if (Events is IEnumerable<ICalendarEvent> events)
            {
                SolidColorBrush[] colors = { Brushes.White, Brushes.White, Brushes.White };
                int accentColor = 0;

                foreach (var e in events.OrderBy(e => e.DateFrom))
                {
                    if (!e.DateFrom.HasValue || !e.DateTo.HasValue)
                    {
                        continue;
                    }

                    var dateFrom = (DateTime)e.DateFrom;
                    var dateTo = (DateTime)e.DateTo;

                    for (DateTime date = dateFrom; date <= dateTo; date = date.AddDays(1))
                    {
                        CalendarDay day = DaysInCurrentMonth.Where(d => d.Date.Date == date.Date).FirstOrDefault();

                        if (day == null)
                        {
                            continue;
                        }

                        int accentColorIndex = accentColor % colors.Length;
                        CalendarEventView calendarEventView = new CalendarEventView();

                        calendarEventView.DataContext = e;

                        // Add the event view to the collection
                        EventViews.Add(calendarEventView);
                    }
                    accentColor++;
                }
            }
            else
            {
                throw new ArgumentException("Events must be IEnumerable<ICalendarEvent>");
            }
        }

    }
}
