﻿using System.Windows.Input;
using System.Windows.Media;
using Wpf.Ui.Input;

namespace DailyTasks.ViewModels.EventCalendar
{
    public class CalendarEventViewModel : ViewModelBase
    {
        private SolidColorBrush _backgroundColor;
        public SolidColorBrush BackgroundColor
        {
            get { return _backgroundColor; }
            set { SetProperty(ref _backgroundColor, value); }
        }

        public ICommand EventMouseDownCommand { get; }

        public CalendarEventViewModel()
        {
            EventMouseDownCommand = new RelayCommand<MouseButtonEventArgs>(EventMouseDown);
        }

        private void EventMouseDown(MouseButtonEventArgs e)
        {

            //if (e.ChangedButton == MouseButton.Left && e.ClickCount == 2)
            //{
            //    _calendar.CalendarEventDoubleClicked(this);
            //}
            //else if (e.ChangedButton == MouseButton.Left && e.ClickCount == 1)
            //{
            //    _calendar.CalendarEventClicked(this);
            //}
        }
    }

}
