﻿namespace DailyTasks.ViewModels.EventCalendar
{
    public class CalendarDayViewModel : ViewModelBase
    {
        public CalendarDayViewModel()
        {
            
        }
    }
}
