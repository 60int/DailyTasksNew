﻿using DailyTasks.DataAccess;
using DailyTasks.Models;
using DailyTasks.Views;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Windows.Input;
using Wpf.Ui.Input;

namespace DailyTasks.ViewModels
{
    public class CalendarPageViewModel : ViewModelBase
    {
        private ICommand? _openAddEventWindowCommand;
        private readonly EventsRepository? _eventsRepository;
        public ObservableCollection<DailyEvent> DailyEvents { get; set; }
        public CalendarPageViewModel()
        {
            DailyEvents = new ObservableCollection<DailyEvent>();
            _eventsRepository = new EventsRepository();
            GetAll();
        }
        public ICommand OpenAddEventWindowCommand
        {
            get
            {
                _openAddEventWindowCommand ??= new AsyncRelayCommand(async param => await OpenAddEventWindow(), null);
                return _openAddEventWindowCommand;
            }
        }
        public async Task GetAll()
        {
            DailyEvents.Clear();
            var events = await _eventsRepository!.GetAll();
            foreach (var data in events)
            {
                DailyEvents.Add(new DailyEvent()
                {
                    Id = data.Id,
                    User = data.User,
                    Label = data.Label,
                    DateFrom = data.DateFrom,
                    DateTo = data.DateTo,
                    Comment = data.Comment,
                    HolidayType = data.HolidayType
                });
            }
        }
        public async Task OpenAddEventWindow()
        {
            var eventWindow = new AddEventWindow
            {
                DataContext = new AddEventViewModel()
            };
            eventWindow.ShowDialog();
            await GetAll();
        }
    }

}
