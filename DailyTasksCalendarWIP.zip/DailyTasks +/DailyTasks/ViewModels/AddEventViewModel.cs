﻿using DailyTasks.DataAccess;
using DailyTasks.Models;
using DailyTasks.Views;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace DailyTasks.ViewModels
{
    public class AddEventViewModel
    {
        private ICommand? _saveCommand;
        private EventsRepository? _eventsRepository;
        private readonly DailyEvent? _dailyEventEntity = null!;
        public DailyEvent DailyEventRecord { get; set; }
        public static Array HolidayTypes
        {
            get { return Enum.GetValues(typeof(HolidayType)); }
        }
        public ICommand? SaveCommand
        {
            get
            {
                _saveCommand ??= new AsyncRelayCommand(async param => await SaveData(), null!);

                return _saveCommand;
            }
        }
        public AddEventViewModel()
        {
             DailyEventRecord = new DailyEvent();
            _dailyEventEntity = new DailyEvent();

            LoadCurrentUser();
        }
        private static string? GetUsernameFromFile()
        {
            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string filePath = Path.Combine(desktopPath, "DailyTasks", "DailyTasks-MyUser.txt");
            string username = File.ReadAllText(filePath).Trim();
            return username;
        }
        public async Task LoadCurrentUser()
        {
            UsersRepository usersRepository = new();
            string currentUserName = GetUsernameFromFile()!;
            User currentUser = (await usersRepository.GetAll()).FirstOrDefault(u => u.UserName == currentUserName)!;
            if (currentUser != null)
            {
                DailyEventRecord.User = currentUser;
            }
        }
        public async Task SaveData()
        {
            _eventsRepository = new EventsRepository();
            UsersRepository usersRepository = new();
            if (DailyEventRecord.User != null)
            {
                User user = (await usersRepository.GetAll()).FirstOrDefault(u => u.UserName == DailyEventRecord.User.UserName)!;
                if (user == null)
                {
                    MessageBox.Show("The user does not exist.");
                    return;
                }
                _eventsRepository.DbContext.Users.Attach(user);
                _dailyEventEntity!.UserId = user.Id;
                _dailyEventEntity!.User.UserName = user.UserName;
                _dailyEventEntity!.Label = DailyEventRecord.Label;
                _dailyEventEntity!.DateFrom = DailyEventRecord.DateFrom;
                _dailyEventEntity!.DateTo = DailyEventRecord.DateTo;
                _dailyEventEntity!.Comment = DailyEventRecord.Comment;
                _dailyEventEntity!.HolidayType = DailyEventRecord.HolidayType;
                try
                {
                    if (DailyEventRecord.Id <= 0)
                    {
                        await _eventsRepository!.AddDailyEvent(_dailyEventEntity);
                        MessageBox.Show("New event successfully saved.");
                    }
                    else
                    {
                        _dailyEventEntity.Id = DailyEventRecord.Id;
                        await _eventsRepository!.UpdateDailyEvent(_dailyEventEntity);
                        MessageBox.Show("Event successfully updated.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occured while saving. " + ex.InnerException);
                }
            }
            if (Application.Current.Windows.OfType<AddTaskWindow>().FirstOrDefault() is AddTaskWindow tasksPage)
            {
                tasksPage.Close();
            }
        }
    }
}
