﻿using DailyTasks.ViewModels;
using Wpf.Ui.Controls;

namespace DailyTasks.Views
{
    public partial class CalendarPage : UiPage
    {
        public CalendarPage()
        {
            InitializeComponent();
            DataContext = new CalendarPageViewModel();
        }
    }
}
