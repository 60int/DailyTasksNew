﻿using DailyTasks.ViewModels;
using System;
using System.Windows.Controls;

namespace DailyTasks.Views.EventCalendar
{
    public partial class CalendarDay : UserControl
    {
        public DateTime Date { get; set; }

        public CalendarDay()
        {
            InitializeComponent();
            DataContext = this;
            //var addEventWindow = new AddEventWindow
            //{
            //    DataContext = new AddEventViewModel()
            //};
            //addEventWindow.ShowDialog();
        }
    }
}
