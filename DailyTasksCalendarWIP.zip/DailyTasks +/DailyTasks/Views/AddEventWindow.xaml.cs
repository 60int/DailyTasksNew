﻿using Wpf.Ui.Controls;

namespace DailyTasks.Views
{
    public partial class AddEventWindow : UiWindow
    {
        public AddEventWindow()
        {
            InitializeComponent();
        }
    }
}
