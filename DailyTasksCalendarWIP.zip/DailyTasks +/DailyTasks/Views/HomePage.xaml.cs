﻿using Wpf.Ui.Controls;

namespace DailyTasks.Views
{
    public partial class HomePage : UiPage
    {
        public HomePage()
        {
            InitializeComponent();
        }
    }
}
