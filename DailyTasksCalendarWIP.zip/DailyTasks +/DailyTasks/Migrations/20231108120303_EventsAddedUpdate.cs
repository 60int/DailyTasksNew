﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DailyTasks.Migrations
{
    /// <inheritdoc />
    public partial class EventsAddedUpdate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "DailyEvents",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    UserId = table.Column<int>(type: "INTEGER", nullable: false),
                    Label = table.Column<string>(type: "TEXT", nullable: false),
                    DateFrom = table.Column<DateTime>(type: "TEXT", nullable: true),
                    DateTo = table.Column<DateTime>(type: "TEXT", nullable: true),
                    Comment = table.Column<string>(type: "TEXT", nullable: true),
                    HolidayType = table.Column<int>(type: "INTEGER", nullable: false),
                    DailyEventId = table.Column<int>(type: "INTEGER", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DailyEvents", x => x.Id);
                    table.ForeignKey(
                        name: "FK_DailyEvents_DailyEvents_DailyEventId",
                        column: x => x.DailyEventId,
                        principalTable: "DailyEvents",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_DailyEvents_Users_UserId",
                        column: x => x.UserId,
                        principalTable: "Users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_DailyEvents_DailyEventId",
                table: "DailyEvents",
                column: "DailyEventId");

            migrationBuilder.CreateIndex(
                name: "IX_DailyEvents_UserId",
                table: "DailyEvents",
                column: "UserId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "DailyEvents");
        }
    }
}
