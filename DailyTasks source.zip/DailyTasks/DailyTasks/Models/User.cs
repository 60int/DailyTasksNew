﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;

namespace DailyTasks.Models
{
    public class User
    {
        private string? userName;
        private ObservableCollection<DailyTask>? dailyTasks;

        public int Id { get; set; }

        public string? UserName
        {
            get => userName;
            set
            {
                if (userName != value)
                {
                    userName = value;
                    OnPropertyChanged(nameof(UserName));
                }
            }
        }

        public ObservableCollection<DailyTask>? DailyTasks
        {
            get => dailyTasks;
            set
            {
                if (dailyTasks != value)
                {
                    dailyTasks = value;
                    OnPropertyChanged(nameof(DailyTasks));
                }
            }
        }

        public User()
        {
            DailyTasks = new ObservableCollection<DailyTask>();
        }

        public User(string userName) : this()
        {
            UserName = userName;
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public override string ToString()
        {
            return userName!;
        }

        public static User[] Deserialize(string filename)
        {
            string[] lines = File.ReadAllLines(filename, Encoding.UTF8).ToArray();
            User[] users = new User[lines.Length];
            for (int i = 0; i < lines.Length; i++)
            {
                string[] line = lines[i].Split(',');
                users[i] = new User(line[0]);
            }
            return users;
        }

        public static void Serialize(string filename, User[] users)
        {
            StreamWriter writer = new(filename, false, Encoding.UTF8);
            foreach (User item in users)
            {
                writer.WriteLine(item.ToString());
            }
            writer.Close();
        }
    }

}
