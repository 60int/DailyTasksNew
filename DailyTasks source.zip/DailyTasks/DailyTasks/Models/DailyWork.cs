﻿using System;
using DailyTasks.ViewModels;

namespace DailyTasks.Models
{
    public class DailyWork : ViewModelBase
    {
        int? userId;
        User? user;
        int? id;
        DateTime? startTime;
        DateTime? endTime;
        int? activeHours;
        int? overtime;

        public int? Id
        {
            get => id;
            set { id = value; OnPropertyChanged(nameof(Id)); }
        }

        public int? UserId
        {
            get => userId;
            set { userId = value; OnPropertyChanged(nameof(UserId)); }
        }

        public virtual User User
        {
            get => user!;
            set { user = value; OnPropertyChanged(nameof(User)); }
        }


    }
}
