﻿using System;
using DailyTasks.Models;
using Microsoft.EntityFrameworkCore;

namespace DailyTasks
{
    public class DailyTasksDbContext : DbContext
    {
        public DbSet<DailyTask> DailyTasks { get; set; }
        public DailyTasksDbContext()
        {
                
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite($"Data Source={AppDomain.CurrentDomain.BaseDirectory}DailyTasksDB.db");
        }
    }
}
