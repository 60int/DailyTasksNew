﻿using DailyTasks.Models;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Documents;

namespace DailyTasks.DataAccess
{
    public class TasksRepository
    {
        private readonly DailyTasksDbContext? _dbContext = null;
        public TasksRepository()
        {
            _dbContext = new DailyTasksDbContext();
        }
        public DailyTask Get(int id)
        {
            return _dbContext!.DailyTasks.Find(id)!;
        }
        public List<DailyTask> GetAll()
        {
            return _dbContext!.DailyTasks.ToList();
        }
        public void AddDailyTask(DailyTask dailyTask)
        {
            if (dailyTask != null)
            {
                _dbContext!.DailyTasks.Add(dailyTask);
                _dbContext.SaveChanges();
            }
        }
        public void UpdateDailyTask(DailyTask dailyTask)
        {
            if (dailyTask != null)
            {
                var taskToUpdate = _dbContext!.DailyTasks.Find(dailyTask.Id);
                if (taskToUpdate != null)
                {
                    taskToUpdate.TotalAmount = dailyTask.TotalAmount ?? 0;
                    taskToUpdate.CustomValue1 = dailyTask.CustomValue1 ?? 0;
                    taskToUpdate.CustomValue2 = dailyTask.CustomValue2 ?? 0;
                    taskToUpdate.CustomValue3 = dailyTask.CustomValue3 ?? 0;
                    taskToUpdate.CustomValue4 = dailyTask.CustomValue4 ?? 0;
                    taskToUpdate.StartTime = dailyTask.StartTime;
                    taskToUpdate.EndTime = dailyTask.EndTime;
                    taskToUpdate.Completed = dailyTask.Completed;
                    taskToUpdate.Priority = dailyTask.Priority;
                    taskToUpdate.TaskType = dailyTask.TaskType;

                    _dbContext.SaveChanges();
                }
            }
        }
        public void RemoveDailyTask(int id)
        {
            var dailyTask = _dbContext!.DailyTasks.Find(id);
            if (dailyTask != null)
            {
                _dbContext.DailyTasks.Remove(dailyTask);
                _dbContext.SaveChanges();
            }
        }
    }
}
