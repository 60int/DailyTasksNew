﻿using System.Windows.Input;

namespace DailyTasks.ViewModels
{
    public class WorkViewModel
    {

    }
}
