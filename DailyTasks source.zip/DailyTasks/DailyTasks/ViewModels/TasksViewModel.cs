﻿using System;
using System.Windows;
using DailyTasks.Models;
using System.Windows.Input;
using DailyTasks.DataAccess;

namespace DailyTasks.ViewModels
{
    class TasksViewModel
    {
        private ICommand? _saveCommand;
        private TasksRepository? _repository;
        private readonly DailyTask? _dailyTask = null;
        public DailyTask DailyTask { get; set; }
        public DailyTasksDbContext? DailyTasksDbContext { get; set; }
        public ICommand? SaveCommand
        {
            get
            {
                _saveCommand ??= new RelayCommand(param => SaveData(), null!);

                return _saveCommand;
            }
        }
        public TasksViewModel()
        {
            DailyTask = new DailyTask();
            _repository = new TasksRepository();
        }
        public void SaveData()
        {
            _repository = new TasksRepository();
            if (DailyTask != null && !string.IsNullOrEmpty(DailyTask.User.UserName))
            {
                _dailyTask!.User = DailyTask.User;
                _dailyTask.TotalAmount = DailyTask.TotalAmount;
                _dailyTask.CustomValue1 = DailyTask.CustomValue1;
                _dailyTask.CustomValue2 = DailyTask.CustomValue2;
                _dailyTask.CustomValue3 = DailyTask.CustomValue3;
                _dailyTask.CustomValue4 = DailyTask.CustomValue4;
                _dailyTask.StartTime = DailyTask.StartTime;
                _dailyTask.EndTime = DailyTask.EndTime;
                _dailyTask.Completed = DailyTask.Completed;
                _dailyTask.Priority = DailyTask.Priority;
                _dailyTask.TaskType = DailyTask.TaskType;
                try
                {
                    if (DailyTask.Id <= 0)
                    {
                        _repository!.AddDailyTask(_dailyTask);
                        MessageBox.Show("New task successfully saved.");
                    }
                    else
                    {
                        _dailyTask.Id = DailyTask.Id;
                        _repository!.UpdateDailyTask(_dailyTask);
                        MessageBox.Show("Task successfully updated.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occured while saving. " + ex.InnerException);
                }
            }
            //if (Application.Current.Windows.OfType<TasksPage>().FirstOrDefault() is TasksPage tasksPage)
            //    tasksPage.Close();
        }
    }
}
