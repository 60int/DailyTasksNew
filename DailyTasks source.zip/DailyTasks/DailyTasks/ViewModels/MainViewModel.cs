﻿using System;
using DailyTasks.Models;
using System.Windows.Input;
using DailyTasks.DataAccess;
using System.Collections.ObjectModel;


namespace DailyTasks.ViewModels
{
    public class MainViewModel
    {
        private ICommand? _editCommand;
        private ICommand? _deleteCommand;
        private ICommand? _openAddTaskWindow;
        private readonly TasksRepository? _tasksRepository;
        public DailyTask? DailyTaskItem { get; set; }

        public MainViewModel()
        {
            DailyTaskItem = new DailyTask();
            _tasksRepository = new TasksRepository();
            GetAll();
        }
        //public ICommand? EditCommand
        //{
        //    get
        //    {
        //        _editCommand ??= new RelayCommand(param => EditTask((int)param), null!);

        //        return _editCommand;
        //    }
        //}

        //public ICommand? DeleteCommand
        //{
        //    get
        //    {
        //        _deleteCommand ??= new RelayCommand(param => DeleteTask((int)param), null!);

        //        return _deleteCommand;
        //    }
        //}

        //public ICommand? OpenAddTaskWindow
        //{
        //    get
        //    {
        //        _openAddTaskWindow ??= new RelayCommand(param => OpenAddTaskWindow(), null!);

        //        return _openAddTaskWindow;
        //    }
        //}


        private void GetAll()
        {
            DailyTaskItem!.DailyTasks = new ObservableCollection<DailyTask>();
            _tasksRepository!.GetAll().ForEach(data =>  DailyTaskItem.DailyTasks.Add(new DailyTask()
            {
                Id = data.Id,
                User = data.User,
                UserId = data.UserId,
                CustomValue1 = data.CustomValue1,
                CustomValue2 = data.CustomValue2,
                CustomValue3 = data.CustomValue3,
                CustomValue4 = data.CustomValue4,
                StartTime = data.StartTime,
                EndTime = data.EndTime,
                Completed = data.Completed,
                Priority = data.Priority,
                TaskType = data.TaskType
            }));
        }
    }
}
